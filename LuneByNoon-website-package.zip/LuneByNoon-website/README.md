# LuneByNoon website: deployment package

Bilingual (English and Arabic) online shop for LuneByNoon, set up for the Egyptian market.
This package is the approved staging build, ready to put on a real domain.

## What is inside

| File or folder | What it is |
| --- | --- |
| `index.html` | The shop. All pages run from this one file (home, collections, product pages, customize, mix and match, bundles, story, help, creators, bag, checkout). |
| `config.js` | Live settings: your domain, the order inbox address, and marketing pixel IDs. Edit this first. |
| `catalog.json` | Products, bundles, prices, delivery fees, promo codes and site text, in English and Arabic. |
| `i18n.js` | Every interface word in English and Arabic, plus the 27 governorates, policies and size chart. |
| `styles.css` | Brand look: colours, fonts, layout, right-to-left Arabic rules. |
| `art.js` | Product drawings used until real photos are added. |
| `app.js` | Shop logic: bag, embroidery builder, checkout, orders. |
| `admin.js` | Store admin used on the staging site. |
| `assets/` | Official logo (taken from the brand sheet), brand photos, share image, tab icon. |
| `products/` | One search-friendly page per product, in English and Arabic, for Google and ad links. |
| `sitemap.xml`, `robots.txt`, `site.webmanifest` | Search engine and phone home-screen files. |
| `apps-script/Code.gs` | Free order inbox in Google Sheets with email alerts. |

## Go live in five steps

1. **Domain.** In `config.js`, set `baseUrl` to the real address, for example `https://www.lunebynoon.com`.
2. **Order inbox.** Follow the steps at the top of `apps-script/Code.gs`. Paste the web app URL into `orderEndpoint`, `creatorEndpoint` and `newsletterEndpoint` in `config.js`.
3. **Pixels.** Paste the Google Analytics 4, Meta Pixel and TikTok Pixel IDs into `config.js`.
4. **Rebuild.** Run `python3 build.py ../site ./dist` so product pages and the sitemap use the real domain. (Needs Python 3 with Pillow.)
5. **Upload.** Upload the contents of `dist/` to any static host (Netlify, Vercel, Cloudflare Pages or normal cPanel hosting). Point the domain to it and switch on HTTPS.

Then submit `https://your-domain/sitemap.xml` in Google Search Console, and turn off the staging banner (set `"staging": false` in `catalog.json`).

## Taking real payments

The checkout already offers cash on delivery, cards (Visa, Mastercard, Meeza), InstaPay, mobile wallets and installments. On a static host, orders arrive in the Google Sheet and the team confirms on WhatsApp, which suits cash on delivery and InstaPay or wallet transfers.

To charge cards and installments online, connect an Egyptian payment gateway such as Paymob or Kashier. That needs a small server step to create the payment securely, which is why the long-term recommendation is to move this design onto Shopify or WooCommerce (see the client guide), where those gateways plug in directly.

## Updating products on the static version

Edit `catalog.json` (each product has `name`, `desc` and `fabric` in `en` and `ar`, plus price, colours and sizes) and upload it again. For real photos, add an `"image": "assets/your-photo.jpg"` line to the product and upload the photo into `assets/`.

## Brand notes

- The logo files in `assets/` were cut from the official LuneByNoon brand sheet. Do not redraw or recolour them. Replace `assets/icon-192.png` with the favicon exported from the brand's Canva files when available.
- Brand fonts: Quicksand is used as is. Citadel Script and The Seasons are licensed fonts that are not on Google Fonts, so the site uses close web stand-ins (Pinyon Script and Gilda Display). If the brand holds web licences, add the font files and swap the names in `styles.css`.
- Arabic uses El Messiri and Alexandria, both by Egyptian type designer Mohamed Gaber, and Aref Ruqaa for Arabic embroidery previews.
