/**
 * LuneByNoon order inbox for Google Sheets.
 *
 * Setup (about 10 minutes):
 * 1. Create a Google Sheet called "LuneByNoon Orders".
 * 2. Extensions > Apps Script. Paste this file. Set TEAM_EMAIL below.
 * 3. Deploy > New deployment > Web app.
 *    Execute as: Me. Who has access: Anyone.
 * 4. Copy the web app URL into config.js as orderEndpoint,
 *    creatorEndpoint and newsletterEndpoint.
 *
 * Each order becomes one row on the "Orders" tab, embroidery lines go to
 * the "Embroidery" tab for the workshop, and the team gets an email.
 */
const TEAM_EMAIL = "hello@lunebynoon.com";

function doPost(e) {
  const data = JSON.parse(e.postData.contents);
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  if (data.orderNo) saveOrder_(ss, data);
  else if (data.links) saveCreator_(ss, data);
  else if (data.email) saveSubscriber_(ss, data);
  return ContentService.createTextOutput(JSON.stringify({ ok: true })).setMimeType(ContentService.MimeType.JSON);
}

function sheet_(ss, name, header) {
  let sh = ss.getSheetByName(name);
  if (!sh) { sh = ss.insertSheet(name); sh.appendRow(header); sh.setFrozenRows(1); }
  return sh;
}

function saveOrder_(ss, o) {
  const sh = sheet_(ss, "Orders", ["Order", "Date", "Status", "Language", "Name", "Phone", "Email", "Governorate", "City", "Street", "Building", "Floor", "Apartment", "Landmark", "Notes", "Payment", "Items", "Gift", "Subtotal", "Discount", "Promo", "Delivery", "Gift wrap", "Total", "Source"]);
  const a = o.address || {}, t = o.totals || {};
  const items = (o.items || []).map(function (it) {
    return it.name.en + " x" + it.qty + ": " + (it.parts || []).map(function (p) { return p.name.en + " " + (p.color ? p.color.en : "") + " " + p.size; }).join(" + ");
  }).join(" | ");
  const gift = o.gift ? (o.gift.recipientName + " " + o.gift.recipientPhone + " " + (o.gift.note || "") + (o.gift.wrap ? " [wrap]" : "")) : "";
  sh.appendRow([o.orderNo, o.createdAt, o.status, o.lang, o.customer.name, "'" + o.customer.phone, o.customer.email, a.governorate, a.city, a.street, a.building, a.floor, a.apartment, a.landmark, a.notes, o.payment.method, items, gift, t.subtotal, t.discount, t.promo, t.delivery, t.giftWrap, t.total, o.utm ? (o.utm.utm_source || "") + " " + (o.utm.utm_campaign || "") : ""]);

  const emb = sheet_(ss, "Embroidery", ["Order", "Date", "Piece", "Colour", "Size", "Qty", "Text", "Font", "Thread", "Placement", "Icon", "Special instructions", "Done"]);
  (o.items || []).forEach(function (it) {
    (it.parts || []).forEach(function (p) {
      if (!p.embroidery) return;
      emb.appendRow([o.orderNo, o.createdAt, p.name.en, p.color ? p.color.en : "", p.size, it.qty, p.embroidery.text, p.embroidery.font, p.embroidery.thread, p.embroidery.placement, p.embroidery.icon || "", p.embroidery.note || "", false]);
    });
  });

  if (TEAM_EMAIL) {
    MailApp.sendEmail(TEAM_EMAIL, "New order " + o.orderNo + " (EGP " + t.total + ")",
      o.customer.name + " · " + o.customer.phone + "\n" + a.governorate + ", " + a.city + "\n\n" + items + "\n\nPayment: " + o.payment.method + "\nTotal: EGP " + t.total);
  }
}

function saveCreator_(ss, c) {
  const sh = sheet_(ss, "Creators", ["Date", "Name", "Phone", "Email", "Type", "Links", "About", "Portfolio"]);
  sh.appendRow([c.at, c.name, "'" + c.phone, c.email, c.type, (c.links || []).join("\n"), c.about, c.portfolio]);
}

function saveSubscriber_(ss, s) {
  const sh = sheet_(ss, "Subscribers", ["Date", "Email", "Language"]);
  sh.appendRow([new Date().toISOString(), s.email, s.lang]);
}
