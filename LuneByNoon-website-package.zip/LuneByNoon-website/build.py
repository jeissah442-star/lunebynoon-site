"""Builds the LuneByNoon deployment package from the staging source.

Usage: python3 build.py <site_dir> <out_dir>
Produces a static site that runs on any host (Netlify, Vercel, Cloudflare Pages,
cPanel hosting), plus one indexable landing page per product for search and ads.
"""
import json, re, shutil, sys, html
from pathlib import Path
from PIL import Image

site, out = Path(sys.argv[1]), Path(sys.argv[2])
here = Path(__file__).parent
if out.exists():
    shutil.rmtree(out)
out.mkdir(parents=True)

cfg_text = (here / "config.js").read_text()
base = re.search(r'baseUrl:\s*"([^"]*)"', cfg_text).group(1).rstrip("/")
cat = json.loads((site / "catalog.json").read_text())

for f in ["styles.css", "i18n.js", "art.js", "app.js", "admin.js", "catalog.json"]:
    shutil.copy(site / f, out / f)
shutil.copytree(site / "assets", out / "assets")
shutil.copy(here / "config.js", out / "config.js")

# Social share image built from the official wordmark.
og = Image.new("RGB", (1200, 630), (246, 231, 241))
logo = Image.open(site / "assets/logo-burgundy.png").convert("RGBA")
w = 760
logo = logo.resize((w, int(logo.height * w / logo.width)), Image.LANCZOS)
og.paste(logo, ((1200 - w) // 2, (630 - logo.height) // 2), logo)
og.save(out / "assets/og-image.jpg", quality=88)

FONTS = '<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Alexandria:wght@300;400;500;600;700&family=Aref+Ruqaa:wght@400;700&family=Caveat:wght@500;600&family=El+Messiri:wght@400;500;600&family=Gilda+Display&family=Pinyon+Script&family=Quicksand:wght@400;500;600;700&display=swap">'
DESC = "LuneByNoon pyjamas, personalized with embroidery. Shop sets, mix and match, bundles and gifts with delivery across Egypt. بيجامات لون باي نون بتطريز شخصي وتوصيل لكل مصر."

org_ld = {
    "@context": "https://schema.org",
    "@graph": [
        {"@type": "Organization", "name": "LuneByNoon", "url": base + "/", "logo": base + "/assets/logo-burgundy.png",
         "sameAs": [cat["settings"].get("instagram", ""), cat["settings"].get("tiktok", "")], "foundingDate": "2020"},
        {"@type": "WebSite", "name": "LuneByNoon", "url": base + "/", "inLanguage": ["en", "ar-EG"]},
    ],
}

def head(title, desc, url, image, extra=""):
    return f"""<!doctype html>
<html lang="en" dir="ltr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<title>{html.escape(title)}</title>
<meta name="description" content="{html.escape(desc)}">
<link rel="canonical" href="{url}">
<link rel="alternate" hreflang="en" href="{url}">
<link rel="alternate" hreflang="ar-EG" href="{url}">
<link rel="alternate" hreflang="x-default" href="{url}">
<meta property="og:type" content="website">
<meta property="og:site_name" content="LuneByNoon">
<meta property="og:title" content="{html.escape(title)}">
<meta property="og:description" content="{html.escape(desc)}">
<meta property="og:url" content="{url}">
<meta property="og:image" content="{image}">
<meta property="og:locale" content="en_US">
<meta property="og:locale:alternate" content="ar_EG">
<meta name="twitter:card" content="summary_large_image">
<meta name="theme-color" content="#6e2135">
<link rel="icon" type="image/png" href="{base}/assets/icon-192.png">
<link rel="manifest" href="{base}/site.webmanifest">
{FONTS}
<link rel="stylesheet" href="{base}/styles.css">
{extra}
</head>
"""

# Main app page
body = (site / "index.html").read_text()
body = re.sub(r"<title>.*?</title>\s*", "", body)
body = re.sub(r'<meta name="claude:[^>]+>\s*', "", body)
body = re.sub(r'<meta name="description"[^>]+>\s*', "", body)
body = re.sub(r'<link rel="preconnect"[^>]+>\s*', "", body)
body = re.sub(r'<link rel="stylesheet"[^>]+>\s*', "", body)
body = body.replace('<script src="i18n.js"></script>', '<script src="config.js"></script>\n<script src="i18n.js"></script>')
ld = f'<script type="application/ld+json">{json.dumps(org_ld, ensure_ascii=False)}</script>'
page = head("LuneByNoon | Personalized pyjamas in Egypt", DESC, base + "/", base + "/assets/og-image.jpg", ld)
page = page.replace(f'href="{base}/styles.css"', 'href="styles.css"')
(out / "index.html").write_text(page + "<body>\n" + body + "\n</body>\n</html>\n")

# Placeholder tab icon: the full official wordmark, unaltered, on burgundy.
# Replace assets/icon-192.png with the favicon exported from the brand's Canva files.
icon = Image.new("RGB", (192, 192), (110, 33, 53))
crop = Image.open(site / "assets/logo-cream.png").convert("RGBA")
crop.thumbnail((176, 176), Image.LANCZOS)
icon.paste(crop, ((192 - crop.width) // 2, (192 - crop.height) // 2), crop)
icon.save(out / "assets/icon-192.png")
(out / "site.webmanifest").write_text(json.dumps({"name": "LuneByNoon", "short_name": "LuneByNoon", "start_url": "/", "display": "standalone", "background_color": "#f6e7f1", "theme_color": "#6e2135", "icons": [{"src": "/assets/icon-192.png", "sizes": "192x192", "type": "image/png"}]}, indent=2))

# One indexable landing page per product, in English and Arabic on the same page.
urls = [base + "/"]
for p in cat["products"]:
    url = f"{base}/products/{p['id']}/"
    urls.append(url)
    ld = {"@context": "https://schema.org", "@type": "Product", "name": p["name"]["en"], "alternateName": p["name"]["ar"],
          "description": p["desc"]["en"], "sku": p["id"], "brand": {"@type": "Brand", "name": "LuneByNoon"}, "image": base + "/assets/og-image.jpg",
          "offers": {"@type": "Offer", "priceCurrency": "EGP", "price": p["price"], "url": url,
                     "availability": "https://schema.org/InStock" if p.get("inStock", True) else "https://schema.org/OutOfStock"}}
    title = f"{p['name']['en']} | {p['name']['ar']} | LuneByNoon"
    desc = f"{p['desc']['en']} {p['desc']['ar']}"
    h = head(title, desc, url, base + "/assets/og-image.jpg", f'<script type="application/ld+json">{json.dumps(ld, ensure_ascii=False)}</script>')
    colours = ", ".join(c["name"]["en"] for c in p["colors"])
    colours_ar = "، ".join(c["name"]["ar"] for c in p["colors"])
    d = out / "products" / p["id"]
    d.mkdir(parents=True)
    (d / "index.html").write_text(h + f"""<body>
<header class="hdr"><div class="wrap" style="grid-template-columns:1fr"><a class="logo" href="{base}/" style="justify-self:center"><img src="{base}/assets/logo-burgundy.png" alt="LuneByNoon" width="640" height="148"></a></div></header>
<main class="wrap" style="padding-block:3rem;display:grid;gap:2rem;max-width:860px">
  <section style="display:grid;gap:.8rem">
    <span class="eyebrow">LuneByNoon</span><h1>{html.escape(p['name']['en'])}</h1>
    <p class="price" style="font-size:1.2rem">EGP {p['price']:,}</p>
    <p class="lede">{html.escape(p['desc']['en'])}</p>
    <p class="note">{html.escape(p['fabric']['en'])} Colours: {html.escape(colours)}. Sizes: {html.escape(', '.join(p['sizes']))}.{' Can be personalized with embroidery.' if p.get('customizable') else ''}</p>
    <a class="btn" style="justify-self:start" href="{base}/#p-{p['id']}">Order now</a>
  </section>
  <section dir="rtl" lang="ar-EG" style="display:grid;gap:.8rem;font-family:'Alexandria',sans-serif">
    <h2 style="font-family:'El Messiri',serif">{html.escape(p['name']['ar'])}</h2>
    <p class="lede">{html.escape(p['desc']['ar'])}</p>
    <p class="note">{html.escape(p['fabric']['ar'])} الألوان: {html.escape(colours_ar)}.{' ينفع يتطرز.' if p.get('customizable') else ''}</p>
    <a class="btn" style="justify-self:start" href="{base}/#p-{p['id']}">اطلبي دلوقتي</a>
  </section>
</main>
<script src="{base}/config.js"></script>
</body></html>
""")

(out / "sitemap.xml").write_text('<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n' + "".join(f"  <url><loc>{u}</loc></url>\n" for u in urls) + "</urlset>\n")
(out / "robots.txt").write_text(f"User-agent: *\nAllow: /\nSitemap: {base}/sitemap.xml\n")
print("built", out, len(urls), "urls")
