/* LuneByNoon deployment settings.
   Fill these in before going live. Leave a value empty to switch that feature off. */
window.LBN_CONFIG = {
  // The live address of the shop, no trailing slash.
  baseUrl: "https://lunebynoon.com",

  // Where the product catalogue is read from.
  catalogUrl: "catalog.json",

  // Google Apps Script web app URL (see apps-script/Code.gs).
  // Orders, creator applications and newsletter sign-ups are sent here
  // and land in the LuneByNoon Google Sheet, with an email to the team.
  orderEndpoint: "",
  creatorEndpoint: "",
  newsletterEndpoint: "",

  // Marketing pixels. Paste the IDs from each ad platform.
  ga4: "",          // Google Analytics 4, looks like G-XXXXXXX
  metaPixel: "",    // Meta (Facebook and Instagram) Pixel ID, numbers only
  tiktokPixel: ""   // TikTok Pixel ID
};

/* Loads the pixels that have an ID. The shop sends these events automatically:
   view_item, add_to_cart, begin_checkout, purchase, sign_up, generate_lead. */
(function (c) {
  if (c.ga4) {
    var s = document.createElement("script");
    s.async = true; s.src = "https://www.googletagmanager.com/gtag/js?id=" + encodeURIComponent(c.ga4);
    document.head.appendChild(s);
    window.dataLayer = window.dataLayer || [];
    window.gtag = function () { window.dataLayer.push(arguments); };
    window.gtag("js", new Date());
    window.gtag("config", c.ga4, { currency: "EGP" });
  }
  if (c.metaPixel) {
    !function (f, b, e, v, n, t, s) { if (f.fbq) return; n = f.fbq = function () { n.callMethod ? n.callMethod.apply(n, arguments) : n.queue.push(arguments); }; if (!f._fbq) f._fbq = n; n.push = n; n.loaded = !0; n.version = "2.0"; n.queue = []; t = b.createElement(e); t.async = !0; t.src = v; s = b.getElementsByTagName(e)[0]; s.parentNode.insertBefore(t, s); }(window, document, "script", "https://connect.facebook.net/en_US/fbevents.js");
    window.fbq("init", c.metaPixel); window.fbq("track", "PageView");
  }
  if (c.tiktokPixel) {
    !function (w, d, t) { w.TiktokAnalyticsObject = t; var ttq = w[t] = w[t] || []; ttq.methods = ["page", "track", "identify", "instances", "debug", "on", "off", "once", "ready", "alias", "group", "enableCookie", "disableCookie"]; ttq.setAndDefer = function (t, e) { t[e] = function () { t.push([e].concat(Array.prototype.slice.call(arguments, 0))); }; }; for (var i = 0; i < ttq.methods.length; i++) ttq.setAndDefer(ttq, ttq.methods[i]); ttq.load = function (e) { var n = "https://analytics.tiktok.com/i18n/pixel/events.js"; ttq._i = ttq._i || {}; ttq._i[e] = []; ttq._i[e]._u = n; var o = d.createElement("script"); o.type = "text/javascript"; o.async = !0; o.src = n + "?sdkid=" + e + "&lib=" + t; var a = d.getElementsByTagName("script")[0]; a.parentNode.insertBefore(o, a); }; ttq.load(c.tiktokPixel); ttq.page(); }(window, document, "ttq");
  }
})(window.LBN_CONFIG);
