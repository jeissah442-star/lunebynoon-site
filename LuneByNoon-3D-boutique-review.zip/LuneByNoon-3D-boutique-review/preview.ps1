# LuneByNoon - local preview of the 3D boutique upgrade.
# Serves the "site" folder at http://localhost:8080 and opens it in your browser.
# Nothing is uploaded anywhere. Close this window to stop the preview.
$port = 8080
$root = Join-Path $PSScriptRoot 'site'
$types = @{
  '.html' = 'text/html; charset=utf-8'; '.js' = 'text/javascript; charset=utf-8'; '.css' = 'text/css; charset=utf-8'
  '.json' = 'application/json; charset=utf-8'; '.png' = 'image/png'; '.jpg' = 'image/jpeg'; '.jpeg' = 'image/jpeg'
  '.svg' = 'image/svg+xml'; '.webmanifest' = 'application/manifest+json'; '.xml' = 'application/xml'; '.txt' = 'text/plain'
}
$listener = New-Object System.Net.HttpListener
$listener.Prefixes.Add("http://localhost:$port/")
try { $listener.Start() } catch { Write-Host "Port $port is busy. Close other previews and try again."; Read-Host 'Press Enter to close'; exit 1 }
Write-Host ""
Write-Host "  LuneByNoon preview is running at http://localhost:$port/"
Write-Host "  Tip: open it in a private window to see the door again, or add #boutique to the address."
Write-Host "  Close this window to stop."
Start-Process "http://localhost:$port/"
while ($listener.IsListening) {
  $ctx = $listener.GetContext()
  try {
    $rel = [Uri]::UnescapeDataString($ctx.Request.Url.AbsolutePath).TrimStart('/')
    if ($rel -eq '' -or $rel.EndsWith('/')) { $rel = $rel + 'index.html' }
    $file = [IO.Path]::GetFullPath((Join-Path $root $rel))
    if (-not $file.StartsWith([IO.Path]::GetFullPath($root))) { $ctx.Response.StatusCode = 403 }
    elseif (Test-Path $file -PathType Container) { $file = Join-Path $file 'index.html' }
    if ($ctx.Response.StatusCode -ne 403 -and (Test-Path $file -PathType Leaf)) {
      $bytes = [IO.File]::ReadAllBytes($file)
      $ext = [IO.Path]::GetExtension($file).ToLower()
      $ctx.Response.ContentType = $(if ($types.ContainsKey($ext)) { $types[$ext] } else { 'application/octet-stream' })
      $ctx.Response.Headers.Add('Cache-Control', 'no-store')
      $ctx.Response.OutputStream.Write($bytes, 0, $bytes.Length)
    } elseif ($ctx.Response.StatusCode -ne 403) { $ctx.Response.StatusCode = 404 }
  } catch { $ctx.Response.StatusCode = 500 }
  $ctx.Response.Close()
}
