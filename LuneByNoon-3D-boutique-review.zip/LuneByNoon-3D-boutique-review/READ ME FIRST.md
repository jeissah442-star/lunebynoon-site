# LuneByNoon: the whole store in 3D

This package holds the upgraded website and a one-click preview for Windows. Nothing has been published, and lunebynoon.com is unchanged.

## Preview it

1. Unzip this folder anywhere, for example on the Desktop.
2. Double-click **Open preview (Windows).bat**. Your browser opens at http://localhost:8080.
3. To see the door again, open a private window.

Order sending is switched off in this preview copy (`site/config.js`), so test checkouts reach no one. The deployable zip keeps your real settings.

## What changed since the first version

- **There is no "old site" any more.** Every page now lives inside one 3D world. Moving between pages carries the camera from room to room.
- **The logo is sharp everywhere.** The header, the footer, the door, the product pages and the 3D rooms all use a vector version of the logo (`assets/logo-burgundy.svg` and `logo-cream.svg`), so it stays crisp at any size.
- **The 3D view is sharper.** The scene renders at full resolution whenever it is still, and only lowers its resolution briefly while the camera is moving.

## The rooms

| Page | Room | What you do there |
|---|---|---|
| Home | Every room, in order | Scroll and the camera travels: the boutique, your signature sets, the atelier, the clothes lines, the collection cabinets, the gift salon and the story gallery. |
| Shop Collections | The round boutique | Each arched alcove holds a piece. Drag, swipe, use the arrows, the mouse wheel or the keyboard, or click a piece. The tabs switch collections. "See as a list" opens the filters and grid. |
| Product page | Close up in its alcove | The panel has colour, size, quantity, personalization and Add to bag. Changing the colour or typing initials repaints the framed piece. Arrows hop to the next piece. |
| Customize Your Pyjamas | The embroidery atelier | Six steps, and the camera moves for each one: the piece on the board, your text in the embroidery hoop, the font cards, the thread spools and the placement. You can also click a spool or a font card on the table. |
| Mix & Match | The mix studio | Tops and bottoms hang on two clothes lines. Arrows (or a click on a piece) slide the line, and the panel walks through top, bottom, add-ons, embroidery and review. |
| Bundles | The gift salon | Gift boxes on pedestals. "Open the box" lifts the lid and fans out the pieces, with a panel for each piece's colour, size and embroidery. |
| Our Story | The story gallery | Scroll to walk down an arched corridor past six framed chapters. |
| Help, policies, creators, checkout, orders | The lounge | The page sits on a cream reading panel in front of the collection cabinets. |

All shopping logic is the store's own: sizes, colours, embroidery, the set discount, bundles, the bag, checkout and payments work exactly as before.

## Works on every device

- **Phones:** panels become bottom sheets, and swipes and taps work in every room.
- **Arabic:** fully translated, and the layout mirrors right to left.
- **Reduced motion** (a device setting): camera moves become short fades.
- **No 3D support:** the same interface runs over still pictures of each room.
- **Slower graphics:** the scene lowers its own resolution while moving, then sharpens.

## Files

| File | Change |
|---|---|
| `world-core.js` | **New.** The 3D engine: a small built-in WebGL renderer with no libraries, the camera and the moves between rooms. |
| `world-rooms.js` | **New.** The seven rooms. |
| `world-ui.js` | **New.** The interface for every page, connected to the store's existing logic. |
| `world.css` | **New.** The look of the interface. |
| `assets/logo-*.svg`, `assets/rooms/*.jpg` | **New.** The vector logos, and pictures of the rooms for devices without 3D. |
| `app.js` | Hands each page to the new interface, and shares its existing functions with it. |
| `index.html`, `i18n.js`, `products/*/index.html` | Load the new files, add the new wording in both languages, and use the vector logo. |

The first version's `boutique.js`, `boutique-world.js` and `boutique.css` are replaced by the files above.

## Publishing (when you're happy)

Replace `lunebynoon-site.zip` in the GitHub repository with the new one. The existing workflow publishes it to lunebynoon.com automatically. To undo, put the previous zip back.
