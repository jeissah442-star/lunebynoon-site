/* LuneByNoon — product and room illustrations.
   Until LuneByNoon's own photography is uploaded in admin, each product is drawn
   from its colours and print, and the homepage beds are drawn in the brand palette.
   Embroidery previews are drawn on the same garments. */
window.LBNArt = (function () {
  let uid = 0;
  const nid = (p) => p + "-" + (++uid).toString(36);

  /* Thread colours and fonts exactly as listed in the customization mockup. */
  const THREADS = {
    ballet: "#efb3c3", baby: "#f7d3dc", rose: "#e58fa3", burgundy: "#6e2135", chocolate: "#4f2b1f",
    cream: "#f3e9d2", white: "#ffffff", black: "#1d1517", sage: "#9fb39a"
  };
  const FONTS = {
    script: "'Pinyon Script','Aref Ruqaa',cursive",
    serif: "'Gilda Display','El Messiri',serif",
    sans: "'Quicksand','Alexandria',sans-serif",
    hand: "'Caveat','Aref Ruqaa',cursive",
    mono: "'Gilda Display','El Messiri',serif"
  };
  /* Small embroidered icons from the customization preview mockup. */
  const ICONS = {
    moon: "M14.5 3.2a9 9 0 1 0 6.3 14.6a7.2 7.2 0 0 1 -6.3 -14.6z",
    heart: "M12 20.5l-1.3-1.2C5.6 14.7 2.5 11.9 2.5 8.4A4.4 4.4 0 0 1 7 4c1.9 0 3.6 1 5 2.6C13.4 5 15.1 4 17 4a4.4 4.4 0 0 1 4.5 4.4c0 3.5-3.1 6.3-8.2 10.9z",
    star: "M12 2.8l2.7 6.1 6.6.6-5 4.4 1.5 6.5L12 17l-5.8 3.4 1.5-6.5-5-4.4 6.6-.6z",
    bow: "M12 11.2c-2.6-3.6-8-5.6-8.8-2.7-.8 2.8 1.5 5.3 4.4 4.6-1.4 2.1-2.6 4.6-2.1 6.7l1.6.4 4.9-7.1 4.9 7.1 1.6-.4c.5-2.1-.7-4.6-2.1-6.7 2.9.7 5.2-1.8 4.4-4.6-.8-2.9-6.2-.9-8.8 2.7z",
    flower: "M12 9.2a2.8 2.8 0 1 1 0 5.6a2.8 2.8 0 1 1 0-5.6zM12 2.5c1.7 0 3 1.9 3 4.2 0 .6-.1 1.1-.3 1.6L12 9.3 9.3 8.3c-.2-.5-.3-1-.3-1.6 0-2.3 1.3-4.2 3-4.2zm9.2 6.7c.5 1.6-.9 3.5-3.1 4.2-.6.2-1.1.2-1.7.2L14.7 12l1.6-2.4c.4-.3.9-.6 1.5-.8 2.2-.7 4.4-.2 5 1.4zM2.8 9.2c.5-1.6 2.7-2.1 5-1.4.6.2 1.1.5 1.5.8L10.9 12l-1.7 2.6c-.6 0-1.1 0-1.7-.2-2.2-.7-3.6-2.6-3.1-4.2zM6.3 19.6c-1.4-1 -1.3-3.3.1-5.2.4-.5.8-.9 1.2-1.2l2.9-.1.9 2.9c-.1.5-.3 1-.7 1.5-1.4 1.9-3.6 2.7-4.4 2.1zm11.4 0c-.8.6-3 -.2-4.4-2.1-.4-.5-.6-1-.7-1.5l.9-2.9 2.9.1c.4.3.8.7 1.2 1.2 1.4 1.9 1.5 4.2.1 5.2z"
  };

  function esc(s) {
    return String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  }

  function patternDef(id, print, base, acc) {
    switch (print) {
      case "crescent":
        return `<pattern id="${id}" width="36" height="36" patternUnits="userSpaceOnUse" patternTransform="rotate(-14)"><rect width="36" height="36" fill="${base}"/><path d="M12 6a8 8 0 1 0 8 12.4a6.4 6.4 0 1 1-8-12.4z" fill="${acc}" opacity=".82"/><path d="M29 22a4.2 4.2 0 1 0 4.2 6.5a3.4 3.4 0 1 1-4.2-6.5z" fill="${acc}" opacity=".5"/></pattern>`;
      case "stripe":
        return `<pattern id="${id}" width="14" height="14" patternUnits="userSpaceOnUse"><rect width="14" height="14" fill="${base}"/><rect width="4.5" height="14" fill="${acc}" opacity=".6"/></pattern>`;
      case "gingham":
        return `<pattern id="${id}" width="18" height="18" patternUnits="userSpaceOnUse"><rect width="18" height="18" fill="${base}"/><rect width="9" height="18" fill="${acc}" opacity=".32"/><rect width="18" height="9" fill="${acc}" opacity=".32"/></pattern>`;
      case "dots":
        return `<pattern id="${id}" width="16" height="16" patternUnits="userSpaceOnUse"><rect width="16" height="16" fill="${base}"/><circle cx="4" cy="4" r="1.6" fill="${acc}" opacity=".75"/><circle cx="12" cy="12" r="1.6" fill="${acc}" opacity=".75"/></pattern>`;
      default:
        return "";
    }
  }

  const PATH = {
    shirtLong: "M118 30 L150 46 L182 30 L218 42 L250 150 L228 158 L206 92 L208 205 Q150 214 92 205 L94 92 L72 158 L50 150 L82 42 Z",
    shirtShort: "M118 30 L150 46 L182 30 L218 42 L242 92 L218 103 L206 86 L208 205 Q150 214 92 205 L94 86 L82 103 L58 92 L82 42 Z",
    cami: "M112 62 L118 30 L122 30 L128 62 L172 62 L178 30 L182 30 L188 62 Q200 130 206 196 Q150 206 94 196 Q100 130 112 62 Z",
    pants: "M98 30 L202 30 L214 372 L160 372 L150 128 L140 372 L86 372 Z",
    wide: "M98 30 L202 30 L232 372 L158 372 L150 132 L142 372 L68 372 Z",
    shorts: "M96 30 L204 30 L222 158 L160 164 L150 112 L140 164 L78 158 Z",
    robe: "M116 30 L150 70 L184 30 L220 42 L254 176 L232 184 L212 112 L224 392 Q150 404 76 392 L88 112 L68 184 L46 176 L80 42 Z"
  };

  function shade(id) {
    return `<linearGradient id="${id}" x1="0" y1="0" x2="0.35" y2="1"><stop offset="0" stop-color="#fff" stop-opacity=".28"/><stop offset=".55" stop-color="#fff" stop-opacity="0"/><stop offset="1" stop-color="#3a1018" stop-opacity=".12"/></linearGradient>`;
  }

  function shirt(fill, acc, shadeId, short) {
    const body = short ? PATH.shirtShort : PATH.shirtLong;
    const cuffs = short
      ? `<path d="M58 92 L82 103" stroke="${acc}" stroke-width="4" stroke-linecap="round"/><path d="M218 103 L242 92" stroke="${acc}" stroke-width="4" stroke-linecap="round"/>`
      : `<path d="M50 150 L72 158" stroke="${acc}" stroke-width="4" stroke-linecap="round"/><path d="M228 158 L250 150" stroke="${acc}" stroke-width="4" stroke-linecap="round"/>`;
    return `<path d="${body}" fill="${fill}"/>
      <path d="${body}" fill="url(#${shadeId})"/>
      <path d="M150 48 L150 208" stroke="#3a1018" stroke-opacity=".14" stroke-width="1.2"/>
      <path d="M150 48 L122 31 L110 64 Z" fill="${fill}" stroke="${acc}" stroke-width="2.4" stroke-linejoin="round"/>
      <path d="M150 48 L178 31 L190 64 Z" fill="${fill}" stroke="${acc}" stroke-width="2.4" stroke-linejoin="round"/>
      ${[78, 110, 142, 174].map((y) => `<circle cx="150" cy="${y}" r="3" fill="${acc}" opacity=".9"/>`).join("")}
      <rect x="160" y="100" width="30" height="28" rx="2" fill="${fill}" stroke="#3a1018" stroke-opacity=".12"/>
      <path d="M160 101 L190 101" stroke="${acc}" stroke-width="3"/>
      ${cuffs}
      <path d="M92 205 Q150 214 208 205" fill="none" stroke="${acc}" stroke-width="3.4"/>
      <path d="M100 120 Q112 150 104 186 M200 130 Q190 160 198 190" fill="none" stroke="#3a1018" stroke-opacity=".07" stroke-width="2"/>`;
  }

  function camiTop(fill, acc, shadeId) {
    return `<path d="${PATH.cami}" fill="${fill}"/><path d="${PATH.cami}" fill="url(#${shadeId})"/>
      <path d="M112 62 Q150 76 188 62" fill="none" stroke="${acc}" stroke-width="3"/>
      <path d="M94 196 Q150 206 206 196" fill="none" stroke="${acc}" stroke-width="2.4"/>
      <path d="M140 66 l10 8 l10 -8" fill="none" stroke="${acc}" stroke-width="2"/>`;
  }

  function bottoms(kind, fill, acc, shadeId) {
    const d = kind === "wide" ? PATH.wide : kind === "shorts" ? PATH.shorts : PATH.pants;
    let hems;
    if (kind === "shorts") hems = `<path d="M78 158 L140 164 M160 164 L222 158" stroke="${acc}" stroke-width="3.4"/>`;
    else if (kind === "wide") hems = `<path d="M68 372 L142 372 M158 372 L232 372" stroke="${acc}" stroke-width="3.4"/>`;
    else hems = `<path d="M86 372 L140 372 M160 372 L214 372" stroke="${acc}" stroke-width="3.4"/>`;
    return `<path d="${d}" fill="${fill}"/><path d="${d}" fill="url(#${shadeId})"/>
      <rect x="98" y="30" width="104" height="14" fill="${fill}" stroke="#3a1018" stroke-opacity=".14"/>
      <path d="M98 44 L202 44" stroke="${acc}" stroke-width="2"/>
      <path d="M146 44 q-6 18 -12 22 M154 44 q6 18 12 22" fill="none" stroke="${acc}" stroke-width="1.6"/>
      <path d="M150 128 L150 60" stroke="#3a1018" stroke-opacity=".1" stroke-width="1.2"/>
      ${hems}`;
  }

  function robe(fill, acc, shadeId) {
    return `<path d="${PATH.robe}" fill="${fill}"/><path d="${PATH.robe}" fill="url(#${shadeId})"/>
      <path d="M116 30 L150 70 L150 392 M184 30 L150 70" fill="none" stroke="${acc}" stroke-width="3.2"/>
      <path d="M116 30 Q96 120 112 200 M184 30 Q206 120 188 200" fill="none" stroke="${acc}" stroke-width="3"/>
      <path d="M46 176 L68 184 M232 184 L254 176" stroke="${acc}" stroke-width="4" stroke-linecap="round"/>
      <path d="M90 210 Q150 222 212 210" stroke="${fill}" stroke-width="12" fill="none"/>
      <path d="M90 210 Q150 222 212 210" stroke="#3a1018" stroke-opacity=".12" stroke-width="12" fill="none"/>
      <path d="M150 216 q-14 30 -24 70 M150 216 q10 34 26 66" fill="none" stroke="${fill}" stroke-width="9" stroke-linecap="round"/>
      <rect x="168" y="250" width="32" height="34" rx="2" fill="none" stroke="#3a1018" stroke-opacity=".12"/>
      <path d="M168 251 L200 251" stroke="${acc}" stroke-width="3"/>`;
  }

  function hanger(x, y, bar) {
    return bar
      ? `<g stroke="#b8955a" stroke-width="3" fill="none" stroke-linecap="round"><path d="M${x} ${y + 18} L${x} ${y + 6} a7 7 0 1 1 7 -7"/><path d="M${x - 56} ${y + 22} L${x + 56} ${y + 22}"/></g>`
      : `<g stroke="#b8955a" stroke-width="3" fill="none" stroke-linecap="round" stroke-linejoin="round"><path d="M${x} ${y + 18} L${x} ${y + 6} a7 7 0 1 1 7 -7"/><path d="M${x - 62} ${y + 34} L${x} ${y + 18} L${x + 62} ${y + 34}"/></g>`;
  }

  /* Embroidery: the text, with an optional small icon stitched under it. */
  function embroidery(c, x, y, size, rot) {
    if (!c || (!c.text && !c.icon)) return "";
    const col = THREADS[c.thread] || THREADS.burgundy;
    let out = "";
    let fs = size;
    if (c.text) {
      let tx = String(c.text).slice(0, 12);
      if (c.font === "mono") tx = tx.replace(/\s+/g, "").toUpperCase().split("").join(".");
      const len = Math.max(1, [...tx].length);
      fs = size * Math.min(1, Math.pow(5 / len, 0.55));
      out += `<text x="${x}" y="${y}" text-anchor="middle" dominant-baseline="middle" font-family="${FONTS[c.font] || FONTS.script}" font-style="italic" font-size="${fs.toFixed(1)}" fill="${col}" stroke="${col}" stroke-width=".35" filter="url(#stitch)" style="letter-spacing:${c.font === "mono" ? ".08em" : "0"}">${esc(tx)}</text>`;
    }
    if (c.icon && ICONS[c.icon]) {
      const s = (c.text ? size * 0.7 : size * 1.1);
      const iy = c.text ? y + fs * 0.62 : y - s / 2;
      out += `<path d="${ICONS[c.icon]}" transform="translate(${(x - s / 2).toFixed(1)} ${iy.toFixed(1)}) scale(${(s / 24).toFixed(3)})" fill="${col}" filter="url(#stitch)"/>`;
    }
    return `<g transform="rotate(${rot || 0} ${x} ${y})">${out}</g>`;
  }

  /* Where each placement sits on the drawing. */
  function spots(shape, shirtOff, botOff) {
    const s = (x, y) => [x + shirtOff[0], y + shirtOff[1]];
    const b = (x, y) => [x + botOff[0], y + botOff[1]];
    const short = shape === "set-short";
    const out = {
      left: [...s(175, 84), 13, 0],
      right: [...s(124, 92), 13, 0],
      pocket: [...s(175, 113), 12, 0],
      sleeve: short ? [...s(226, 89), 8.5, -22] : [...s(235, 137), 8.5, -71]
    };
    if (botOff) {
      if (shape === "set-short") out.shorts = [...b(190, 132), 10, -84];
      else out.trousers = [...b(187, 318), 11, -88];
    }
    return out;
  }

  /* Placement options, from the customization mockup: Left Chest, Right Chest, Pocket, Sleeve, Shorts, Trousers. */
  function placementsFor(p) {
    switch (p.shape) {
      case "set-long": return ["left", "right", "pocket", "sleeve", "trousers"];
      case "set-short": return ["left", "right", "pocket", "sleeve", "shorts"];
      case "top": return ["left", "right", "pocket", "sleeve"];
      case "pants": case "wide": return ["trousers"];
      case "shorts": return ["shorts"];
      case "robe": return ["left", "right", "pocket", "sleeve"];
      default: return [];
    }
  }

  function defs(extra) {
    return `<defs><filter id="stitch" x="-20%" y="-40%" width="140%" height="180%"><feDropShadow dx=".5" dy=".7" stdDeviation=".35" flood-color="#2b0d14" flood-opacity=".45"/></filter>
      <filter id="softsh" x="-10%" y="-10%" width="120%" height="130%"><feDropShadow dx="0" dy="6" stdDeviation="7" flood-color="#5a2333" flood-opacity=".16"/></filter>${extra}</defs>`;
  }

  /* Draw a product. opts: { color, custom, zoom, rack } */
  function draw(product, opts) {
    opts = opts || {};
    const col = (product.colors || []).find((c) => c.key === opts.color) || (product.colors || [])[0] || { base: "#f4cdd8", accent: "#6e2135" };
    const base = col.base, acc = col.accent;
    const pid = nid("pt"), sid = nid("sh");
    const pat = patternDef(pid, product.print, base, acc);
    const fill = pat ? `url(#${pid})` : base;
    const c = opts.custom;
    const shape = product.shape;
    let body = "", vb = "0 0 300 420", sp = {};

    if (shape === "set-long" || shape === "set-short" || shape === "cami") {
      vb = opts.rack ? "0 0 600 520" : "0 0 540 430";
      const so = opts.rack ? [40, 74] : [0, 8];
      const bo = opts.rack ? [250, shape === "set-long" ? 70 : 72] : [236, 18];
      const top = shape === "cami" ? camiTop(fill, acc, sid) : shirt(fill, acc, sid, shape === "set-short");
      const bot = bottoms(shape === "set-long" ? "pants" : "shorts", fill, acc, sid);
      body = (opts.rack ? hanger(so[0] + 150, so[1] - 12) + hanger(bo[0] + 150, bo[1] - 12, true) : "") +
        `<g filter="url(#softsh)"><g transform="translate(${bo[0]} ${bo[1]})">${bot}</g><g transform="translate(${so[0]} ${so[1]})">${top}</g></g>`;
      if (shape !== "cami") sp = spots(shape, so, bo);
    } else if (shape === "top") {
      vb = "0 0 300 240";
      body = `<g filter="url(#softsh)" transform="translate(0 6)">${shirt(fill, acc, sid, false)}</g>`;
      sp = spots("top", [0, 6], null);
    } else if (shape === "pants" || shape === "wide" || shape === "shorts") {
      vb = shape === "shorts" ? "0 0 300 210" : "0 0 300 410";
      body = `<g filter="url(#softsh)" transform="translate(0 6)">${bottoms(shape, fill, acc, sid)}</g>`;
      sp = shape === "shorts" ? { shorts: [190, 126, 10, -84] } : { trousers: [187, 324, 11, -88] };
    } else if (shape === "robe") {
      if (opts.rack) {
        vb = "0 0 600 520";
        body = hanger(300, 36) + `<g filter="url(#softsh)" transform="translate(150 48) scale(1)">${robe(fill, acc, sid)}</g>`;
        sp = { left: [334, 152, 13, 0], right: [266, 152, 13, 0], pocket: [334, 324, 12, 0], sleeve: [388, 212, 8.5, -74] };
      } else {
        vb = "0 0 300 420";
        body = `<g filter="url(#softsh)" transform="translate(0 6)">${robe(fill, acc, sid)}</g>`;
        sp = { left: [184, 104, 13, 0], right: [116, 104, 13, 0], pocket: [184, 276, 12, 0], sleeve: [238, 164, 8.5, -74] };
      }
    } else if (shape === "mask") {
      vb = "0 0 300 220";
      const m = "M40 110 Q30 60 150 66 Q270 60 260 110 Q262 160 200 162 Q166 160 150 136 Q134 160 100 162 Q38 160 40 110 Z";
      body = `<g filter="url(#softsh)"><path d="${m}" fill="${fill}"/><path d="${m}" fill="url(#${sid})"/><path d="${m}" fill="none" stroke="${acc}" stroke-width="3"/><path d="M40 104 Q10 100 8 120 M260 104 Q290 100 292 120" stroke="${acc}" stroke-width="5" fill="none" stroke-linecap="round"/><path d="M196 96a9 9 0 1 0 9 14a7.2 7.2 0 1 1 -9 -14z" fill="${acc}" opacity=".85"/></g>`;
    } else if (shape === "scrunchie") {
      vb = "0 0 300 220";
      let blobs = "";
      for (let k = 0; k < 14; k++) {
        const a = (k / 14) * Math.PI * 2;
        blobs += `<circle cx="${(150 + Math.cos(a) * 52).toFixed(1)}" cy="${(110 + Math.sin(a) * 52).toFixed(1)}" r="23" fill="${fill}"/>`;
      }
      body = `<g filter="url(#softsh)">${blobs}<circle cx="150" cy="110" r="30" fill="#f6e7f1"/><circle cx="150" cy="110" r="76" fill="url(#${sid})"/></g>`;
    } else if (shape === "towel") {
      vb = "0 0 300 220";
      body = `<g filter="url(#softsh)"><path d="M46 70 Q150 40 254 70 L254 170 Q150 196 46 170 Z" fill="${fill}"/><path d="M46 70 Q150 40 254 70 L254 170 Q150 196 46 170 Z" fill="url(#${sid})"/><path d="M46 150 Q150 176 254 150" fill="none" stroke="${acc}" stroke-width="2.4" stroke-dasharray="3 4"/><path d="M60 82 Q150 58 240 82" fill="none" stroke="#3a1018" stroke-opacity=".08" stroke-width="10"/><path d="M214 118a9 9 0 1 0 9 14a7.2 7.2 0 1 1 -9 -14z" fill="${acc}" opacity=".85"/></g>`;
    } else if (shape === "pillow") {
      vb = "0 0 300 220";
      body = `<g filter="url(#softsh)"><rect x="34" y="40" width="232" height="146" rx="26" fill="${fill}"/><rect x="34" y="40" width="232" height="146" rx="26" fill="url(#${sid})"/><rect x="42" y="48" width="216" height="130" rx="20" fill="none" stroke="${acc}" stroke-width="2.4"/><path d="M226 74a9 9 0 1 0 9 14a7.2 7.2 0 1 1 -9 -14z" fill="${acc}" opacity=".8"/></g>`;
    }

    let emb = "";
    if (c && (c.text || c.icon) && sp[c.placement]) {
      const [x, y, s, r] = sp[c.placement];
      emb = embroidery(c, x, y, s, r);
    }

    let viewBox = vb;
    if (opts.zoom && c && sp[c.placement]) {
      const [x, y] = sp[c.placement];
      const w = 92, h = w * 0.72;
      viewBox = `${(x - w / 2).toFixed(1)} ${(y - h / 2 + 4).toFixed(1)} ${w.toFixed(1)} ${h.toFixed(1)}`;
    }
    return `<svg class="art" viewBox="${viewBox}" preserveAspectRatio="xMidYMid meet" role="img" aria-label="${esc(product.name ? product.name.en : "")}" xmlns="http://www.w3.org/2000/svg">${defs(pat + shade(sid))}${body}${emb}</svg>`;
  }

  /* The gold boutique rack the hero carousel hangs pieces on. */
  function rack() {
    return `<svg class="rack" viewBox="0 0 600 520" preserveAspectRatio="xMidYMid meet" aria-hidden="true" xmlns="http://www.w3.org/2000/svg">
      <defs><linearGradient id="gold" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#e3c98f"/><stop offset=".5" stop-color="#b8955a"/><stop offset="1" stop-color="#d9bb7c"/></linearGradient></defs>
      <g fill="none" stroke="url(#gold)" stroke-linecap="round">
        <path d="M70 470 L70 120 Q70 40 300 30 Q530 40 530 120 L530 470" stroke-width="9"/>
        <path d="M70 70 L530 70" stroke-width="6"/>
        <path d="M300 30 L300 12" stroke-width="5"/>
      </g>
      <circle cx="300" cy="10" r="8" fill="url(#gold)"/>
      <rect x="60" y="466" width="480" height="18" rx="4" fill="#f3e9d8" stroke="url(#gold)" stroke-width="3"/>
      <g fill="#6b5a4a"><circle cx="96" cy="500" r="14"/><circle cx="504" cy="500" r="14"/></g>
      <g fill="url(#gold)"><circle cx="96" cy="500" r="6"/><circle cx="504" cy="500" r="6"/></g>
    </svg>`;
  }

  /* A styled bed for the homepage arches ("four beds, four experiences").
     o: { wall, duvet, duvetPrint, duvetAcc, pillow, head, accent, canopy, gift, word, moonPillow } */
  function bed(o) {
    const id = nid("bd"), pid = nid("bp");
    const pat = o.duvetPrint ? patternDef(pid, o.duvetPrint, o.duvet, o.duvetAcc || o.accent) : "";
    const duvet = pat ? `url(#${pid})` : o.duvet;
    const acc = o.accent || "#6e2135";
    return `<svg class="art bed" viewBox="0 0 300 380" preserveAspectRatio="xMidYMax slice" aria-hidden="true" xmlns="http://www.w3.org/2000/svg">
      <defs>${pat}<linearGradient id="${id}w" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${o.wall || "#f6e1e6"}"/><stop offset="1" stop-color="#f0d3da"/></linearGradient>
      <radialGradient id="${id}l" cx=".2" cy=".25" r=".6"><stop offset="0" stop-color="#fff6e8" stop-opacity=".9"/><stop offset="1" stop-color="#fff6e8" stop-opacity="0"/></radialGradient></defs>
      <rect width="300" height="380" fill="url(#${id}w)"/>
      <g stroke="#fff" stroke-opacity=".55" fill="none"><rect x="18" y="40" width="80" height="150" rx="3"/><rect x="202" y="40" width="80" height="150" rx="3"/></g>
      <rect width="300" height="380" fill="url(#${id}l)"/>
      ${o.canopy ? `<path d="M40 0 Q150 40 260 0 L262 250 Q236 200 214 250 L214 40 Q150 70 86 40 L86 250 Q64 200 38 250 Z" fill="#fff" opacity=".55"/>` : ""}
      <g transform="translate(36 52)"><rect x="0" y="120" width="26" height="46" rx="3" fill="#f3e6d6"/><path d="M4 120 L13 96 L22 120 Z" fill="#fbe9d0"/><circle cx="13" cy="92" r="16" fill="#fff4dc" opacity=".55"/></g>
      <path d="M58 300 L58 170 Q58 104 150 98 Q242 104 242 170 L242 300 Z" fill="${o.head || "#f7ece6"}" stroke="#e9d4c8" stroke-width="2"/>
      <path d="M74 170 Q74 118 150 112 Q226 118 226 170" fill="none" stroke="#e9d4c8" stroke-width="2"/>
      <g transform="translate(150 112)" fill="${acc}"><path d="M0 0c-6-8-18-12-20-6s4 11 10 9c-3 5-5 10-4 14l3 1 11-14 11 14 3-1c1-4-1-9-4-14 6 2 12-3 10-9s-14-2-20 6z"/></g>
      <rect x="70" y="172" width="78" height="46" rx="16" fill="${o.pillow || "#fbf3f5"}" stroke="#ead9de"/>
      <rect x="152" y="172" width="78" height="46" rx="16" fill="${o.pillow || "#fbf3f5"}" stroke="#ead9de"/>
      ${o.moonPillow ? `<path d="M138 196a20 20 0 1 0 18 30a16 16 0 1 1 -18 -30z" fill="${o.duvet}" stroke="${acc}" stroke-opacity=".4"/>` : `<rect x="112" y="190" width="76" height="40" rx="14" fill="${o.duvet}" stroke="${acc}" stroke-opacity=".25"/>`}
      ${o.word ? `<text x="150" y="${o.moonPillow ? 252 : 216}" text-anchor="middle" font-family="'Pinyon Script',cursive" font-size="${o.word.length > 2 ? 15 : 20}" fill="${acc}">${esc(o.word)}</text>` : ""}
      <path d="M30 380 L30 250 Q60 222 150 224 Q240 222 270 250 L270 380 Z" fill="${duvet}"/>
      <path d="M30 380 L30 250 Q60 222 150 224 Q240 222 270 250 L270 380 Z" fill="#fff" opacity=".12"/>
      <path d="M30 262 Q150 238 270 262" stroke="#fff" stroke-opacity=".6" stroke-width="5" fill="none"/>
      <path d="M70 300 Q110 286 150 300 T230 300 M60 340 Q110 324 160 342 T260 338" stroke="#3a1018" stroke-opacity=".07" stroke-width="3" fill="none"/>
      ${o.gift ? `<g transform="translate(176 248)"><rect width="70" height="52" rx="3" fill="#f8d9e1" stroke="#e9b8c6"/><rect x="30" width="10" height="52" fill="${acc}" opacity=".7"/><rect y="20" width="70" height="9" fill="${acc}" opacity=".7"/><path d="M35 0c-6-10-20-12-20-4s12 6 20 4c8 2 20 4 20-4s-14-6-20 4z" fill="${acc}" opacity=".8"/></g>` : ""}
    </svg>`;
  }

  /* Small crescent used as decoration (not a logo). */
  function crescent(size, color) {
    return `<svg width="${size}" height="${size}" viewBox="0 0 24 24" aria-hidden="true"><path d="${ICONS.moon}" fill="${color || "currentColor"}"/></svg>`;
  }
  function icon(name, size, color) {
    return `<svg width="${size}" height="${size}" viewBox="0 0 24 24" aria-hidden="true"><path d="${ICONS[name] || ICONS.moon}" fill="${color || "currentColor"}"/></svg>`;
  }

  return { draw, rack, bed, crescent, icon, placementsFor, THREADS, FONTS, ICONS, esc };
})();
