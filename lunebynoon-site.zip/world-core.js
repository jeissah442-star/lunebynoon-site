/* LuneByNoon — the 3D world, core.
   A small dependency-free WebGL2 renderer, procedural materials, a camera director
   that hops between rooms, and the shared helpers every room uses.
   Rooms (the hall with the door and rotunda, the atelier, the mix studio, the gift
   salon, the story gallery and the lounge) live in world-rooms.js and register on
   LBNW.rooms. Exposes window.LBNW. */
(function () {
  "use strict";

  /* ---------------------------------------------------------------- math */
  const D2R = Math.PI / 180;
  const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
  const lerp = (a, b, t) => a + (b - a) * t;
  const smooth = (t) => t * t * (3 - 2 * t);
  const smoother = (t) => t * t * t * (t * (t * 6 - 15) + 10);
  const easeInOutCubic = (t) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2);
  const easeInOutSine = (t) => -(Math.cos(Math.PI * t) - 1) / 2;
  const easeOutCubic = (t) => 1 - Math.pow(1 - t, 3);
  const easeInCubic = (t) => t * t * t;
  const easeOutBack = (t) => { const c1 = 1.4, c3 = c1 + 1; return 1 + c3 * Math.pow(t - 1, 3) + c1 * Math.pow(t - 1, 2); };
  const mod = (a, n) => ((a % n) + n) % n;
  const damp = (a, b, k, dt) => lerp(a, b, 1 - Math.exp(-k * dt));

  const V = {
    add: (a, b) => [a[0] + b[0], a[1] + b[1], a[2] + b[2]],
    sub: (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]],
    mul: (a, s) => [a[0] * s, a[1] * s, a[2] * s],
    dot: (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2],
    cross: (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]],
    len: (a) => Math.hypot(a[0], a[1], a[2]),
    norm: (a) => { const l = Math.hypot(a[0], a[1], a[2]) || 1; return [a[0] / l, a[1] / l, a[2] / l]; },
    lerp: (a, b, t) => [lerp(a[0], b[0], t), lerp(a[1], b[1], t), lerp(a[2], b[2], t)],
    damp: (a, b, k, dt) => { const f = 1 - Math.exp(-k * dt); return [lerp(a[0], b[0], f), lerp(a[1], b[1], f), lerp(a[2], b[2], f)]; }
  };

  const M4 = {
    ident: () => new Float32Array([1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1]),
    mul(a, b, out) {
      out = out || new Float32Array(16);
      for (let c = 0; c < 4; c++) for (let r = 0; r < 4; r++) {
        out[c * 4 + r] = a[r] * b[c * 4] + a[4 + r] * b[c * 4 + 1] + a[8 + r] * b[c * 4 + 2] + a[12 + r] * b[c * 4 + 3];
      }
      return out;
    },
    persp(fovy, aspect, near, far) {
      const f = 1 / Math.tan(fovy / 2), nf = 1 / (near - far), m = new Float32Array(16);
      m[0] = f / aspect; m[5] = f; m[10] = (far + near) * nf; m[11] = -1; m[14] = 2 * far * near * nf;
      return m;
    },
    lookAt(eye, tgt, up) {
      const z = V.norm(V.sub(eye, tgt)), x = V.norm(V.cross(up, z)), y = V.cross(z, x);
      return new Float32Array([x[0], y[0], z[0], 0, x[1], y[1], z[1], 0, x[2], y[2], z[2], 0,
        -V.dot(x, eye), -V.dot(y, eye), -V.dot(z, eye), 1]);
    },
    basis(o, x, y, z) { return new Float32Array([x[0], x[1], x[2], 0, y[0], y[1], y[2], 0, z[0], z[1], z[2], 0, o[0], o[1], o[2], 1]); },
    trans(x, y, z) { const m = M4.ident(); m[12] = x; m[13] = y; m[14] = z; return m; },
    rotX(a) { const c = Math.cos(a), s = Math.sin(a); return new Float32Array([1, 0, 0, 0, 0, c, s, 0, 0, -s, c, 0, 0, 0, 0, 1]); },
    rotY(a) { const c = Math.cos(a), s = Math.sin(a); return new Float32Array([c, 0, -s, 0, 0, 1, 0, 0, s, 0, c, 0, 0, 0, 0, 1]); },
    rotZ(a) { const c = Math.cos(a), s = Math.sin(a); return new Float32Array([c, s, 0, 0, -s, c, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1]); },
    scale(x, y, z) { if (y == null) { y = x; z = x; } return new Float32Array([x, 0, 0, 0, 0, y, 0, 0, 0, 0, z, 0, 0, 0, 0, 1]); },
    chain(...ms) { let r = ms[0]; for (let i = 1; i < ms.length; i++) r = M4.mul(r, ms[i]); return r; },
    pt(m, p) { return [m[0] * p[0] + m[4] * p[1] + m[8] * p[2] + m[12], m[1] * p[0] + m[5] * p[1] + m[9] * p[2] + m[13], m[2] * p[0] + m[6] * p[1] + m[10] * p[2] + m[14]]; },
    dir(m, p) { return [m[0] * p[0] + m[4] * p[1] + m[8] * p[2], m[1] * p[0] + m[5] * p[1] + m[9] * p[2], m[2] * p[0] + m[6] * p[1] + m[10] * p[2]]; }
  };

  function lin(hex, k) {
    const h = hex.replace("#", "");
    const c = [0, 2, 4].map((i) => parseInt(h.substr(i, 2), 16) / 255).map((v) => (v <= 0.04045 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4)));
    return k == null ? c : c.map((v) => v * k);
  }
  function mixHex(a, b, t) {
    const pa = a.replace("#", ""), pb = b.replace("#", "");
    const c = [0, 2, 4].map((i) => Math.round(lerp(parseInt(pa.substr(i, 2), 16), parseInt(pb.substr(i, 2), 16), t)));
    return "#" + c.map((v) => v.toString(16).padStart(2, "0")).join("");
  }

  /* ------------------------------------------------------------ geometry */
  class Geo {
    constructor() { this.p = []; this.n = []; this.u = []; this.i = []; }
    v(x, y, z, nx, ny, nz, u, w) { this.p.push(x, y, z); this.n.push(nx, ny, nz); this.u.push(u, w); return this.p.length / 3 - 1; }
    tri(a, b, c) { this.i.push(a, b, c); }
    quad(a, b, c, d) { this.i.push(a, b, c, a, c, d); }
    add(g, m) {
      const off = this.p.length / 3;
      for (let k = 0; k < g.p.length; k += 3) {
        const p = m ? M4.pt(m, [g.p[k], g.p[k + 1], g.p[k + 2]]) : [g.p[k], g.p[k + 1], g.p[k + 2]];
        const n = m ? V.norm(M4.dir(m, [g.n[k], g.n[k + 1], g.n[k + 2]])) : [g.n[k], g.n[k + 1], g.n[k + 2]];
        this.p.push(p[0], p[1], p[2]); this.n.push(n[0], n[1], n[2]);
      }
      for (let k = 0; k < g.u.length; k++) this.u.push(g.u[k]);
      for (let k = 0; k < g.i.length; k++) this.i.push(g.i[k] + off);
      return this;
    }
  }
  const G = {
    rect(x0, y0, x1, y1, z, s, flip) {
      const g = new Geo(), nz = flip ? -1 : 1; s = s || 1;
      const a = g.v(x0, y0, z, 0, 0, nz, x0 * s, y0 * s), b = g.v(x1, y0, z, 0, 0, nz, x1 * s, y0 * s);
      const c = g.v(x1, y1, z, 0, 0, nz, x1 * s, y1 * s), d = g.v(x0, y1, z, 0, 0, nz, x0 * s, y1 * s);
      g.quad(a, b, c, d); return g;
    },
    card(w, h, z) {
      const g = new Geo(), x = w / 2, y = h / 2; z = z || 0;
      const a = g.v(-x, -y, z, 0, 0, 1, 0, 0), b = g.v(x, -y, z, 0, 0, 1, 1, 0), c = g.v(x, y, z, 0, 0, 1, 1, 1), d = g.v(-x, y, z, 0, 0, 1, 0, 1);
      g.quad(a, b, c, d); return g;
    },
    /* a card hanging from its top edge (origin at the top centre) */
    hangCard(w, h) { const g = new Geo(); g.add(G.card(w, h), M4.trans(0, -h / 2, 0)); return g; },
    box(w, h, d) {
      const g = new Geo(), x = w / 2, y = h / 2, z = d / 2;
      const f = (n, u, v, sz) => {
        const c = V.mul(n, sz), base = g.p.length / 3;
        [[-1, -1], [1, -1], [1, 1], [-1, 1]].forEach(([a, b]) => { const p = V.add(c, V.add(V.mul(u, a), V.mul(v, b))); g.v(p[0], p[1], p[2], n[0], n[1], n[2], (a + 1) / 2, (b + 1) / 2); });
        g.quad(base, base + 1, base + 2, base + 3);
      };
      f([0, 0, 1], [x, 0, 0], [0, y, 0], z); f([0, 0, -1], [-x, 0, 0], [0, y, 0], z);
      f([1, 0, 0], [0, 0, -z], [0, y, 0], x); f([-1, 0, 0], [0, 0, z], [0, y, 0], x);
      f([0, 1, 0], [x, 0, 0], [0, 0, -z], y); f([0, -1, 0], [x, 0, 0], [0, 0, z], y);
      return g;
    },
    /* a box with softly rounded vertical edges (folded fabric, cushions) */
    softBox(w, h, d, r, seg) {
      r = Math.min(r || 0.02, w / 2, d / 2); seg = seg || 3;
      const pts = roundRect(w, d, r, seg);
      const g = new Geo();
      const top = G.fan(pts.map(([x, z]) => [x, -z]), 0, (x, y) => [x / w + 0.5, y / d + 0.5]);
      g.add(top, M4.chain(M4.trans(0, h / 2, 0), M4.rotX(-Math.PI / 2)));
      const bot = G.fan(pts.map(([x, z]) => [x, z]), 0, (x, y) => [x / w + 0.5, y / d + 0.5], -1);
      g.add(bot, M4.chain(M4.trans(0, -h / 2, 0), M4.rotX(-Math.PI / 2)));
      const side = G.sweep(pts, true, [[0, -h / 2], [0, h / 2]], 1, 1 / w);
      g.add(side, M4.rotX(-Math.PI / 2));
      return g;
    },
    fan(pts, z, uvf, nz) {
      const g = new Geo(); nz = nz || 1;
      let cx = 0, cy = 0; pts.forEach((p) => { cx += p[0]; cy += p[1]; }); cx /= pts.length; cy /= pts.length;
      const uv = uvf || ((x, y) => [x, y]);
      const c = g.v(cx, cy, z, 0, 0, nz, ...uv(cx, cy));
      const ids = pts.map((p) => g.v(p[0], p[1], z, 0, 0, nz, ...uv(p[0], p[1])));
      for (let k = 0; k < ids.length; k++) g.tri(c, ids[k], ids[(k + 1) % ids.length]);
      return g;
    },
    strip(a, b, z, uvf) {
      const g = new Geo(), uv = uvf || ((x, y) => [x, y]);
      const ia = a.map((p) => g.v(p[0], p[1], z, 0, 0, 1, ...uv(p[0], p[1])));
      const ib = b.map((p) => g.v(p[0], p[1], z, 0, 0, 1, ...uv(p[0], p[1])));
      for (let k = 0; k < a.length - 1; k++) g.quad(ia[k], ia[k + 1], ib[k + 1], ib[k]);
      return g;
    },
    /* sweep a 2D profile [offset, z] along a path in the XY plane */
    sweep(path, closed, profile, sign, uvs) {
      const g = new Geo(); sign = sign || 1; uvs = uvs || 1;
      const n = path.length, norms = [], miter = [];
      for (let k = 0; k < n; k++) {
        const pPrev = path[closed ? mod(k - 1, n) : Math.max(0, k - 1)], pNext = path[closed ? mod(k + 1, n) : Math.min(n - 1, k + 1)];
        let tx = pNext[0] - pPrev[0], ty = pNext[1] - pPrev[1]; const tl = Math.hypot(tx, ty) || 1; tx /= tl; ty /= tl;
        norms.push([ty * sign, -tx * sign]);
        const pa = path[closed ? mod(k - 1, n) : Math.max(0, k - 1)], pb = path[k];
        let sx = pb[0] - pa[0], sy = pb[1] - pa[1]; const sl = Math.hypot(sx, sy);
        if (sl < 1e-6) { sx = tx; sy = ty; } else { sx /= sl; sy /= sl; }
        const d = clamp(ty * sign * (sy * sign) + (-tx * sign) * (-sx * sign), 0.5, 1);
        miter.push(1 / d);
      }
      const lens = [0]; for (let k = 1; k < n; k++) lens.push(lens[k - 1] + Math.hypot(path[k][0] - path[k - 1][0], path[k][1] - path[k - 1][1]));
      const segs = closed ? n : n - 1;
      for (let j = 0; j < profile.length - 1; j++) {
        const [o0, z0] = profile[j], [o1, z1] = profile[j + 1];
        let pn = [z1 - z0, -(o1 - o0)]; const pl = Math.hypot(pn[0], pn[1]) || 1; pn = [pn[0] / pl, pn[1] / pl];
        const base = g.p.length / 3;
        for (let k = 0; k < n; k++) {
          const [x, y] = path[k], [nx, ny] = norms[k], m = miter[k];
          const N = V.norm([nx * pn[0], ny * pn[0], pn[1]]);
          g.v(x + nx * o0 * m, y + ny * o0 * m, z0, N[0], N[1], N[2], lens[k] * uvs, j);
          g.v(x + nx * o1 * m, y + ny * o1 * m, z1, N[0], N[1], N[2], lens[k] * uvs, j + 1);
        }
        for (let k = 0; k < segs; k++) { const a = base + k * 2, b = base + ((k + 1) % n) * 2; g.quad(a, b, b + 1, a + 1); }
      }
      return g;
    },
    /* a round tube along any 3D polyline */
    tube(pts, r, seg) {
      const g = new Geo(); seg = seg || 8;
      let prevN = null;
      for (let k = 0; k < pts.length; k++) {
        const a = pts[Math.max(0, k - 1)], b = pts[Math.min(pts.length - 1, k + 1)];
        const t = V.norm(V.sub(b, a));
        let n = prevN ? V.norm(V.sub(prevN, V.mul(t, V.dot(prevN, t)))) : V.norm(V.cross(t, Math.abs(t[1]) < 0.9 ? [0, 1, 0] : [1, 0, 0]));
        prevN = n; const bn = V.cross(t, n);
        for (let s = 0; s <= seg; s++) {
          const ang = (s / seg) * Math.PI * 2, d = V.add(V.mul(n, Math.cos(ang)), V.mul(bn, Math.sin(ang)));
          const p = V.add(pts[k], V.mul(d, r));
          g.v(p[0], p[1], p[2], d[0], d[1], d[2], s / seg, k / (pts.length - 1));
        }
      }
      const row = seg + 1;
      for (let k = 0; k < pts.length - 1; k++) for (let s = 0; s < seg; s++) g.quad(k * row + s, k * row + s + 1, (k + 1) * row + s + 1, (k + 1) * row + s);
      return g;
    },
    cyl(r, h, seg, caps, r2) {
      const g = new Geo(); seg = seg || 20; r2 = r2 == null ? r : r2;
      for (let k = 0; k <= seg; k++) {
        const a = (k / seg) * Math.PI * 2, x = Math.cos(a), z = Math.sin(a);
        g.v(x * r, -h / 2, z * r, x, 0, z, k / seg, 0); g.v(x * r2, h / 2, z * r2, x, 0, z, k / seg, 1);
      }
      for (let k = 0; k < seg; k++) g.quad(k * 2, k * 2 + 2, k * 2 + 3, k * 2 + 1);
      if (caps) [-1, 1].forEach((s) => {
        const rr = s < 0 ? r : r2, c = g.v(0, s * h / 2, 0, 0, s, 0, 0.5, 0.5), base = g.p.length / 3;
        for (let k = 0; k <= seg; k++) { const a = (k / seg) * Math.PI * 2; g.v(Math.cos(a) * rr, s * h / 2, Math.sin(a) * rr, 0, s, 0, 0.5 + Math.cos(a) * 0.5, 0.5 + Math.sin(a) * 0.5); }
        for (let k = 0; k < seg; k++) g.tri(c, base + k, base + k + 1);
      });
      return g;
    },
    lathe(prof, seg) {
      const g = new Geo(); seg = seg || 48;
      for (let j = 0; j < prof.length; j++) {
        const pPrev = prof[Math.max(0, j - 1)], pNext = prof[Math.min(prof.length - 1, j + 1)];
        const dr = pNext[0] - pPrev[0], dy = pNext[1] - pPrev[1];
        const nl = Math.hypot(dr, dy) || 1, nr = dy / nl, ny = -dr / nl;
        for (let k = 0; k <= seg; k++) {
          const a = (k / seg) * Math.PI * 2, c = Math.cos(a), s = Math.sin(a);
          g.v(prof[j][0] * c, prof[j][1], prof[j][0] * s, nr * c, ny, nr * s, k / seg, j / (prof.length - 1));
        }
      }
      const row = seg + 1;
      for (let j = 0; j < prof.length - 1; j++) for (let k = 0; k < seg; k++) g.quad(j * row + k, j * row + k + 1, (j + 1) * row + k + 1, (j + 1) * row + k);
      return g;
    },
    torus(R, r, seg, seg2) {
      const prof = []; seg2 = seg2 || 12;
      for (let k = 0; k <= seg2; k++) { const a = (k / seg2) * Math.PI * 2; prof.push([R + Math.cos(a) * r, Math.sin(a) * r]); }
      return G.lathe(prof, seg || 48);
    },
    disc(r, seg, z) {
      const pts = []; seg = seg || 48;
      for (let k = 0; k < seg; k++) { const a = (k / seg) * Math.PI * 2; pts.push([Math.cos(a) * r, Math.sin(a) * r]); }
      return G.fan(pts, z || 0, (x, y) => [x / (2 * r) + 0.5, y / (2 * r) + 0.5]);
    },
    /* a room-facing wall rectangle with an arched hole cut from y=ab upward */
    wallWithArch(x0, x1, y0, y1, aw, ab, spring, uvs, seg, cx) {
      const g = new Geo(), r = aw / 2; seg = seg || 32; uvs = uvs || 1; cx = cx || 0;
      const uv = (x, y) => [x * uvs, y * uvs];
      if (ab > y0) g.add(G.rect(x0, y0, x1, ab, 0, uvs));
      g.add(G.rect(x0, ab, cx - r, y1, 0, uvs));
      g.add(G.rect(cx + r, ab, x1, y1, 0, uvs));
      const lo = [], hi = [];
      for (let k = 0; k <= seg; k++) { const x = -r + (k / seg) * aw; lo.push([cx + x, ab + spring + Math.sqrt(Math.max(0, r * r - x * x))]); hi.push([cx + x, y1]); }
      g.add(G.strip(lo, hi, 0, uv));
      return g;
    }
  };
  function archPath(w, spring, seg, y0, cx) {
    const r = w / 2, pts = []; y0 = y0 || 0; seg = seg || 40; cx = cx || 0;
    pts.push([cx - r, y0]);
    for (let k = 0; k <= seg; k++) { const a = Math.PI - (k / seg) * Math.PI; pts.push([cx + Math.cos(a) * r, y0 + spring + Math.sin(a) * r]); }
    pts.push([cx + r, y0]);
    return pts;
  }
  function roundRect(w, h, r, seg) {
    const pts = [], x = w / 2 - r, y = h / 2 - r; seg = seg || 4;
    [[x, y, 0], [-x, y, 90], [-x, -y, 180], [x, -y, 270]].forEach(([cx, cy, a0]) => {
      for (let k = 0; k <= seg; k++) { const a = (a0 + (k / seg) * 90) * D2R; pts.push([cx + Math.cos(a) * r, cy + Math.sin(a) * r]); }
    });
    return pts;
  }
  function crescentPts(r, seg) {
    const outer = [], inner = [], ir = 0.8 * r, oc = [0.44 * r, 0.22 * r];
    const inside = (x, y) => Math.hypot(x - oc[0], y - oc[1]) < ir;
    const samples = 720; let start = 0;
    for (let k = 0; k < samples; k++) { const a = (k / samples) * Math.PI * 2; if (inside(Math.cos(a) * r, Math.sin(a) * r) && !inside(Math.cos(a + 0.01) * r, Math.sin(a + 0.01) * r)) { start = a + 0.01; break; } }
    let end = start; for (let k = 1; k < samples; k++) { const a = start + (k / samples) * Math.PI * 2; if (inside(Math.cos(a) * r, Math.sin(a) * r)) { end = a; break; } }
    const pA = [Math.cos(start) * r, Math.sin(start) * r], pB = [Math.cos(end) * r, Math.sin(end) * r];
    const aA = Math.atan2(pA[1] - oc[1], pA[0] - oc[0]), aB = Math.atan2(pB[1] - oc[1], pB[0] - oc[0]);
    for (let k = 0; k <= seg; k++) { const a = lerp(start, end, k / seg); outer.push([Math.cos(a) * r, Math.sin(a) * r]); }
    let d = aB - aA; while (d > Math.PI) d -= Math.PI * 2; while (d < -Math.PI) d += Math.PI * 2;
    const inOuter = (a) => Math.hypot(oc[0] + Math.cos(a) * ir, oc[1] + Math.sin(a) * ir) < r;
    if (!inOuter(aA + d / 2) && inOuter(aA + d / 2 + Math.PI)) d = d > 0 ? d - Math.PI * 2 : d + Math.PI * 2;
    for (let k = 0; k <= seg; k++) { const a = aA + d * (k / seg); inner.push([oc[0] + Math.cos(a) * ir, oc[1] + Math.sin(a) * ir]); }
    return { outer, inner };
  }
  function crescentSolid(r, depth) {
    const { outer, inner } = crescentPts(r, 48), g = new Geo();
    const front = G.strip(outer, inner, depth / 2, (x, y) => [x, y]);
    const back = G.strip(inner, outer, -depth / 2, (x, y) => [x, y]);
    for (let k = 0; k < back.n.length; k += 3) back.n[k + 2] = -1;
    g.add(front); g.add(back);
    g.add(G.sweep(outer.concat(inner.slice().reverse()), true, [[0, -depth / 2], [0, depth / 2]], 1));
    return g;
  }
  const PROF = {
    casing: [[0, 0.002], [0, 0.03], [0.025, 0.04], [0.05, 0.04], [0.06, 0.058], [0.15, 0.058], [0.17, 0.05], [0.2, 0.03], [0.22, 0.012], [0.22, 0.002]],
    bead: (() => { const b = []; for (let k = 0; k <= 8; k++) { const a = (k / 8) * Math.PI; b.push([0.03 + 0.012 - Math.cos(a) * 0.012, 0.039 + Math.sin(a) * 0.012]); } return b; })(),
    panel: [[-0.03, 0.001], [-0.02, 0.016], [0, 0.022], [0.02, 0.016], [0.03, 0.001]],
    rail: [[0, 0], [0.02, 0.02], [0.03, 0.035], [0.05, 0.02], [0.06, 0]],
    cornice: [[0, 0], [0.03, 0.02], [0.05, 0.06], [0.1, 0.1], [0.16, 0.14], [0.2, 0.25], [0.2, 0.26]],
    frame: [[-0.03, 0], [-0.028, 0.018], [-0.012, 0.028], [0, 0.022], [0.004, 0.008], [0.004, 0]]
  };

  /* ------------------------------------------------------------- shaders */
  const VS = `#version 300 es
  precision highp float; precision highp int;
  in vec3 aPos; in vec3 aNor; in vec2 aUv;
  uniform mat4 uModel, uVP; uniform vec2 uUvScale; uniform vec2 uUvOff; uniform int uMode;
  out vec3 vW; out vec3 vN; out vec2 vUv;
  void main(){
    vUv = aUv * uUvScale + uUvOff;
    if (uMode == 4) { vW = vec3(0.); vN = vec3(0.,0.,1.); gl_Position = vec4(aPos.xy, 0., 1.); return; }
    vec4 w = uModel * vec4(aPos,1.); vW = w.xyz; vN = mat3(uModel) * aNor; gl_Position = uVP * w;
  }`;
  const FS = `#version 300 es
  precision highp float; precision highp int;
  in vec3 vW; in vec3 vN; in vec2 vUv;
  uniform int uMode; uniform vec3 uColor; uniform sampler2D uMap; uniform bool uHasMap; uniform bool uAlphaMap;
  uniform float uRough, uMetal, uOpacity, uEnvI, uEmisMap; uniform vec3 uEmis;
  uniform vec3 uCam, uSky, uGnd, uKeyDir, uKeyCol;
  uniform int uNL; uniform vec4 uLP[8]; uniform vec3 uLC[8];
  uniform float uExpo; uniform vec4 uFog; uniform vec3 uFogCol;
  out vec4 oCol;
  const float PI = 3.14159265;
  vec3 aces(vec3 x){ return clamp((x*(2.51*x+.03))/(x*(2.43*x+.59)+.14),0.,1.); }
  vec3 envc(vec3 r, float ro){
    float y = r.y;
    vec3 top = vec3(1.05,.9,.78), hor = vec3(.78,.55,.55), bot = vec3(.16,.1,.09);
    vec3 c = y > 0. ? mix(hor, top, smoothstep(0.,.7,y)) : mix(hor, bot, smoothstep(0.,.5,-y));
    c += vec3(2.2,1.75,1.3) * pow(max(0., 1. - abs(y - .3) * 3.), 8.) * (1. - ro);
    return mix(c, vec3(.55,.42,.4), ro * .6);
  }
  vec3 outc(vec3 c){ return pow(aces(c * uExpo), vec3(1./2.2)); }
  void main(){
    vec4 tx = uHasMap ? texture(uMap, vUv) : vec4(1.);
    float alpha = uOpacity * (uAlphaMap ? tx.a : 1.);
    if (uAlphaMap && alpha < .02) discard;
    if (uMode == 3) { oCol = vec4(0.,0.,0., tx.r * uOpacity); return; }
    if (uMode == 4) { oCol = vec4(pow(uColor, vec3(1./2.2)), uOpacity); return; }
    vec3 base = uColor * (uAlphaMap ? tx.rgb / max(tx.a, .004) : tx.rgb);
    if (uMode == 1 || uMode == 2) {
      vec3 c = outc(base);
      oCol = uMode == 2 ? vec4(c * uOpacity, 1.) : vec4(c, alpha);
      return;
    }
    vec3 N = normalize(vN), Vv = normalize(uCam - vW);
    if (dot(N, Vv) < 0.) N = -N;
    float a = max(uRough * uRough, .03), a2 = a * a;
    bool spec = uRough < .78;
    vec3 F0 = mix(vec3(.04), base, uMetal), dif = base * (1. - uMetal);
    float NoV = max(dot(N, Vv), .001);
    vec3 col = dif * mix(uGnd, uSky, N.y * .5 + .5);
    for (int i = 0; i < 9; i++) {
      vec3 L; vec3 C;
      if (i == 8) { L = normalize(-uKeyDir); C = uKeyCol; }
      else {
        if (i >= uNL) continue;
        vec3 d = uLP[i].xyz - vW; float dist = length(d);
        if (dist > uLP[i].w) continue;
        L = d / dist;
        float att = pow(clamp(1. - pow(dist / uLP[i].w, 4.), 0., 1.), 2.) / (dist * dist * .5 + 1.);
        C = uLC[i] * att;
      }
      float NoL = max(dot(N, L), 0.); if (NoL <= 0.) continue;
      vec3 lit = dif / PI * 3.0;
      if (spec) {
        vec3 H = normalize(L + Vv); float NoH = max(dot(N, H), 0.);
        float dd = NoH * NoH * (a2 - 1.) + 1.; float D = a2 / (PI * dd * dd);
        vec3 F = F0 + (1. - F0) * pow(1. - max(dot(H, Vv), 0.), 5.);
        float k = a * .5; float Gv = NoV / (NoV * (1. - k) + k), Gl = NoL / (NoL * (1. - k) + k);
        lit += D * F * Gv * Gl / (4. * NoV * NoL + .001);
      }
      col += lit * C * NoL;
    }
    vec3 R = reflect(-Vv, N);
    vec3 Fe = F0 + (max(vec3(1. - uRough), F0) - F0) * pow(1. - NoV, 5.);
    col += envc(R, uRough) * Fe * uEnvI;
    col += uEmis * (uEmisMap > .5 ? tx.rgb : vec3(1.));
    if (uFog.w > 0.) { float f = clamp((length(uCam - vW) - uFog.x) / (uFog.y - uFog.x), 0., 1.) * uFog.w; col = mix(col, uFogCol, f); }
    oCol = vec4(outc(col), alpha);
  }`;

  /* ------------------------------------------------------------ textures */
  function cnv(w, h) { const c = document.createElement("canvas"); c.width = w; c.height = h; return c; }
  function rng(seed) { let s = seed >>> 0; return () => { s = (s * 1664525 + 1013904223) >>> 0; return s / 4294967296; }; }
  function speckle(ctx, w, h, n, alpha, seed, col) {
    const r = rng(seed);
    for (let k = 0; k < n; k++) { ctx.fillStyle = col || (r() > 0.5 ? `rgba(255,255,255,${alpha * r()})` : `rgba(90,60,40,${alpha * r()})`); ctx.fillRect(r() * w, r() * h, 1 + r() * 2, 1 + r() * 2); }
  }
  function softNoise(ctx, w, h, seed, blobs, color, alpha) {
    const r = rng(seed);
    for (let k = 0; k < blobs; k++) {
      const x = r() * w, y = r() * h, rad = 20 + r() * w * 0.25;
      const gr = ctx.createRadialGradient(x, y, 0, x, y, rad);
      gr.addColorStop(0, color.replace("A", String(alpha * r()))); gr.addColorStop(1, color.replace("A", "0"));
      ctx.fillStyle = gr; ctx.fillRect(x - rad, y - rad, rad * 2, rad * 2);
    }
  }
  function crescentPath(x, cx, cy, r) { x.beginPath(); x.arc(cx, cy, r, 0, Math.PI * 2); x.arc(cx + r * 0.42, cy - r * 0.24, r * 0.82, 0, Math.PI * 2, true); }
  const TX = {
    plaster(base, seed) {
      const c = cnv(512, 512), x = c.getContext("2d");
      x.fillStyle = base; x.fillRect(0, 0, 512, 512);
      softNoise(x, 512, 512, seed || 7, 40, "rgba(255,255,255,A)", 0.25);
      softNoise(x, 512, 512, (seed || 7) + 3, 30, "rgba(140,100,80,A)", 0.05);
      speckle(x, 512, 512, 2500, 0.08, 11);
      return c;
    },
    wallpaper(a, b, line) {
      a = a || "#f9e2e9"; b = b || "#f6d6e0"; line = line || "rgba(184,149,90,.35)";
      const c = cnv(512, 512), x = c.getContext("2d");
      x.fillStyle = a; x.fillRect(0, 0, 512, 512);
      for (let k = 0; k < 8; k++) { x.fillStyle = k % 2 ? b : a; x.fillRect(k * 64, 0, 64, 512); x.fillStyle = line; x.fillRect(k * 64 + 31, 0, 1.5, 512); }
      x.fillStyle = line;
      for (let k = 0; k < 8; k++) for (let j = 0; j < 4; j++) { const cx = k * 64 + 32, cy = j * 128 + (k % 2 ? 96 : 32); crescentPath(x, cx, cy, 5); x.fill("evenodd"); }
      softNoise(x, 512, 512, 21, 30, "rgba(255,255,255,A)", 0.18);
      speckle(x, 512, 512, 1600, 0.05, 5);
      return c;
    },
    marble(size, seed) {
      size = size || 1024; const c = cnv(size, size), x = c.getContext("2d");
      x.fillStyle = "#f3ece2"; x.fillRect(0, 0, size, size);
      softNoise(x, size, size, seed || 3, 70, "rgba(255,252,246,A)", 0.6);
      softNoise(x, size, size, (seed || 3) + 1, 40, "rgba(200,170,150,A)", 0.12);
      const r = rng((seed || 3) * 9); x.lineCap = "round";
      for (let v = 0; v < 14; v++) {
        let px = r() * size, py = r() * size, ang = r() * Math.PI * 2;
        x.strokeStyle = `rgba(150,118,100,${0.05 + r() * 0.12})`; x.lineWidth = 0.6 + r() * 1.8;
        x.beginPath(); x.moveTo(px, py);
        for (let s = 0; s < 60; s++) { ang += (r() - 0.5) * 0.6; px += Math.cos(ang) * size * 0.02; py += Math.sin(ang) * size * 0.02; x.lineTo(px, py); }
        x.stroke();
      }
      x.strokeStyle = "rgba(170,140,115,.28)"; x.lineWidth = 2;
      for (let k = 0; k <= 2; k++) { const p = (k / 2) * size; x.beginPath(); x.moveTo(p, 0); x.lineTo(p, size); x.moveTo(0, p); x.lineTo(size, p); x.stroke(); }
      return c;
    },
    stone() {
      const s = 1024, c = cnv(s, s), x = c.getContext("2d");
      x.fillStyle = "#efe6d6"; x.fillRect(0, 0, s, s);
      softNoise(x, s, s, 41, 60, "rgba(255,250,240,A)", 0.5);
      softNoise(x, s, s, 42, 30, "rgba(170,140,110,A)", 0.1);
      speckle(x, s, s, 9000, 0.08, 43);
      x.strokeStyle = "rgba(160,130,100,.35)"; x.lineWidth = 2.5;
      for (let k = -2; k <= 4; k++) { x.beginPath(); x.moveTo(k * s / 2, 0); x.lineTo(k * s / 2 + s, s); x.stroke(); x.beginPath(); x.moveTo(k * s / 2 + s, 0); x.lineTo(k * s / 2, s); x.stroke(); }
      return c;
    },
    wood(tone, seed) {
      const W = 1024, H = 1024, c = cnv(W, H), x = c.getContext("2d"), r = rng(seed || 17);
      x.fillStyle = tone || "#c9a07a"; x.fillRect(0, 0, W, H);
      const plank = 128;
      for (let k = 0; k < W / plank; k++) {
        const shade = (r() - 0.5) * 0.14;
        x.fillStyle = shade > 0 ? `rgba(255,240,220,${shade})` : `rgba(80,45,25,${-shade})`;
        x.fillRect(k * plank, 0, plank, H);
        for (let g = 0; g < 26; g++) {
          x.strokeStyle = `rgba(90,55,30,${0.04 + r() * 0.08})`; x.lineWidth = 0.6 + r() * 1.6;
          const gx = k * plank + r() * plank; x.beginPath(); x.moveTo(gx, 0);
          for (let y = 0; y <= H; y += 32) x.lineTo(gx + Math.sin(y * 0.01 + g) * 3 + (r() - 0.5) * 2, y);
          x.stroke();
        }
        x.fillStyle = "rgba(70,40,20,.35)"; x.fillRect(k * plank, 0, 2, H);
        const joint = r() * H; x.fillRect(k * plank, joint, plank, 2);
      }
      speckle(x, W, H, 4000, 0.05, 9);
      return c;
    },
    rug() {
      const s = 1024, c = cnv(s, s), x = c.getContext("2d"), m = s / 2;
      x.fillStyle = "#f2d3dc"; x.fillRect(0, 0, s, s);
      const ring = (r, w, col) => { x.strokeStyle = col; x.lineWidth = w; x.beginPath(); x.arc(m, m, r, 0, Math.PI * 2); x.stroke(); };
      const gr = x.createRadialGradient(m, m, 0, m, m, m); gr.addColorStop(0, "#f7dfe6"); gr.addColorStop(1, "#efc7d3"); x.fillStyle = gr;
      x.beginPath(); x.arc(m, m, m, 0, Math.PI * 2); x.fill();
      ring(m - 26, 40, "#6e2135"); ring(m - 52, 3, "#c9a46c"); ring(m - 70, 2, "#6e2135");
      x.fillStyle = "#6e2135";
      for (let k = 0; k < 36; k++) {
        const a = (k / 36) * Math.PI * 2, cx = m + Math.cos(a) * (m - 105), cy = m + Math.sin(a) * (m - 105);
        x.save(); x.translate(cx, cy); x.rotate(a + Math.PI / 2); crescentPath(x, 0, 0, 11); x.fill("evenodd"); x.restore();
      }
      ring(m - 140, 2, "#c9a46c");
      x.fillStyle = "#6e2135"; crescentPath(x, m, m, 70); x.fill("evenodd");
      ring(110, 2, "#c9a46c");
      speckle(x, s, s, 16000, 0.06, 77);
      return c;
    },
    runner(len) { // a long rug for the gallery
      const W = 512, H = 2048, c = cnv(W, H), x = c.getContext("2d");
      x.fillStyle = "#efc9d3"; x.fillRect(0, 0, W, H);
      x.strokeStyle = "#6e2135"; x.lineWidth = 26; x.strokeRect(20, 20, W - 40, H - 40);
      x.strokeStyle = "#c9a46c"; x.lineWidth = 3; x.strokeRect(52, 52, W - 104, H - 104);
      x.fillStyle = "#6e2135";
      for (let k = 0; k < 9; k++) { const cy = 200 + k * ((H - 400) / 8); crescentPath(x, W / 2, cy, 34); x.fill("evenodd"); }
      speckle(x, W, H, 16000, 0.06, 71);
      return c;
    },
    glow(inner, outer) {
      const c = cnv(128, 128), x = c.getContext("2d");
      const g = x.createRadialGradient(64, 64, 0, 64, 64, 64);
      g.addColorStop(0, inner || "#fff"); g.addColorStop(0.35, "rgba(255,255,255,.35)"); g.addColorStop(1, outer || "#000");
      x.fillStyle = "#000"; x.fillRect(0, 0, 128, 128); x.fillStyle = g; x.fillRect(0, 0, 128, 128);
      return c;
    },
    beam() { // a soft vertical light shaft
      const c = cnv(64, 256), x = c.getContext("2d");
      x.fillStyle = "#000"; x.fillRect(0, 0, 64, 256);
      const gh = x.createLinearGradient(0, 0, 64, 0); gh.addColorStop(0, "rgba(255,255,255,0)"); gh.addColorStop(0.5, "rgba(255,255,255,1)"); gh.addColorStop(1, "rgba(255,255,255,0)");
      x.fillStyle = gh; x.fillRect(0, 0, 64, 256);
      x.globalCompositeOperation = "multiply";
      const gv = x.createLinearGradient(0, 0, 0, 256); gv.addColorStop(0, "#000"); gv.addColorStop(0.25, "#fff"); gv.addColorStop(1, "#222");
      x.fillStyle = gv; x.fillRect(0, 0, 64, 256);
      return c;
    },
    shadowRect(blur, inset) {
      const c = cnv(256, 256), x = c.getContext("2d"); inset = inset || 60;
      x.fillStyle = "#000"; x.fillRect(0, 0, 256, 256);
      x.filter = `blur(${blur || 22}px)`; x.fillStyle = "#fff"; x.fillRect(inset, inset, 256 - inset * 2, 256 - inset * 2); x.filter = "none";
      return c;
    },
    shadowDisc() {
      const c = cnv(256, 256), x = c.getContext("2d"), g = x.createRadialGradient(128, 128, 10, 128, 128, 126);
      g.addColorStop(0, "#fff"); g.addColorStop(0.55, "rgba(255,255,255,.55)"); g.addColorStop(1, "#000");
      x.fillStyle = "#000"; x.fillRect(0, 0, 256, 256); x.fillStyle = g; x.fillRect(0, 0, 256, 256); return c;
    },
    gradV(stops) {
      const c = cnv(4, 128), x = c.getContext("2d"), g = x.createLinearGradient(0, 0, 0, 128);
      stops.forEach(([o, v]) => g.addColorStop(o, `rgb(${v},${v},${v})`)); x.fillStyle = g; x.fillRect(0, 0, 4, 128); return c;
    },
    alcoveBack() {
      const c = cnv(512, 1024), x = c.getContext("2d");
      x.fillStyle = "#f4cfda"; x.fillRect(0, 0, 512, 1024);
      for (let k = 0; k < 8; k++) { x.fillStyle = k % 2 ? "rgba(255,255,255,.14)" : "rgba(255,255,255,0)"; x.fillRect(k * 64, 0, 64, 1024); }
      const g = x.createRadialGradient(256, 330, 10, 256, 420, 520);
      g.addColorStop(0, "rgba(255,248,240,.95)"); g.addColorStop(0.45, "rgba(255,236,236,.35)"); g.addColorStop(1, "rgba(120,40,60,.28)");
      x.fillStyle = g; x.fillRect(0, 0, 512, 1024);
      const s = x.createLinearGradient(0, 0, 512, 0);
      s.addColorStop(0, "rgba(110,33,53,.18)"); s.addColorStop(0.18, "rgba(110,33,53,0)"); s.addColorStop(0.82, "rgba(110,33,53,0)"); s.addColorStop(1, "rgba(110,33,53,.18)");
      x.fillStyle = s; x.fillRect(0, 0, 512, 1024);
      return c;
    },
    sky() { // a soft glowing ceiling medallion / skylight
      const c = cnv(256, 256), x = c.getContext("2d");
      const g = x.createRadialGradient(128, 110, 0, 128, 128, 180); g.addColorStop(0, "#fff7f2"); g.addColorStop(1, "#f1c6d2");
      x.fillStyle = g; x.fillRect(0, 0, 256, 256); return c;
    },
    windowGlass() { // morning light through sheer curtains
      const W = 256, H = 512, c = cnv(W, H), x = c.getContext("2d");
      const g = x.createLinearGradient(0, 0, 0, H); g.addColorStop(0, "#fffdf8"); g.addColorStop(0.6, "#fff3ea"); g.addColorStop(1, "#f8dcd8");
      x.fillStyle = g; x.fillRect(0, 0, W, H);
      for (let k = 0; k < 18; k++) { x.fillStyle = `rgba(240,200,200,${0.05 + (k % 3) * 0.03})`; x.fillRect(k * (W / 18), 0, W / 36, H); }
      return c;
    },
    mat(base, w, h) {
      w = w || 768; h = h || 1024;
      const c = cnv(w, h), x = c.getContext("2d");
      x.fillStyle = base || "#fbf6ee"; x.fillRect(0, 0, w, h);
      x.globalAlpha = 0.05;
      for (let k = 0; k < h; k += 3) { x.fillStyle = k % 2 ? "#7a5d64" : "#fff"; x.fillRect(0, k, w, 1); }
      for (let k = 0; k < w; k += 3) { x.fillStyle = k % 2 ? "#7a5d64" : "#fff"; x.fillRect(k, 0, 1, h); }
      x.globalAlpha = 1;
      return c;
    },
    weave(base) {
      const s = 256, c = cnv(s, s), x = c.getContext("2d");
      x.fillStyle = base || "#fbf3ef"; x.fillRect(0, 0, s, s);
      for (let k = 0; k < s; k += 2) { x.fillStyle = k % 4 ? "rgba(255,255,255,.12)" : "rgba(120,80,80,.06)"; x.fillRect(0, k, s, 1); x.fillRect(k, 0, 1, s); }
      return c;
    },
    thread(hex) {
      const W = 64, H = 128, c = cnv(W, H), x = c.getContext("2d");
      x.fillStyle = hex; x.fillRect(0, 0, W, H);
      for (let k = 0; k < H; k += 2) { x.fillStyle = k % 4 ? "rgba(255,255,255,.18)" : "rgba(0,0,0,.12)"; x.fillRect(0, k, W, 1); }
      const g = x.createLinearGradient(0, 0, W, 0); g.addColorStop(0, "rgba(0,0,0,.08)"); g.addColorStop(0.5, "rgba(255,255,255,.12)"); g.addColorStop(1, "rgba(0,0,0,.08)");
      x.fillStyle = g; x.fillRect(0, 0, W, H);
      return c;
    },
    giftPaper(base, acc) {
      const s = 512, c = cnv(s, s), x = c.getContext("2d");
      /* plain satin paper: a soft vertical sheen, one thin gold hairline frame
         and a single small wax seal — no pattern, nothing cartoonish */
      const g = x.createLinearGradient(0, 0, s, s);
      g.addColorStop(0, base); g.addColorStop(0.45, mixHex(base, "#ffffff", 0.16)); g.addColorStop(1, mixHex(base, "#000000", 0.06));
      x.fillStyle = g; x.fillRect(0, 0, s, s);
      x.strokeStyle = acc; x.globalAlpha = 0.5; x.lineWidth = 2;
      x.strokeRect(26, 26, s - 52, s - 52);
      x.globalAlpha = 1;
      x.fillStyle = acc; x.beginPath(); x.arc(s / 2, s / 2, 26, 0, Math.PI * 2); x.fill();
      x.fillStyle = mixHex(acc, "#ffffff", 0.55); x.beginPath(); x.arc(s / 2 - 6, s / 2 - 6, 9, 0, Math.PI * 2); x.fill();
      speckle(x, s, s, 700, 0.012, 33);
      return c;
    }
  };

  /* -------------------------------------------------- image helpers */
  const svgImg = (svg, w, h) => new Promise((res, rej) => {
    let s = svg.replace(/^<svg /, `<svg width="${w}" height="${h}" `);
    const img = new Image(); img.decoding = "async"; img.onload = () => res(img); img.onerror = rej;
    img.src = "data:image/svg+xml;charset=utf-8," + encodeURIComponent(s);
  });
  const imgCache = new Map();
  const loadImg = (src) => {
    if (imgCache.has(src)) return imgCache.get(src);
    const p = new Promise((res, rej) => { const i = new Image(); i.decoding = "async"; i.onload = () => res(i); i.onerror = rej; i.src = src; });
    imgCache.set(src, p); p.catch(() => imgCache.delete(src));
    return p;
  };
  /* rasterise an SVG string and crop to what is drawn (returns canvas + box) */
  async function artCanvas(svg, maxW) {
    if (typeof svg !== "string" || !svg) return Promise.reject(new Error("sprite: no svg"));
    const vb = (svg.match(/viewBox="([^"]+)"/) || [])[1];
    const p = vb ? vb.split(/\s+/).map(Number) : [0, 0, 300, 420];
    const rw = maxW || 900, rh = Math.max(1, Math.round(rw * p[3] / p[2]));
    const img = await svgImg(svg, rw, rh);
    const tmp = cnv(rw, rh), tx = tmp.getContext("2d"); tx.drawImage(img, 0, 0, rw, rh);
    let data; try { data = tx.getImageData(0, 0, rw, rh).data; } catch (e) { return { c: tmp, x0: 0, y0: 0, w: rw, h: rh }; }
    let x0 = rw, y0 = rh, x1 = 0, y1 = 0;
    for (let yy = 0; yy < rh; yy += 2) for (let xx = 0; xx < rw; xx += 2) if (data[(yy * rw + xx) * 4 + 3] > 20) { if (xx < x0) x0 = xx; if (xx > x1) x1 = xx; if (yy < y0) y0 = yy; if (yy > y1) y1 = yy; }
    if (x1 <= x0) { x0 = 0; y0 = 0; x1 = rw - 1; y1 = rh - 1; }
    return { c: tmp, x0, y0, w: x1 - x0 + 1, h: y1 - y0 + 1 };
  }
  function drawContain(x, src, sx, sy, sw, sh, bx, by, bw, bh, align) {
    const r = Math.min(bw / sw, bh / sh), dw = sw * r, dh = sh * r;
    const dx = bx + (bw - dw) / 2, dy = align === "top" ? by : align === "bottom" ? by + bh - dh : by + (bh - dh) / 2;
    x.drawImage(src, sx, sy, sw, sh, dx, dy, dw, dh);
    return { dx, dy, dw, dh };
  }
  function drawCover(x, img, bx, by, bw, bh) {
    const r = Math.max(bw / img.width, bh / img.height), dw = img.width * r, dh = img.height * r;
    x.save(); x.beginPath(); x.rect(bx, by, bw, bh); x.clip(); x.drawImage(img, bx + (bw - dw) / 2, by + (bh - dh) / 2, dw, dh); x.restore();
  }

  /* ------------------------------------------------------------- engine */
  const rooms = {};

  function create(canvas, opts) {
    opts = opts || {};
    const lite = !!opts.lite;
    const gl = canvas.getContext("webgl2", { antialias: true, alpha: false, powerPreference: "high-performance", preserveDrawingBuffer: !!opts.preserve });
    if (!gl) throw new Error("webgl2");
    const aniso = gl.getExtension("EXT_texture_filter_anisotropic");
    const maxAniso = aniso ? Math.min(8, gl.getParameter(aniso.MAX_TEXTURE_MAX_ANISOTROPY_EXT)) : 0;

    function sh(type, src) { const s = gl.createShader(type); gl.shaderSource(s, src); gl.compileShader(s); if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(s)); return s; }
    const prog = gl.createProgram();
    gl.attachShader(prog, sh(gl.VERTEX_SHADER, VS)); gl.attachShader(prog, sh(gl.FRAGMENT_SHADER, FS));
    gl.bindAttribLocation(prog, 0, "aPos"); gl.bindAttribLocation(prog, 1, "aNor"); gl.bindAttribLocation(prog, 2, "aUv");
    gl.linkProgram(prog);
    if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(prog));
    gl.useProgram(prog);
    const U = {};
    ["uModel", "uVP", "uUvScale", "uUvOff", "uMode", "uColor", "uMap", "uHasMap", "uAlphaMap", "uRough", "uMetal", "uOpacity", "uEnvI", "uEmisMap", "uEmis", "uCam", "uSky", "uGnd", "uKeyDir", "uKeyCol", "uNL", "uLP", "uLC", "uExpo", "uFog", "uFogCol"]
      .forEach((n) => { U[n] = gl.getUniformLocation(prog, n); });
    gl.uniform1i(U.uMap, 0);

    function upload(g) {
      const vao = gl.createVertexArray(); gl.bindVertexArray(vao);
      const buf = (data, loc, size) => { const b = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, b); gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(data), gl.STATIC_DRAW); gl.enableVertexAttribArray(loc); gl.vertexAttribPointer(loc, size, gl.FLOAT, false, 0, 0); return b; };
      const bufs = [buf(g.p, 0, 3), buf(g.n, 1, 3), buf(g.u, 2, 2)];
      const ib = gl.createBuffer(); gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, ib); gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, new Uint32Array(g.i), gl.STATIC_DRAW);
      gl.bindVertexArray(null);
      return { vao, n: g.i.length, bufs, ib };
    }
    const textures = new Set();
    function tex(src, o) {
      o = o || {};
      const t = gl.createTexture(); gl.bindTexture(gl.TEXTURE_2D, t);
      gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, true);
      gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL, !!o.premul);
      gl.texImage2D(gl.TEXTURE_2D, 0, o.linear ? gl.RGBA8 : gl.SRGB8_ALPHA8, gl.RGBA, gl.UNSIGNED_BYTE, src);
      gl.generateMipmap(gl.TEXTURE_2D);
      const wrap = o.clamp ? gl.CLAMP_TO_EDGE : gl.REPEAT;
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, wrap); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, wrap);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR_MIPMAP_LINEAR); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
      if (maxAniso) gl.texParameterf(gl.TEXTURE_2D, aniso.TEXTURE_MAX_ANISOTROPY_EXT, maxAniso);
      textures.add(t);
      return t;
    }
    function dropTex(t) { if (t && textures.has(t)) { gl.deleteTexture(t); textures.delete(t); } }

    const MAT = (o) => Object.assign({ mode: 0, color: [1, 1, 1], map: null, alphaMap: false, rough: 0.6, metal: 0, env: 0.35, emis: [0, 0, 0], emisMap: 0, opacity: 1, uv: [1, 1], uvOff: [0, 0], blend: 0 }, o);

    /* shared textures and materials (every room draws from the same palette) */
    const T = {
      plaster: tex(TX.plaster("#f6efe2", 7)),
      plasterWarm: tex(TX.plaster("#f2e8d8", 13)),
      wallpaper: tex(TX.wallpaper()),
      marble: tex(TX.marble(lite ? 512 : 1024, 3)),
      stone: tex(TX.stone()),
      wood: tex(TX.wood("#dcc0a0", 17)),
      woodDark: tex(TX.wood("#8a5a3c", 23)),
      rug: tex(TX.rug(), { clamp: true }),
      glow: tex(TX.glow(), { clamp: true }),
      beam: tex(TX.beam(), { clamp: true }),
      shadow: tex(TX.shadowRect(24), { clamp: true, linear: true }),
      shadowSoft: tex(TX.shadowRect(34, 40), { clamp: true, linear: true }),
      shadowDisc: tex(TX.shadowDisc(), { clamp: true, linear: true }),
      aoUp: tex(TX.gradV([[0, 0], [0.55, 40], [1, 255]]), { clamp: true, linear: true }),
      alcove: tex(TX.alcoveBack(), { clamp: true }),
      sky: tex(TX.sky(), { clamp: true }),
      window: tex(TX.windowGlass(), { clamp: true }),
      mat: tex(TX.mat(), { clamp: true }),
      weave: tex(TX.weave())
    };
    const GOLD = [0.78, 0.5, 0.22];
    const M = {
      plaster: MAT({ map: T.plaster, uv: [0.45, 0.45], rough: 0.85, env: 0.12 }),
      plasterIn: MAT({ map: T.plasterWarm, uv: [0.45, 0.45], rough: 0.8, env: 0.12, color: [0.98, 0.94, 0.9] }),
      lacquer: MAT({ map: T.plaster, uv: [0.8, 0.8], color: [1.0, 0.96, 0.9], rough: 0.32, env: 0.5 }),
      moulding: MAT({ color: lin("#f6eedf"), rough: 0.38, env: 0.45 }),
      wallpaper: MAT({ map: T.wallpaper, uv: [1 / 0.62, 1 / 0.62], rough: 0.8, env: 0.12 }),
      gold: MAT({ color: GOLD, rough: 0.26, metal: 1, env: 1.15 }),
      goldSoft: MAT({ color: GOLD, rough: 0.42, metal: 1, env: 0.95 }),
      marble: MAT({ map: T.marble, uv: [1 / 1.2, 1 / 1.2], color: [0.84, 0.76, 0.71], rough: 0.2, env: 0.55 }),
      stone: MAT({ map: T.stone, uv: [1 / 2.4, 1 / 2.4], color: [0.9, 0.84, 0.78], rough: 0.42, env: 0.35 }),
      wood: MAT({ map: T.wood, uv: [1 / 3.2, 1 / 3.2], color: [0.9, 0.84, 0.8], rough: 0.45, env: 0.32 }),
      woodFurn: MAT({ map: T.woodDark, uv: [1 / 1.6, 1 / 1.6], color: [0.95, 0.86, 0.8], rough: 0.4, env: 0.35 }),
      rug: MAT({ map: T.rug, rough: 0.95, env: 0.04 }),
      alcove: MAT({ map: T.alcove, rough: 0.9, env: 0.06, emis: [0.035, 0.025, 0.025], emisMap: 1 }),
      reveal: MAT({ color: lin("#e8c9d1"), rough: 0.8, env: 0.1 }),
      jamb: MAT({ color: lin("#e6d8c4"), rough: 0.6, env: 0.2 }),
      ceiling: MAT({ map: T.plaster, uv: [0.3, 0.3], color: [1.0, 0.97, 0.94], rough: 0.9, env: 0.05, emis: [0.34, 0.3, 0.28], emisMap: 1 }),
      skylight: MAT({ mode: 1, map: T.sky, color: [1.0, 0.95, 0.93] }),
      window: MAT({ mode: 1, map: T.window, color: [1.15, 1.08, 1.04] }),
      velvet: MAT({ color: lin("#6e2135"), rough: 0.7, env: 0.25 }),
      velvetBlush: MAT({ color: lin("#e9aebe"), rough: 0.85, env: 0.15 }),
      cream: MAT({ color: lin("#f3e6d3"), rough: 0.7, env: 0.2 }),
      shadow: (o) => MAT({ mode: 3, map: T.shadow, opacity: o, blend: 1 }),
      shadowSoft: (o) => MAT({ mode: 3, map: T.shadowSoft, opacity: o, blend: 1 }),
      shadowDisc: (o) => MAT({ mode: 3, map: T.shadowDisc, opacity: o, blend: 1 }),
      ao: (o) => MAT({ mode: 3, map: T.aoUp, opacity: o, blend: 1 }),
      glow: (col, o) => MAT({ mode: 2, map: T.glow, color: col, opacity: o, blend: 2 }),
      beam: (col, o) => MAT({ mode: 2, map: T.beam, color: col, opacity: o, blend: 2 })
    };

    /* scene list: each item belongs to a room */
    const items = [];
    let curRoom = null;
    function add(room, geo, mat, model, extra) {
      const it = Object.assign({ room, mesh: upload(geo), mat, model: model || M4.ident(), visible: true, group: null }, extra || {});
      let mn = [1e9, 1e9, 1e9], mx = [-1e9, -1e9, -1e9];
      for (let k = 0; k < geo.p.length; k += 3) for (let c = 0; c < 3; c++) { mn[c] = Math.min(mn[c], geo.p[k + c]); mx[c] = Math.max(mx[c], geo.p[k + c]); }
      it._lc = V.mul(V.add(mn, mx), 0.5); it._r = V.len(V.sub(mx, mn)) / 2;
      it._c = M4.pt(it.model, it._lc);
      items.push(it); return it;
    }
    function removeItem(it) {
      const i = items.indexOf(it); if (i < 0) return;
      items.splice(i, 1);
      gl.deleteVertexArray(it.mesh.vao); it.mesh.bufs.forEach((b) => gl.deleteBuffer(b)); gl.deleteBuffer(it.mesh.ib);
    }
    function worldOf(it) { return it.group ? M4.mul(it.group.m, it.model) : it.model; }

    /* ---------------- camera & director ---------------- */
    const cam = { pos: [0, 1.6, 5], tgt: [0, 1.6, 0], fov: 45, aspect: 1 };
    const st = {
      t: 0, pointer: [0, 0], pointerS: [0, 0], speed: 0, reduce: !!opts.reduce, layout: "side", progress: 0,
      hop: null, veil: 0, veilColor: lin("#fbf8ef"), wakeUntil: 0, shot: null, params: {}, k: 6.5
    };
    let W = 1, H = 1, dpr = 1;
    const built = {};

    const ctx = {
      gl, lite, V, M4, G, Geo, TX, PROF, D2R, clamp, lerp, smooth, smoother, damp, mod, lin, mixHex,
      easeInOutCubic, easeInOutSine, easeOutCubic, easeInCubic, easeOutBack, archPath, roundRect, crescentSolid, crescentPts,
      cnv, svgImg, loadImg, artCanvas, drawContain, drawCover, tex, dropTex, MAT, T, M, add, removeItem, worldOf, items,
      cam, st, wake, base: opts.base || "", logo: null, opts,
      size: () => ({ W, H }),
      retex(it, src) { const t = tex(src, { clamp: true }); const old = it.mat.map; it.mat.map = t; if (old && old !== T.mat && it.mat._own) dropTex(old); it.mat._own = true; wake(); }
    };

    async function ensure(name) {
      if (built[name]) return built[name];
      const f = rooms[name]; if (!f) throw new Error("room " + name);
      built[name] = Promise.resolve(f(ctx)).then((r) => { r.name = name; built[name] = r; return r; });
      return built[name];
    }
    function roomObj(name) { const r = built[name]; return r && !r.then ? r : null; }

    /* hop: push into the current view, veil, cut, pull out into the new shot */
    function go(room, shot, params, how) {
      how = how || {};
      const target = { room, shot, params: params || {} };
      wake(4000);
      if (!curRoom || how.instant) {
        return ensure(room).then((r) => { setRoom(r, target); snap(); return r; });
      }
      if (curRoom.name === room) {
        st.shot = shot; st.params = target.params; st.k = how.k || 30;
        if (curRoom.onShot) curRoom.onShot(shot, target.params);
        return Promise.resolve(curRoom);
      }
      /* straight cut to the next room: no travel, no veil, no easing */
      return ensure(room).then((r) => { setRoom(r, target); snap(); return r; });
    }
    function setRoom(r, target) {
      if (curRoom && curRoom !== r && curRoom.onLeave) curRoom.onLeave();
      curRoom = r; st.shot = target.shot; st.params = target.params; st.k = 6.5;
      if (r.onEnter) r.onEnter(target.shot, target.params);
      if (r.onShot) r.onShot(target.shot, target.params);
    }
    function desired(dt) {
      if (!curRoom) return null;
      return curRoom.camera(st.shot, st.params, dt) || null;
    }
    function snap() { const d = desired(0); if (d) { cam.pos = d.pos.slice(); cam.tgt = d.tgt.slice(); cam.fov = d.fov; } }

    function stepCamera(dt, hdt) {
      st.pointerS = [damp(st.pointerS[0], st.pointer[0], 3, dt), damp(st.pointerS[1], st.pointer[1], 3, dt)];
      const h = st.hop;
      if (h) {
        h.t += hdt || dt; // hops run on real time (capped) so slow devices still finish them promptly
        if (h.phase === "out") {
          const u = clamp(h.t / h.dur, 0, 1), e = easeInCubic(u);
          st.veil = e;
          if (!st.reduce) { cam.pos = V.add(cam.pos, V.mul(h.fwd, dt * 2.2 * (0.4 + e))); cam.fov = cam.fov + dt * 10 * e; }
          if (u >= 1) {
            const r = roomObj(h.target.room);
            if (r) {
              setRoom(r, h.target);
              const d = desired(0);
              if (d) {
                const fwd = V.norm(V.sub(d.tgt, d.pos));
                cam.pos = st.reduce ? d.pos.slice() : V.sub(d.pos, V.mul(fwd, 0.9));
                cam.tgt = d.tgt.slice(); cam.fov = d.fov + (st.reduce ? 0 : 7);
              }
              h.phase = "in"; h.t = 0; h.dur = st.reduce ? 0.18 : 0.6;
            }
          }
          return;
        }
        if (h.phase === "in") {
          const u = clamp(h.t / h.dur, 0, 1);
          st.veil = 1 - easeOutCubic(u);
          if (u >= 1) { st.hop = null; st.veil = 0; }
        }
      }
      const d = desired(dt);
      if (!d) return;
      if (d.direct) { cam.pos = d.pos; cam.tgt = d.tgt; cam.fov = d.fov; return; }
      // scroll speed: a fast scroller gets a camera that follows immediately, a slow one glides
      const k = (h ? 5.5 : (d.k || st.k)) * (1 + clamp(st.speed, 0, 1) * 2.4);
      const kdt = Math.max(dt, hdt || 0); // exponential easing is stable at any step; use real time so slow devices keep up
      cam.pos = V.damp(cam.pos, d.pos, k, kdt); cam.tgt = V.damp(cam.tgt, d.tgt, k, kdt); cam.fov = damp(cam.fov, d.fov, k, kdt);
    }

    /* ---------------- frame, resolution and idle refinement ---------------- */
    let raf = 0, last = 0, running = false, scale = lite ? 0.85 : 1, frames = 0, hist = [], calm = 0, lastMotion = 0, refined = false;
    const MIN_SCALE = lite ? 0.55 : 0.65;
    function wake(ms) { st.wakeUntil = Math.max(st.wakeUntil, performance.now() + (ms || 1200)); refined = false; if (running && !raf) { last = 0; raf = requestAnimationFrame(frame); } }
    function adapt(ms) {
      frames++; if (frames < 40) return;
      hist.push(Math.min(ms, 120)); if (hist.length > 30) hist.shift();
      if (hist.length < 30) return;
      const avg = hist.reduce((a, b) => a + b, 0) / hist.length;
      if (avg > 24 && scale > MIN_SCALE) { scale = Math.max(MIN_SCALE, scale * 0.86); hist = []; calm = 0; applySize(); }
      else if (avg < 17.5) { if (++calm > 120 && scale < 1) { scale = Math.min(1, scale * 1.1); calm = 0; hist = []; applySize(); } }
      else calm = 0;
    }
    function frame(now) {
      raf = 0;
      if (!running) return;
      const ms = last ? now - last : 16, dt = Math.min(0.05, ms / 1000); last = now;
      const before = [cam.pos[0], cam.pos[1], cam.pos[2], cam.tgt[0], cam.tgt[1], cam.tgt[2], cam.fov];
      st.t += dt;
      stepCamera(dt, Math.min(0.14, ms / 1000));
      st.speed *= 0.82;   /* a flick fades back to a gentle glide in a few frames */
      const anim = curRoom && curRoom.update ? curRoom.update(dt) : false;
      const moved = Math.abs(before[0] - cam.pos[0]) + Math.abs(before[1] - cam.pos[1]) + Math.abs(before[2] - cam.pos[2]) + Math.abs(before[3] - cam.tgt[0]) + Math.abs(before[4] - cam.tgt[1]) + Math.abs(before[5] - cam.tgt[2]) + Math.abs(before[6] - cam.fov) * 0.02;
      if (moved > 0.0004 || anim || st.hop || st.veil > 0) lastMotion = now;
      const busy = now < st.wakeUntil || now - lastMotion < 350;
      if (busy) {
        if (ms > 0 && ms < 4000) adapt(ms);
        render();
        raf = requestAnimationFrame(frame);
      } else if (!refined) {
        // the scene has settled: one crisp frame at full resolution, then rest
        refined = true;
        if (scale < 1) { const s = scale; scale = 1; applySize(); render(); scale = s; canvas.dataset.res = "full"; }
        else render();
        last = 0;
      }
    }
    function applySize() {
      const w = Math.max(1, Math.round(W * dpr * scale)), h = Math.max(1, Math.round(H * dpr * scale));
      if (canvas.width !== w || canvas.height !== h) { canvas.width = w; canvas.height = h; }
      canvas.dataset.res = scale < 1 ? "reduced" : "full";
    }
    function resize() {
      const r = canvas.getBoundingClientRect();
      dpr = Math.min(window.devicePixelRatio || 1, lite ? 1.5 : 1.75);
      W = Math.max(1, r.width); H = Math.max(1, r.height);
      cam.aspect = W / H; applySize(); wake();
    }

    const lightBuf = new Float32Array(32), lightCol = new Float32Array(24);
    const quad = upload((() => { const g = new Geo(); const a = g.v(-1, -1, 0, 0, 0, 1, 0, 0), b = g.v(1, -1, 0, 0, 0, 1, 1, 0), c = g.v(1, 1, 0, 0, 0, 1, 1, 1), d = g.v(-1, 1, 0, 0, 0, 1, 0, 1); g.quad(a, b, c, d); return g; })());
    function render() {
      gl.viewport(0, 0, canvas.width, canvas.height);
      gl.clearColor(0.95, 0.91, 0.86, 1); gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
      if (!curRoom) return;
      gl.enable(gl.DEPTH_TEST); gl.disable(gl.CULL_FACE);
      const proj = M4.persp(cam.fov * D2R, cam.aspect, 0.04, 80), view = M4.lookAt(cam.pos, cam.tgt, [0, 1, 0]);
      gl.uniformMatrix4fv(U.uVP, false, M4.mul(proj, view));
      gl.uniform3fv(U.uCam, cam.pos);
      const env = curRoom.env(cam);
      gl.uniform3fv(U.uSky, env.sky); gl.uniform3fv(U.uGnd, env.gnd);
      gl.uniform3fv(U.uKeyDir, env.keyDir); gl.uniform3fv(U.uKeyCol, env.keyCol);
      gl.uniform1f(U.uExpo, env.expo);
      const fog = env.fog || [0, 1, 0, 0];
      gl.uniform4fv(U.uFog, fog); gl.uniform3fv(U.uFogCol, env.fogCol || [1, 0.9, 0.9]);
      const cands = curRoom.lights(cam).filter((l) => l.c[0] + l.c[1] + l.c[2] > 0.001);
      const fwdC = V.norm(V.sub(cam.tgt, cam.pos));
      cands.forEach((l) => { const dv = V.sub(l.p, cam.pos), dl = V.len(dv); l._d = dl - 2.5 * V.dot(V.mul(dv, 1 / (dl || 1)), fwdC) - (l.prio || 0); });
      const chosen = cands.sort((a, b) => a._d - b._d).slice(0, lite ? 5 : 7);
      chosen.forEach((l, i) => { lightBuf.set([l.p[0], l.p[1], l.p[2], l.r], i * 4); lightCol.set(l.c, i * 3); });
      gl.uniform1i(U.uNL, chosen.length); gl.uniform4fv(U.uLP, lightBuf); gl.uniform3fv(U.uLC, lightCol);

      const vis = curRoom.visible || [curRoom.name];
      const opaque = [], trans = [], addv = [];
      for (const it of items) {
        if (!it.visible || vis.indexOf(it.room) < 0) continue;
        const m = it.mat;
        if (m.opacity <= 0.001) continue;
        if (m.blend === 2) addv.push(it); else if (m.blend === 1 || m.opacity < 0.999 || m.alphaMap) trans.push(it); else opaque.push(it);
      }
      const camDist = (it) => { const mm = worldOf(it); return V.len(V.sub(M4.pt(mm, it._lc), cam.pos)); };
      trans.forEach((it) => { it._cd = camDist(it) - (it.sortBias || 0); });
      trans.sort((a, b) => b._cd - a._cd);
      opaque.forEach((it) => { it._cd = (it.group ? camDist(it) : V.len(V.sub(it._c, cam.pos))) + (it._r > 4 ? 40 : 0); });
      opaque.sort((a, b) => a._cd - b._cd);
      gl.disable(gl.BLEND); gl.depthMask(true);
      opaque.forEach(draw);
      gl.enable(gl.BLEND); gl.blendFuncSeparate(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA, gl.ONE, gl.ONE_MINUS_SRC_ALPHA); gl.depthMask(false);
      trans.forEach(draw);
      gl.blendFunc(gl.ONE, gl.ONE);
      addv.forEach(draw);
      if (st.veil > 0.001) {
        gl.disable(gl.DEPTH_TEST); gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);
        gl.uniform1i(U.uMode, 4); gl.uniform3fv(U.uColor, st.veilColor); gl.uniform1f(U.uOpacity, st.veil); gl.uniform1i(U.uHasMap, 0); gl.uniform1i(U.uAlphaMap, 0);
        gl.uniform2fv(U.uUvScale, [1, 1]); gl.uniform2fv(U.uUvOff, [0, 0]);
        gl.bindVertexArray(quad.vao); gl.drawElements(gl.TRIANGLES, quad.n, gl.UNSIGNED_INT, 0);
        gl.enable(gl.DEPTH_TEST);
      }
      gl.depthMask(true); gl.disable(gl.BLEND);
    }
    function draw(it) {
      const m = it.mat;
      gl.uniformMatrix4fv(U.uModel, false, worldOf(it));
      gl.uniform1i(U.uMode, m.mode); gl.uniform3fv(U.uColor, m.color);
      gl.uniform1f(U.uRough, m.rough); gl.uniform1f(U.uMetal, m.metal); gl.uniform1f(U.uEnvI, m.env);
      gl.uniform3fv(U.uEmis, m.emis); gl.uniform1f(U.uEmisMap, m.emisMap); gl.uniform1f(U.uOpacity, m.opacity);
      gl.uniform2fv(U.uUvScale, m.uv); gl.uniform2fv(U.uUvOff, m.uvOff);
      gl.uniform1i(U.uHasMap, m.map ? 1 : 0); gl.uniform1i(U.uAlphaMap, m.alphaMap ? 1 : 0);
      if (m.map) { gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, m.map); }
      gl.bindVertexArray(it.mesh.vao);
      gl.drawElements(gl.TRIANGLES, it.mesh.n, gl.UNSIGNED_INT, 0);
    }

    /* ---------------- picking & projection ---------------- */
    function ray(px, py) {
      const f = V.norm(V.sub(cam.tgt, cam.pos)), r = V.norm(V.cross(f, [0, 1, 0])), u = V.cross(r, f);
      const th = Math.tan(cam.fov * D2R / 2), nx = (px / W) * 2 - 1, ny = 1 - (py / H) * 2;
      return { o: cam.pos.slice(), d: V.norm(V.add(f, V.add(V.mul(r, nx * th * cam.aspect), V.mul(u, ny * th)))) };
    }
    function project(p) {
      const proj = M4.persp(cam.fov * D2R, cam.aspect, 0.04, 80), view = M4.lookAt(cam.pos, cam.tgt, [0, 1, 0]);
      const vp = M4.mul(proj, view);
      const x = vp[0] * p[0] + vp[4] * p[1] + vp[8] * p[2] + vp[12], y = vp[1] * p[0] + vp[5] * p[1] + vp[9] * p[2] + vp[13], w = vp[3] * p[0] + vp[7] * p[1] + vp[11] * p[2] + vp[15];
      return [(x / w * 0.5 + 0.5) * W, (1 - (y / w * 0.5 + 0.5)) * H, w];
    }
    ctx.ray = ray; ctx.project = project;
    /* ray against a rectangle given by a model matrix (local XY plane, half sizes) */
    ctx.hitRect = (r, m, hw, hh, cx, cy) => {
      const o = [m[12], m[13], m[14]], ax = V.norm([m[0], m[1], m[2]]), ay = V.norm([m[4], m[5], m[6]]), az = V.norm([m[8], m[9], m[10]]);
      const den = V.dot(r.d, az); if (Math.abs(den) < 1e-5) return null;
      const t = V.dot(V.sub(o, r.o), az) / den; if (t <= 0) return null;
      const p = V.sub(V.add(r.o, V.mul(r.d, t)), o);
      const lx = V.dot(p, ax) - (cx || 0), ly = V.dot(p, ay) - (cy || 0);
      return Math.abs(lx) <= hw && Math.abs(ly) <= hh ? { t, lx, ly } : null;
    };
    ctx.hitSphere = (r, c, rad) => {
      const oc = V.sub(r.o, c), b = V.dot(oc, r.d), cc = V.dot(oc, oc) - rad * rad, h = b * b - cc;
      if (h < 0) return null; const t = -b - Math.sqrt(h); return t > 0 ? { t } : null;
    };

    /* ---------------- assets shared by every room ---------------- */
    async function loadLogo() {
      const base = ctx.base;
      try { ctx.logo = await loadImg(base + "assets/logo-burgundy.svg"); }
      catch (e) { try { ctx.logo = await loadImg(base + "assets/logo-burgundy.png"); } catch (e2) { ctx.logo = null; } }
    }
    /* draw the vector logo crisply at any size */
    ctx.drawLogo = (x, cx, cy, w, alpha) => {
      const lg = ctx.logo; if (!lg) return;
      const ratio = (lg.naturalHeight || lg.height || 147) / (lg.naturalWidth || lg.width || 640);
      x.save(); if (alpha != null) x.globalAlpha = alpha; x.drawImage(lg, cx - w / 2, cy - w * ratio / 2, w, w * ratio); x.restore();
    };

    const api = {
      async init() { resize(); await loadLogo(); await ensure("hall"); return api; },
      ensure, room: () => (curRoom ? curRoom.name : null), get: (n) => roomObj(n),
      go,
      start() { if (running) return; running = true; last = 0; frames = 0; hist = []; wake(1500); if (!raf) raf = requestAnimationFrame(frame); },
      stop() { running = false; if (raf) cancelAnimationFrame(raf); raf = 0; },
      resize, wake, renderOnce() { stepCamera(0.016); if (curRoom && curRoom.update) curRoom.update(0.016); render(); },
      snap,
      setReduce(v) { st.reduce = !!v; },
      setLayout(l) { if (st.layout !== l) { st.layout = l; wake(); } },
      setPointer(x, y) { st.pointer = [clamp(x, -1, 1), clamp(y, -1, 1)]; wake(600); },
      setProgress(p) { st.progress = clamp(p, 0, 1); wake(900); },
      setSpeed(v) { st.speed = clamp(v, 0, 1); },
      pick(px, py) { if (!curRoom || !curRoom.pick || st.hop) return null; return curRoom.pick(ray(px, py), px, py); },
      hover(px, py) { if (!curRoom || !curRoom.hover) return null; const h = px == null ? null : (st.hop ? null : curRoom.pick ? curRoom.pick(ray(px, py), px, py) : null); curRoom.hover(h); return h; },
      project,
      busy: () => !!st.hop,
      debug: { st, cam, items, get scale() { return scale; }, setScale(v) { scale = v; applySize(); }, stats() { let tri = 0; items.forEach((i) => { tri += i.mesh.n / 3; }); return { items: items.length, tri, textures: textures.size }; } },
      dispose() {
        api.stop();
        items.forEach((it) => { gl.deleteVertexArray(it.mesh.vao); it.mesh.bufs.forEach((b) => gl.deleteBuffer(b)); gl.deleteBuffer(it.mesh.ib); });
        textures.forEach((t) => gl.deleteTexture(t));
      }
    };
    ctx.api = api;
    return api;
  }

  window.LBNW = {
    rooms, create,
    supported() { try { const c = document.createElement("canvas"); return !!c.getContext("webgl2"); } catch (e) { return false; } }
  };
})();
