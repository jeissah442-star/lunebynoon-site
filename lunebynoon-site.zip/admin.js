/* LuneByNoon store admin.
   Visible only to people who can edit this site (the owner and editors).
   Orders, products, bundles, site text, creator applications and subscribers,
   each editable in English and Arabic. */
window.LBNAdmin = (function () {
  "use strict";
  const X = window.LBN;
  const { S, esc, Art, P, B, ACT, INPUT } = X;
  const A = { tab: "orders", orders: [], creators: [], subs: [], status: "all", q: "", connected: false, edit: null, confirmDel: false };

  const T = {
    en: {
      title: "Store admin", only: "This page is for the LuneByNoon team. Sign in with an editor account to manage the shop.",
      orders: "Orders", products: "Products", bundles: "Bundles", content: "Site text & delivery", creators: "Creators", subs: "Subscribers",
      k_orders: "Orders", k_rev: "Revenue", k_open: "Open orders", k_emb: "Pieces to embroider",
      all: "All statuses", find: "Search name, phone or order", export: "Export CSV", none: "No orders yet. Place a test order from the shop and it appears here.",
      no: "Order", date: "Date", customer: "Customer", gov: "Governorate", total: "Total", pay: "Payment", status: "Status",
      s_new: "New", s_confirmed: "Confirmed", s_embroidery: "In embroidery", s_shipped: "Shipped", s_delivered: "Delivered", s_cancelled: "Cancelled",
      items: "Items", address: "Delivery address", gift: "Gift", ticket: "Workshop ticket", copy_ticket: "Copy workshop ticket", copy_wa: "Copy WhatsApp confirmation",
      device: "Saved on a test device only", totals: "Totals", source: "Campaign source",
      add: "Add product", edit: "Edit", save: "Save", cancel: "Cancel", del: "Delete", del_q: "Delete this for good? This can't be undone.", keep: "Keep it",
      name: "Name", desc: "Description", fabric: "Fabric", price: "Price (EGP)", compare: "Compare-at price (optional)", cols: "Collections", type: "Type", shape: "Drawing shape", print: "Print",
      sizes: "Sizes (comma separated)", colours: "Colours", add_colour: "Add colour", base: "Base", accent: "Trim", flags: "Options",
      f_custom: "Can be personalized", f_feat: "Featured on the homepage rack", f_new: "Show New badge", f_stock: "In stock", order: "Sort order",
      photo: "Product photo", upload: "Upload photo", remove_photo: "Remove photo", photo_note: "Real photos replace the drawing everywhere. Use square images, at least 1200 px.",
      saved: "Saved", need: "Fill in the English and Arabic name and a price.", seed: "Load the sample catalogue", seed_note: "The shop is showing the sample catalogue. Load it into the store so you can edit it here.",
      seeded: "Sample catalogue loaded", in_stock: "In stock", out: "Sold out",
      b_add: "Add bundle", b_items: "Pieces in the bundle", b_none: "None", b_gift: "Gift ready", b_price_type: "Price type", giftwrap_on: "Offer gift packaging at checkout",
      announce: "Announcement bar", heroT: "Homepage headline", heroS: "Homepage sub line", staging: "Show staging banner",
      free: "Free delivery over (EGP)", embfee: "Embroidery fee per piece (EGP)", wrapfee: "Gift packaging fee (EGP)", codfee: "Cash on delivery fee (EGP)", setdisc: "Mix & Match set saving (%)",
      zones: "Delivery zones", fee: "Fee (EGP)", days: "Working days (e.g. 2-3)", promos: "Promo codes", promos_help: "One per line, like WELCOME10=10 for 10% off.",
      contact: "Contact and social", wa: "WhatsApp number", email: "Email", ig: "Instagram link", tt: "TikTok link",
      c_none: "No creator applications yet.", s_none: "No subscribers yet.", copy_all: "Copy all emails",
      links: "Links", about: "About", portfolio: "Portfolio", typeC: "Type", phone: "Phone",
      no_store: "Saving needs the shared store, which isn't available in this view.", csv_title: "Orders CSV", csv_note: "Copy this into Excel or Google Sheets.",
      tip: "Changes go live on the staging shop straight away. Arabic fields show on the Arabic version of the site."
    },
    ar: {
      title: "إدارة المتجر", only: "الصفحة دي لفريق لون باي نون. ادخلي بحساب محرر عشان تديري المتجر.",
      orders: "الطلبات", products: "المنتجات", bundles: "الباقات", content: "نصوص الموقع والتوصيل", creators: "صناع المحتوى", subs: "المشتركين",
      k_orders: "الطلبات", k_rev: "الإيرادات", k_open: "طلبات مفتوحة", k_emb: "قطع محتاجة تطريز",
      all: "كل الحالات", find: "دوّري بالاسم أو الموبايل أو رقم الطلب", export: "تصدير CSV", none: "مفيش طلبات لسه. اعملي طلب تجريبي من المتجر وهيظهر هنا.",
      no: "الطلب", date: "التاريخ", customer: "العميلة", gov: "المحافظة", total: "الإجمالي", pay: "الدفع", status: "الحالة",
      s_new: "جديد", s_confirmed: "متأكد", s_embroidery: "في التطريز", s_shipped: "اتشحن", s_delivered: "اتسلّم", s_cancelled: "اتلغى",
      items: "القطع", address: "عنوان التوصيل", gift: "هدية", ticket: "تذكرة الورشة", copy_ticket: "انسخي تذكرة الورشة", copy_wa: "انسخي رسالة تأكيد واتساب",
      device: "متسجل على جهاز تجريبي بس", totals: "الحساب", source: "مصدر الحملة",
      add: "ضيفي منتج", edit: "تعديل", save: "حفظ", cancel: "إلغاء", del: "حذف", del_q: "تمسحيه خالص؟ مش هينفع ترجّعيه.", keep: "سيبيه",
      name: "الاسم", desc: "الوصف", fabric: "الخامة", price: "السعر (ج.م)", compare: "السعر قبل الخصم (اختياري)", cols: "المجموعات", type: "النوع", shape: "شكل الرسمة", print: "الطبعة",
      sizes: "المقاسات (افصلي بفاصلة)", colours: "الألوان", add_colour: "ضيفي لون", base: "الأساسي", accent: "البايبنج", flags: "اختيارات",
      f_custom: "ينفع يتطرز", f_feat: "يظهر على الستاند في الصفحة الرئيسية", f_new: "علامة جديد", f_stock: "متاح", order: "الترتيب",
      photo: "صورة المنتج", upload: "ارفعي صورة", remove_photo: "شيلي الصورة", photo_note: "الصور الحقيقية بتحل مكان الرسمة في كل مكان. استخدمي صور مربعة ١٢٠٠ بكسل على الأقل.",
      saved: "اتحفظ", need: "اكتبي الاسم بالإنجليزي والعربي والسعر.", seed: "حمّلي الكتالوج التجريبي", seed_note: "المتجر بيعرض الكتالوج التجريبي. حمّليه في المتجر عشان تقدري تعدّليه من هنا.",
      seeded: "اتحمل الكتالوج التجريبي", in_stock: "متاح", out: "خلص",
      b_add: "ضيفي باقة", b_items: "القطع في الباقة", b_none: "ولا حاجة", b_gift: "جاهزة للهدية", b_price_type: "نوع السعر", giftwrap_on: "إتاحة تغليف الهدايا في صفحة الطلب",
      announce: "شريط الإعلان", heroT: "عنوان الصفحة الرئيسية", heroS: "السطر تحت العنوان", staging: "إظهار شريط النسخة التجريبية",
      free: "توصيل مجاني فوق (ج.م)", embfee: "سعر التطريز للقطعة (ج.م)", wrapfee: "سعر تغليف الهدية (ج.م)", codfee: "رسوم الدفع عند الاستلام (ج.م)", setdisc: "خصم طقم نسّقي طقمك (٪)",
      zones: "مناطق التوصيل", fee: "السعر (ج.م)", days: "أيام العمل (مثلًا 2-3)", promos: "أكواد الخصم", promos_help: "كود في كل سطر، زي WELCOME10=10 لخصم ١٠٪.",
      contact: "التواصل والسوشيال", wa: "رقم واتساب", email: "الإيميل", ig: "لينك إنستجرام", tt: "لينك تيك توك",
      c_none: "مفيش طلبات تعاون لسه.", s_none: "مفيش مشتركين لسه.", copy_all: "انسخي كل الإيميلات",
      links: "اللينكات", about: "عنها", portfolio: "البورتفوليو", typeC: "النوع", phone: "الموبايل",
      no_store: "الحفظ محتاج المخزن المشترك، ومش متاح في العرض ده.", csv_title: "ملف الطلبات CSV", csv_note: "انسخيه في إكسل أو جوجل شيتس.",
      tip: "التعديلات بتظهر على المتجر التجريبي على طول. الخانات العربي بتظهر في النسخة العربي من الموقع."
    }
  };
  const a = (k) => (T[S.lang] && T[S.lang][k]) || T.en[k] || k;
  const STATUSES = ["new", "confirmed", "embroidery", "shipped", "delivered", "cancelled"];
  const COLS = ["original", "winter", "summer", "bridal", "postpartum"];

  function connect() {
    if (A.connected || !S.db) return;
    A.connected = true;
    S.db.collection("orders").onSnapshot((snap) => {
      const list = [];
      snap.docs.forEach((d) => { const l = (d.data() || {}).list || {}; Object.keys(l).forEach((k) => list.push(Object.assign({}, l[k], { _uid: d.id, orderNo: l[k].orderNo || k }))); });
      A.orders = list; refresh();
    }, () => {});
    S.db.collection("creators").onSnapshot((snap) => {
      const list = []; snap.docs.forEach((d) => { const ap = (d.data() || {}).apps || {}; Object.keys(ap).forEach((k) => list.push(ap[k])); });
      A.creators = list.sort((x, y) => String(y.at).localeCompare(String(x.at))); refresh();
    }, () => {});
    S.db.collection("subscribers").onSnapshot((snap) => {
      A.subs = snap.docs.map((d) => d.data()).sort((x, y) => String(y.at).localeCompare(String(x.at))); refresh();
    }, () => {});
  }
  function refresh() {
    if (S.route.name !== "admin") return;
    const ae = document.activeElement;
    if (ae && document.getElementById("main").contains(ae) && /INPUT|TEXTAREA|SELECT/.test(ae.tagName)) return;
    if (!document.getElementById("modal").hidden) return;
    X.renderMain(true);
  }

  function allOrders() {
    const local = (X.lsGet("lbn_orders", []) || []).filter((o) => o.savedTo === "device").map((o) => Object.assign({}, o, { _local: true }));
    const seen = new Set(A.orders.map((o) => o.orderNo));
    return A.orders.concat(local.filter((o) => !seen.has(o.orderNo))).sort((x, y) => String(y.createdAt).localeCompare(String(x.createdAt)));
  }
  const pill = (s) => `<span class="pill ${esc(s)}">${esc(a("s_" + s))}</span>`;
  const dt = (iso) => { try { return new Date(iso).toLocaleString(S.lang === "ar" ? "ar-EG" : "en-GB", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" }); } catch (e) { return iso; } };
  const payName = (m) => X.t("pay_" + m);
  const nm = (o) => (o ? o[S.lang] || o.en || "" : "");

  function view() {
    if (!S.canEdit) return `<div class="wrap"><div class="empty" style="margin-block:4rem">${X.moon(40, "#6e2135")}<p>${esc(a("only"))}</p><a class="btn" href="#home">LuneByNoon</a></div></div>`;
    const tabs = ["orders", "products", "bundles", "content", "creators", "subs"];
    let body = "";
    if (A.tab === "orders") body = vOrders();
    if (A.tab === "products") body = vProducts();
    if (A.tab === "bundles") body = vBundles();
    if (A.tab === "content") body = vContent();
    if (A.tab === "creators") body = vCreators();
    if (A.tab === "subs") body = vSubs();
    return `<div class="wrap"><div class="page-head"><span class="eyebrow">LuneByNoon</span><h1>${esc(a("title"))}</h1><p class="note">${esc(a("tip"))}</p></div>
      <div class="adm"><div class="adm-tabs" role="tablist">${tabs.map((k) => `<button role="tab" class="${A.tab === k ? "on" : ""}" aria-selected="${A.tab === k}" data-act="atab" data-v="${k}">${esc(a(k))}</button>`).join("")}</div>${body}</div></div>`;
  }

  /* ----- orders ----- */
  function vOrders() {
    const all = allOrders();
    const live = all.filter((o) => o.status !== "cancelled");
    const rev = live.reduce((s, o) => s + ((o.totals || {}).total || 0), 0);
    const open = all.filter((o) => ["new", "confirmed", "embroidery"].includes(o.status)).length;
    const emb = all.filter((o) => ["new", "confirmed", "embroidery"].includes(o.status)).reduce((s, o) => s + (o.items || []).reduce((x, it) => x + (it.parts || []).filter((p) => p.embroidery).length * (it.qty || 1), 0), 0);
    let list = all;
    if (A.status !== "all") list = list.filter((o) => o.status === A.status);
    if (A.q) { const q = A.q.toLowerCase(); list = list.filter((o) => [o.orderNo, o.customer && o.customer.name, o.customer && o.customer.phone, o.customer && o.customer.email].join(" ").toLowerCase().includes(q)); }
    return `<div class="kpis">
        <div class="kpi"><b>${X.num(live.length)}</b><span>${esc(a("k_orders"))}</span></div>
        <div class="kpi"><b>${X.fmt(rev)}</b><span>${esc(a("k_rev"))}</span></div>
        <div class="kpi"><b>${X.num(open)}</b><span>${esc(a("k_open"))}</span></div>
        <div class="kpi"><b>${X.num(emb)}</b><span>${esc(a("k_emb"))}</span></div></div>
      <div class="adm-bar"><div class="l">
        <select data-in="astatus" aria-label="${esc(a("status"))}"><option value="all">${esc(a("all"))}</option>${STATUSES.map((s) => `<option value="${s}" ${A.status === s ? "selected" : ""}>${esc(a("s_" + s))}</option>`).join("")}</select>
        <input type="search" id="aq" data-in="aq" value="${esc(A.q)}" placeholder="${esc(a("find"))}" aria-label="${esc(a("find"))}"></div>
        <button class="btn ghost small" data-act="acsv">${esc(a("export"))}</button></div>
      ${list.length ? `<div class="adm-table"><table><thead><tr><th>${esc(a("no"))}</th><th>${esc(a("date"))}</th><th>${esc(a("customer"))}</th><th>${esc(a("gov"))}</th><th>${esc(a("items"))}</th><th>${esc(a("pay"))}</th><th>${esc(a("total"))}</th><th>${esc(a("status"))}</th></tr></thead><tbody>
        ${list.map((o) => `<tr class="click" data-act="aorder" data-v="${esc(o.orderNo)}" tabindex="0"><td><b>${esc(o.orderNo)}</b>${o._local ? ` <span class="pill">${esc(a("device"))}</span>` : ""}</td><td>${esc(dt(o.createdAt))}</td><td>${esc((o.customer || {}).name)}<br><span class="note" dir="ltr">${esc((o.customer || {}).phone)}</span></td><td>${esc(S.lang === "ar" ? (o.address || {}).governorateAr || (o.address || {}).governorate : (o.address || {}).governorate)}</td><td>${X.num((o.items || []).reduce((s, it) => s + (it.qty || 1), 0))}${(o.items || []).some((it) => (it.parts || []).some((p) => p.embroidery)) ? " " + X.moon(12, "#6e2135") : ""}</td><td>${esc(payName((o.payment || {}).method))}</td><td>${X.fmt((o.totals || {}).total)}</td><td>${pill(o.status || "new")}</td></tr>`).join("")}
      </tbody></table></div>` : `<div class="empty">${X.moon(36, "#6e2135")}<p>${esc(a("none"))}</p></div>`}`;
  }
  function findOrder(no) { return allOrders().find((o) => o.orderNo === no); }
  function partLine(p) {
    return `${esc(nm(p.name))} · ${esc(p.color ? (p.color[S.lang] || p.color.en) : "")}${p.size ? " · " + esc(p.size) : ""}`;
  }
  function ticketText(o) {
    const lines = [];
    (o.items || []).forEach((it) => (it.parts || []).forEach((p) => {
      if (!p.embroidery) return;
      const e = p.embroidery;
      const E = window.LBN_I18N.en;
      lines.push(`${o.orderNo} | ${p.name.en} | ${p.color ? p.color.en : ""} | ${p.size} | x${it.qty || 1}\nText: "${e.text}" | Font: ${E["font_" + e.font]} | Thread: ${E["th_" + e.thread]} | Placement: ${E["pl_" + e.placement]}${e.icon ? " | Icon: " + E["icon_" + e.icon] : ""}${e.note ? "\nSpecial instructions: " + e.note : ""}`);
    }));
    return lines.join("\n\n") || o.orderNo + ": no embroidery";
  }
  function waText(o) {
    const ar = o.lang === "ar";
    const items = (o.items || []).map((it) => `${nm(it.name)}${it.qty > 1 ? " x" + it.qty : ""}`).join(ar ? "، " : ", ");
    const emb = (o.items || []).flatMap((it) => (it.parts || []).filter((p) => p.embroidery).map((p) => `"${p.embroidery.text}"`)).join(ar ? "، " : ", ");
    return ar
      ? `أهلًا ${o.customer.name.split(" ")[0]}، شكرًا لطلبك من لون باي نون 🌙\nرقم الطلب: ${o.orderNo}\nالطلب: ${items}\n${emb ? "التطريز: " + emb + "\nمن فضلك أكدي إن الإملاء مظبوط.\n" : ""}الإجمالي: ${o.totals.total} ج.م\nالتوصيل: ${o.address.governorateAr || o.address.governorate}، ${o.address.city}`
      : `Hi ${o.customer.name.split(" ")[0]}, thank you for your LuneByNoon order 🌙\nOrder: ${o.orderNo}\nItems: ${items}\n${emb ? "Embroidery: " + emb + "\nPlease confirm the spelling is right.\n" : ""}Total: EGP ${o.totals.total}\nDelivery: ${o.address.governorate}, ${o.address.city}`;
  }
  function openOrder(no) {
    const o = findOrder(no); if (!o) return;
    const ad = o.address || {}, c = o.customer || {}, tt = o.totals || {};
    const html = `
      <div style="display:flex;gap:.6rem;align-items:center;flex-wrap:wrap;justify-content:space-between">
        <span class="note">${esc(dt(o.createdAt))} · ${esc(o.lang === "ar" ? "العربية" : "English")}${o._local ? " · " + esc(a("device")) : ""}</span>
        <label style="display:flex;gap:.5rem;align-items:center;font-weight:700;font-size:.85rem">${esc(a("status"))}<select data-in="aostatus" data-v="${esc(o.orderNo)}" style="width:auto">${STATUSES.map((s) => `<option value="${s}" ${o.status === s ? "selected" : ""}>${esc(a("s_" + s))}</option>`).join("")}</select></label>
      </div>
      <div class="row2">
        <div><h3 style="font-size:1.1rem">${esc(a("customer"))}</h3><p>${esc(c.name)}<br><span dir="ltr">${esc(c.phone)}</span> <button class="link" data-act="copy" data-v="${esc(c.phone)}">${esc(X.t("copy"))}</button><br>${esc(c.email)}</p>
          <p class="note" style="margin-top:.4rem">${esc(a("pay"))}: ${esc(payName((o.payment || {}).method))} (${esc((o.payment || {}).status || "")})</p></div>
        <div><h3 style="font-size:1.1rem">${esc(a("address"))}</h3><p>${esc([ad.street, ad.building && (S.lang === "ar" ? "عمارة " : "Bldg ") + ad.building, ad.floor && (S.lang === "ar" ? "دور " : "Floor ") + ad.floor, ad.apartment && (S.lang === "ar" ? "شقة " : "Apt ") + ad.apartment].filter(Boolean).join(", "))}<br>${esc(ad.city)}, ${esc(S.lang === "ar" ? ad.governorateAr || ad.governorate : ad.governorate)}${ad.landmark ? "<br>" + esc(ad.landmark) : ""}${ad.notes ? `<br><span class="note">${esc(ad.notes)}</span>` : ""}</p></div>
      </div>
      ${o.gift ? `<div class="ticket"><b>${esc(a("gift"))}</b><span>${esc(o.gift.recipientName)} · <span dir="ltr">${esc(o.gift.recipientPhone)}</span></span>${o.gift.note ? `<span>“${esc(o.gift.note)}”</span>` : ""}<span class="note">${o.gift.wrap ? esc(X.t("co_wrap_line")) + " ✓" : ""} ${o.gift.hidePrices ? " · " + esc(X.t("co_hide_price")) : ""}</span></div>` : ""}
      <div><h3 style="font-size:1.1rem;margin-bottom:.4rem">${esc(a("items"))}</h3>
        <div style="display:grid;gap:.6rem">${(o.items || []).map((it) => `<div class="ticket"><div style="display:flex;justify-content:space-between;gap:1rem"><b>${esc(nm(it.name))} × ${X.num(it.qty)}</b><span class="price">${X.fmt(it.total)}</span></div>
          ${(it.parts || []).map((p) => `<span>${partLine(p)}</span>${p.embroidery ? `<span style="background:var(--petal);border-radius:6px;padding:.3rem .5rem">${X.moon(12, "#6e2135")} “${esc(p.embroidery.text)}” · ${esc(X.t("font_" + p.embroidery.font))} · ${esc(X.t("th_" + p.embroidery.thread))} · ${esc(X.t("pl_" + p.embroidery.placement))}${p.embroidery.icon ? " · " + esc(X.t("icon_" + p.embroidery.icon)) : ""}${p.embroidery.note ? "<br>" + esc(X.t("c_note_label")) + ": " + esc(p.embroidery.note) : ""}</span>` : ""}`).join("")}</div>`).join("")}</div></div>
      <div class="cz-sum">
        <div class="ln"><span>${esc(X.t("cart_sub"))}</span><span>${X.fmt(tt.subtotal)}</span></div>
        ${tt.discount ? `<div class="ln"><span>${esc(X.t("co_discount"))} ${esc(tt.promo || "")}</span><span>−${X.fmt(tt.discount)}</span></div>` : ""}
        <div class="ln"><span>${esc(X.t("co_shipping"))}</span><span>${X.fmt(tt.delivery)}</span></div>
        ${tt.giftWrap ? `<div class="ln"><span>${esc(X.t("co_wrap_line"))}</span><span>${X.fmt(tt.giftWrap)}</span></div>` : ""}
        ${tt.codFee ? `<div class="ln"><span>${esc(X.t("pay_cod"))}</span><span>${X.fmt(tt.codFee)}</span></div>` : ""}
        <div class="ln tot"><span>${esc(X.t("co_total"))}</span><span>${X.fmt(tt.total)}</span></div></div>
      ${o.utm ? `<p class="note">${esc(a("source"))}: ${esc(Object.entries(o.utm).filter(([k]) => k !== "landed").map(([k, v]) => k + "=" + v).join(", "))}</p>` : ""}
      <div style="display:flex;gap:.5rem;flex-wrap:wrap"><button class="btn small" data-act="aticket" data-v="${esc(o.orderNo)}">${esc(a("copy_ticket"))}</button><button class="btn ghost small" data-act="awa" data-v="${esc(o.orderNo)}">${esc(a("copy_wa"))}</button></div>`;
    X.openModal(a("no") + " " + o.orderNo, html, true);
  }
  async function setStatus(no, status) {
    const o = findOrder(no); if (!o) return;
    if (o._local) {
      const l = X.lsGet("lbn_orders", []); const r = l.find((x) => x.orderNo === no); if (r) { r.status = status; X.lsSet("lbn_orders", l); }
    } else if (S.db) {
      try { await S.db.doc("orders/" + o._uid).update({ list: { [no]: { status } } }); } catch (e) { X.toast(a("no_store")); return; }
    }
    o.status = status; X.toast(a("saved") + ": " + a("s_" + status));
    X.renderMain(true);
  }
  function csv() {
    const rows = [["Order", "Date", "Status", "Name", "Phone", "Email", "Governorate", "City", "Address", "Landmark", "Payment", "Items", "Embroidery", "Gift", "Subtotal", "Discount", "Delivery", "Total", "Source"]];
    allOrders().forEach((o) => {
      const ad = o.address || {}, tt = o.totals || {};
      rows.push([o.orderNo, o.createdAt, o.status, o.customer.name, o.customer.phone, o.customer.email, ad.governorate, ad.city, [ad.street, ad.building, ad.floor, ad.apartment].filter(Boolean).join(" / "), ad.landmark,
        (o.payment || {}).method, (o.items || []).map((it) => `${it.name.en} x${it.qty}: ` + (it.parts || []).map((p) => `${p.name.en} ${p.color ? p.color.en : ""} ${p.size}`).join(" + ")).join(" | "),
        (o.items || []).flatMap((it) => (it.parts || []).filter((p) => p.embroidery).map((p) => `${p.name.en}: "${p.embroidery.text}" ${p.embroidery.font} ${p.embroidery.thread} ${p.embroidery.placement}${p.embroidery.icon ? " icon:" + p.embroidery.icon : ""}${p.embroidery.note ? " note:" + p.embroidery.note : ""}`)).join(" | "),
        o.gift ? `${o.gift.recipientName} ${o.gift.recipientPhone} ${o.gift.note || ""}` : "", tt.subtotal, tt.discount, tt.delivery, tt.total, o.utm ? o.utm.utm_source || "" : ""]);
    });
    return "﻿" + rows.map((r) => r.map((v) => { const s = v == null ? "" : String(v); return /[",\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s; }).join(",")).join("\n");
  }
  async function exportCsv() {
    const data = csv();
    if (S.downloads) {
      try { await S.downloads.save({ filename: "lunebynoon-orders-" + new Date().toISOString().slice(0, 10) + ".csv", data }); return; } catch (e) { /* fall through */ }
    }
    X.openModal(a("csv_title"), `<p class="note">${esc(a("csv_note"))}</p><textarea style="min-height:280px;font-family:monospace;font-size:.75rem" readonly id="csvOut">${esc(data)}</textarea><button class="btn small" data-act="copy" data-v="${esc(data)}">${esc(X.t("copy"))}</button>`, true);
  }

  /* ----- products ----- */
  function vProducts() {
    const fromFile = S.source !== "db";
    return `${fromFile ? `<div class="confirmbar" style="background:var(--petal);color:var(--wine-deep)"><span>${esc(a("seed_note"))}</span><button class="btn small" data-act="aseed">${esc(a("seed"))}</button></div>` : ""}
      <div class="adm-bar"><span class="note">${X.num(S.products.length)} ${esc(a("products"))}</span><button class="btn small" data-act="aprod" data-v="">${esc(a("add"))}</button></div>
      <div class="adm-table"><table><thead><tr><th></th><th>${esc(a("name"))} EN</th><th>${esc(a("name"))} AR</th><th>${esc(a("cols"))}</th><th>${esc(a("price"))}</th><th>${esc(a("f_stock"))}</th><th></th></tr></thead><tbody>
      ${S.products.map((p) => `<tr class="click" data-act="aprod" data-v="${esc(p.id)}" tabindex="0"><td>${p.image ? `<img src="${esc(p.image)}" alt="" style="width:44px;height:44px;object-fit:cover;border-radius:6px">` : Art.draw(p)}</td><td>${esc(p.name.en)}${p.customizable ? " " + X.moon(12, "#6e2135") : ""}</td><td dir="rtl">${esc(p.name.ar)}</td><td>${esc((p.collections || []).map((c) => X.t("col_" + c)).join(", "))}</td><td>${X.fmt(p.price)}</td><td>${p.inStock === false ? `<span class="pill off">${esc(a("out"))}</span>` : `<span class="pill on">${esc(a("in_stock"))}</span>`}</td><td><span class="link">${esc(a("edit"))}</span></td></tr>`).join("")}
      </tbody></table></div>`;
  }
  const slug = (s) => String(s || "").toLowerCase().normalize("NFKD").replace(/[^\w\s-]/g, "").trim().replace(/[\s_]+/g, "-").slice(0, 48) || "piece-" + Date.now().toString(36);
  function blankProduct() {
    return { id: "", order: S.products.length + 1, collections: ["original"], type: "set", shape: "set-long", print: "solid", name: { en: "", ar: "" }, desc: { en: "", ar: "" }, fabric: { en: "", ar: "" }, price: 0, customizable: true, featured: false, isNew: true, inStock: true, created: new Date().toISOString().slice(0, 10), sizes: ["XS", "S", "M", "L", "XL"], colors: [{ key: "blush", name: { en: "Blush", ar: "بلاش" }, base: "#f4cdd8", accent: "#6e2135" }] };
  }
  function openProduct(id) {
    const p = id ? JSON.parse(JSON.stringify(P(id))) : blankProduct();
    A.edit = { kind: "product", isNew: !id, data: p };
    A.confirmDel = false;
    renderProductForm();
  }
  function bi(key, label, area) {
    const d = A.edit.data[key] || { en: "", ar: "" };
    const el = (lang) => area
      ? `<textarea id="pf_${key}_${lang}" ${lang === "ar" ? 'dir="rtl"' : 'dir="ltr"'}>${esc(d[lang] || "")}</textarea>`
      : `<input type="text" id="pf_${key}_${lang}" value="${esc(d[lang] || "")}" ${lang === "ar" ? 'dir="rtl"' : 'dir="ltr"'}>`;
    return `<div class="bi"><label class="f"><span><span class="lang">EN</span> ${esc(label)}</span>${el("en")}</label><label class="f"><span><span class="lang">AR</span> ${esc(label)}</span>${el("ar")}</label></div>`;
  }
  function renderProductForm() {
    const p = A.edit.data;
    const opt = (arr, v) => arr.map((x) => `<option value="${x}" ${x === v ? "selected" : ""}>${x}</option>`).join("");
    const html = `<form id="pform" class="in" style="padding:0;display:grid;gap:1rem" novalidate>
      <div style="display:grid;grid-template-columns:160px minmax(0,1fr);gap:1rem;align-items:start">
        <div id="pfPrev" style="aspect-ratio:1;background:#f9ecf0;border-radius:8px;display:grid;place-items:center;padding:8px;overflow:hidden">${p.image ? `<img src="${esc(p.image)}" alt="" style="width:100%;height:100%;object-fit:cover">` : Art.draw(p)}</div>
        <div style="display:grid;gap:.6rem">
          <label class="f">${esc(a("photo"))}<span class="hint">${esc(a("photo_note"))}</span>
            ${S.assets ? `<input type="file" id="pf_photo" accept="image/*">` : `<span class="hint">${esc(a("no_store"))}</span>`}</label>
          ${p.image ? `<button type="button" class="link" data-act="arm_photo" style="justify-self:start">${esc(a("remove_photo"))}</button>` : ""}
        </div>
      </div>
      ${bi("name", a("name"))}
      ${bi("desc", a("desc"), true)}
      ${bi("fabric", a("fabric"))}
      <div class="row3">
        <label class="f">${esc(a("price"))}<input type="number" id="pf_price" min="0" step="10" value="${esc(p.price)}"></label>
        <label class="f">${esc(a("compare"))}<input type="number" id="pf_compare" min="0" step="10" value="${esc(p.compareAt || "")}"></label>
        <label class="f">${esc(a("order"))}<input type="number" id="pf_order" step="1" value="${esc(p.order || "")}"></label>
      </div>
      <div class="f"><span>${esc(a("cols"))}</span><div class="chips">${COLS.map((c) => `<label class="check" style="font-size:.85rem"><input type="checkbox" class="pf_col" value="${c}" ${(p.collections || []).includes(c) ? "checked" : ""}> ${esc(X.t("col_" + c))}</label>`).join("")}</div></div>
      <div class="row3">
        <label class="f">${esc(a("type"))}<select id="pf_type">${opt(["set", "top", "bottom", "robe", "accessory"], p.type)}</select></label>
        <label class="f">${esc(a("shape"))}<select id="pf_shape">${opt(["set-long", "set-short", "cami", "top", "pants", "wide", "shorts", "robe", "mask", "scrunchie", "towel", "pillow"], p.shape)}</select></label>
        <label class="f">${esc(a("print"))}<select id="pf_print">${opt(["solid", "crescent", "stripe", "gingham", "dots"], p.print)}</select></label>
      </div>
      <label class="f">${esc(a("sizes"))}<input type="text" id="pf_sizes" value="${esc((p.sizes || []).join(", "))}" dir="ltr"></label>
      <div class="f"><span>${esc(a("colours"))}</span>
        <div id="pfColors" style="display:grid;gap:.5rem">${(p.colors || []).map((c, i) => `<div class="colorrow" data-i="${i}">
          <label class="f"><span class="lang">EN</span><input type="text" class="pc_en" value="${esc(c.name.en)}" dir="ltr"></label>
          <label class="f"><span class="lang">AR</span><input type="text" class="pc_ar" value="${esc(c.name.ar)}" dir="rtl"></label>
          <label class="f"><span class="lang">${esc(a("base"))}</span><input type="color" class="pc_base" value="${esc(c.base)}"></label>
          <label class="f"><span class="lang">${esc(a("accent"))}</span><input type="color" class="pc_acc" value="${esc(c.accent)}"></label>
          <button type="button" class="iconbtn" data-act="arm_colour" data-i="${i}" aria-label="${esc(a("del"))}" ${(p.colors || []).length < 2 ? "disabled" : ""}>${X.ICON.close}</button></div>`).join("")}</div>
        <button type="button" class="link" data-act="aadd_colour" style="justify-self:start">+ ${esc(a("add_colour"))}</button></div>
      <div class="f"><span>${esc(a("flags"))}</span><div style="display:grid;gap:.4rem">
        <label class="check"><input type="checkbox" id="pf_custom" ${p.customizable ? "checked" : ""}> ${esc(a("f_custom"))}</label>
        <label class="check"><input type="checkbox" id="pf_feat" ${p.featured ? "checked" : ""}> ${esc(a("f_feat"))}</label>
        <label class="check"><input type="checkbox" id="pf_new" ${p.isNew ? "checked" : ""}> ${esc(a("f_new"))}</label>
        <label class="check"><input type="checkbox" id="pf_stock" ${p.inStock !== false ? "checked" : ""}> ${esc(a("f_stock"))}</label></div></div>
      <p class="err" id="pfErr" role="alert"></p>
      ${A.confirmDel ? `<div class="confirmbar"><span>${esc(a("del_q"))}</span><span style="display:flex;gap:.4rem"><button type="button" class="btn small" data-act="adel_yes">${esc(a("del"))}</button><button type="button" class="btn ghost small" data-act="adel_no">${esc(a("keep"))}</button></span></div>` : ""}
      <div style="display:flex;gap:.5rem;justify-content:space-between;flex-wrap:wrap;position:sticky;bottom:0;background:var(--cream);padding-block:.6rem">
        <span>${!A.edit.isNew ? `<button type="button" class="btn ghost small" data-act="adel">${esc(a("del"))}</button>` : ""}</span>
        <span style="display:flex;gap:.5rem"><button type="button" class="btn ghost small" data-act="close">${esc(a("cancel"))}</button><button type="submit" class="btn small">${esc(a("save"))}</button></span></div>
    </form>`;
    X.openModal(A.edit.isNew ? a("add") : nm(p.name) || a("edit"), html, true);
  }
  function readProductForm() {
    const g = (id) => document.getElementById(id);
    const p = A.edit.data;
    ["name", "desc", "fabric"].forEach((k) => { p[k] = { en: g("pf_" + k + "_en").value.trim(), ar: g("pf_" + k + "_ar").value.trim() }; });
    p.price = Number(g("pf_price").value) || 0;
    const cmp = Number(g("pf_compare").value); if (cmp > 0) p.compareAt = cmp; else delete p.compareAt;
    p.order = Number(g("pf_order").value) || 99;
    p.collections = Array.from(document.querySelectorAll(".pf_col:checked")).map((x) => x.value);
    p.type = g("pf_type").value; p.shape = g("pf_shape").value; p.print = g("pf_print").value;
    p.sizes = g("pf_sizes").value.split(",").map((s) => s.trim()).filter(Boolean);
    p.colors = Array.from(document.querySelectorAll("#pfColors .colorrow")).map((r, i) => {
      const en = r.querySelector(".pc_en").value.trim() || "Colour " + (i + 1);
      return { key: slug(en) || "c" + i, name: { en, ar: r.querySelector(".pc_ar").value.trim() || en }, base: r.querySelector(".pc_base").value, accent: r.querySelector(".pc_acc").value };
    });
    p.customizable = g("pf_custom").checked; p.featured = g("pf_feat").checked; p.isNew = g("pf_new").checked; p.inStock = g("pf_stock").checked;
    return p;
  }
  async function saveProduct() {
    const p = readProductForm();
    if (!p.name.en || !p.name.ar || !p.price) { document.getElementById("pfErr").textContent = a("need"); return; }
    if (!p.sizes.length) p.sizes = ["One size"];
    if (A.edit.isNew) { p.id = slug(p.name.en); let n = 2; while (P(p.id)) p.id = slug(p.name.en) + "-" + n++; }
    if (!S.db) { document.getElementById("pfErr").textContent = a("no_store"); return; }
    if (S.source !== "db") await seed(true);
    const body = Object.assign({}, p); delete body.id;
    try { await S.db.doc("products/" + p.id).set(body); } catch (e) { document.getElementById("pfErr").textContent = a("no_store") + " (" + (e.code || "") + ")"; return; }
    X.closeModal(); X.toast(a("saved"));
  }
  async function seed(silent) {
    const cat = S.fileCatalog; if (!S.db || !cat) return;
    for (const p of cat.products) { const b = Object.assign({}, p); delete b.id; await S.db.doc("products/" + p.id).set(b); }
    for (const b of cat.bundles) { const x = Object.assign({}, b); delete x.id; await S.db.doc("bundles/" + b.id).set(x); }
    const st = await S.db.doc("settings/store").get(); if (!st.exists) await S.db.doc("settings/store").set(cat.settings);
    if (!silent) X.toast(a("seeded"));
  }

  /* ----- bundles ----- */
  function vBundles() {
    return `<div class="adm-bar"><span class="note">${X.num(S.bundles.length)} ${esc(a("bundles"))}</span><button class="btn small" data-act="abund" data-v="">${esc(a("b_add"))}</button></div>
      <div class="adm-table"><table><thead><tr><th>${esc(a("name"))} EN</th><th>${esc(a("name"))} AR</th><th>${esc(a("b_items"))}</th><th>${esc(a("price"))}</th><th></th></tr></thead><tbody>
      ${S.bundles.map((b) => `<tr class="click" data-act="abund" data-v="${esc(b.id)}" tabindex="0"><td>${esc(b.name.en)}</td><td dir="rtl">${esc(b.name.ar)}</td><td>${esc(b.items.map((i) => (P(i) || { name: { en: i } }).name.en).join(", "))}</td><td>${X.fmt(b.price)}</td><td><span class="link">${esc(a("edit"))}</span></td></tr>`).join("")}
      </tbody></table></div>`;
  }
  function openBundle(id) {
    const b = id ? JSON.parse(JSON.stringify(B(id))) : { id: "", order: S.bundles.length + 1, price: 0, priceType: "fixed", chooseEach: true, soldSeparately: true, name: { en: "", ar: "" }, desc: { en: "", ar: "" }, items: [] };
    A.edit = { kind: "bundle", isNew: !id, data: b }; A.confirmDel = false;
    renderBundleForm();
  }
  function renderBundleForm() {
    const b = A.edit.data;
    const sel = (i) => `<select id="bf_item${i}"><option value="">${esc(a("b_none"))}</option>${S.products.map((p) => `<option value="${esc(p.id)}" ${b.items[i] === p.id ? "selected" : ""}>${esc(nm(p.name))}</option>`).join("")}</select>`;
    const html = `<form id="bform" style="display:grid;gap:1rem" novalidate>
      ${bi("name", a("name"))}${bi("desc", a("desc"), true)}
      <div class="row2"><label class="f">${esc(a("price"))}<input type="number" id="pf_price" min="0" step="10" value="${esc(b.price)}"></label><label class="f">${esc(a("order"))}<input type="number" id="pf_order" value="${esc(b.order || "")}"></label></div>
      <div class="f"><span>${esc(a("b_items"))}</span><div class="row2">${[0, 1, 2, 3].map(sel).join("")}</div></div>
      <div class="row2"><label class="f">${esc(a("b_price_type"))}<select id="bf_ptype"><option value="fixed" ${b.priceType !== "calculated" ? "selected" : ""}>${esc(X.t("b_price_fixed"))}</option><option value="calculated" ${b.priceType === "calculated" ? "selected" : ""}>${esc(X.t("b_price_calc"))}</option></select></label>
        <label class="check" style="align-self:end"><input type="checkbox" id="bf_sep" ${b.soldSeparately !== false ? "checked" : ""}> ${esc(X.t("b_sep_yes"))}</label></div>
      <p class="err" id="pfErr" role="alert"></p>
      ${A.confirmDel ? `<div class="confirmbar"><span>${esc(a("del_q"))}</span><span style="display:flex;gap:.4rem"><button type="button" class="btn small" data-act="adel_yes">${esc(a("del"))}</button><button type="button" class="btn ghost small" data-act="adel_no">${esc(a("keep"))}</button></span></div>` : ""}
      <div style="display:flex;gap:.5rem;justify-content:space-between;flex-wrap:wrap"><span>${!A.edit.isNew ? `<button type="button" class="btn ghost small" data-act="adel">${esc(a("del"))}</button>` : ""}</span>
        <span style="display:flex;gap:.5rem"><button type="button" class="btn ghost small" data-act="close">${esc(a("cancel"))}</button><button type="submit" class="btn small">${esc(a("save"))}</button></span></div></form>`;
    X.openModal(A.edit.isNew ? a("b_add") : nm(b.name), html, true);
  }
  async function saveBundle() {
    const g = (id) => document.getElementById(id), b = A.edit.data;
    ["name", "desc"].forEach((k) => { b[k] = { en: g("pf_" + k + "_en").value.trim(), ar: g("pf_" + k + "_ar").value.trim() }; });
    b.price = Number(g("pf_price").value) || 0; b.order = Number(g("pf_order").value) || 99;
    b.items = [0, 1, 2, 3].map((i) => g("bf_item" + i).value).filter(Boolean);
    b.priceType = g("bf_ptype").value; b.soldSeparately = g("bf_sep").checked; b.chooseEach = true;
    if (!b.name.en || !b.name.ar || !b.price || !b.items.length) { g("pfErr").textContent = a("need"); return; }
    if (A.edit.isNew) { b.id = slug(b.name.en); let n = 2; while (B(b.id)) b.id = slug(b.name.en) + "-" + n++; }
    if (!S.db) { g("pfErr").textContent = a("no_store"); return; }
    if (S.source !== "db") await seed(true);
    const body = Object.assign({}, b); delete body.id;
    try { await S.db.doc("bundles/" + b.id).set(body); } catch (e) { g("pfErr").textContent = a("no_store"); return; }
    X.closeModal(); X.toast(a("saved"));
  }
  async function deleteEditing() {
    if (!S.db || !A.edit) return;
    const col = A.edit.kind === "product" ? "products" : "bundles";
    try { await S.db.doc(col + "/" + A.edit.data.id).delete(); } catch (e) { X.toast(a("no_store")); return; }
    X.closeModal(); X.toast(a("saved"));
  }

  /* ----- site text & delivery ----- */
  function vContent() {
    const st = S.settings;
    const z = st.zones || {};
    const sbi = (key, label, area) => {
      const d = st[key] || {};
      const el = (lang) => area ? `<textarea id="sc_${key}_${lang}" dir="${lang === "ar" ? "rtl" : "ltr"}">${esc(d[lang] || "")}</textarea>` : `<input type="text" id="sc_${key}_${lang}" value="${esc(d[lang] || "")}" dir="${lang === "ar" ? "rtl" : "ltr"}">`;
      return `<div class="bi"><label class="f"><span><span class="lang">EN</span> ${esc(label)}</span>${el("en")}</label><label class="f"><span><span class="lang">AR</span> ${esc(label)}</span>${el("ar")}</label></div>`;
    };
    const n = (id, label, v) => `<label class="f">${esc(label)}<input type="number" id="${id}" value="${esc(v)}" min="0"></label>`;
    return `<form id="sform" class="co-sec" novalidate style="gap:1.2rem">
      ${sbi("announcement", a("announce"))}${sbi("heroTitle", a("heroT"))}${sbi("heroSub", a("heroS"), true)}
      <label class="check"><input type="checkbox" id="sc_staging" ${st.staging !== false ? "checked" : ""}> ${esc(a("staging"))}</label>
      <label class="check"><input type="checkbox" id="sc_giftwrap" ${st.giftWrapEnabled ? "checked" : ""}> ${esc(a("giftwrap_on"))}</label>
      <div class="row3">${n("sc_free", a("free"), st.freeDeliveryOver)}${n("sc_emb", a("embfee"), st.embroideryFee)}${n("sc_wrap", a("wrapfee"), st.giftWrapFee)}</div>
      <div class="row3">${n("sc_cod", a("codfee"), st.codFee)}${n("sc_set", a("setdisc"), st.setDiscountPct)}</div>
      <div class="f"><span>${esc(a("zones"))}</span>
        <div class="adm-table"><table><thead><tr><th>${esc(a("gov"))}</th><th>${esc(a("fee"))}</th><th>${esc(a("days"))}</th></tr></thead><tbody>
        ${Object.keys(window.LBN_ZONE_NAMES).map((k) => `<tr><td>${esc(window.LBN_ZONE_NAMES[k][S.lang === "ar" ? 1 : 0])}</td><td><input type="number" id="sz_fee_${k}" value="${esc((z[k] || {}).fee)}" style="width:110px"></td><td><input type="text" id="sz_days_${k}" value="${esc((z[k] || {}).days)}" style="width:110px" dir="ltr"></td></tr>`).join("")}
        </tbody></table></div></div>
      <label class="f">${esc(a("promos"))}<textarea id="sc_promos" dir="ltr">${esc(Object.entries(st.promos || {}).map(([k, v]) => k + "=" + v.pct).join("\n"))}</textarea><span class="hint">${esc(a("promos_help"))}</span></label>
      <div class="f"><span>${esc(a("contact"))}</span><div class="row2">
        <label class="f">${esc(a("wa"))}<input type="tel" id="sc_wa" value="${esc(st.whatsapp)}" dir="ltr"></label><label class="f">${esc(a("email"))}<input type="email" id="sc_email" value="${esc(st.email)}" dir="ltr"></label>
        <label class="f">${esc(a("ig"))}<input type="url" id="sc_ig" value="${esc(st.instagram)}" dir="ltr"></label><label class="f">${esc(a("tt"))}<input type="url" id="sc_tt" value="${esc(st.tiktok)}" dir="ltr"></label><label class="f">Pinterest<input type="url" id="sc_pin" value="${esc(st.pinterest || "")}" dir="ltr"></label></div></div>
      <p class="err" id="scErr" role="alert"></p>
      <div><button class="btn" type="submit">${esc(a("save"))}</button></div></form>`;
  }
  async function saveContent() {
    const g = (id) => document.getElementById(id);
    const st = Object.assign({}, S.settings);
    ["announcement", "heroTitle", "heroSub"].forEach((k) => { st[k] = { en: g("sc_" + k + "_en").value.trim(), ar: g("sc_" + k + "_ar").value.trim() }; });
    st.staging = g("sc_staging").checked; st.giftWrapEnabled = g("sc_giftwrap").checked;
    st.freeDeliveryOver = Number(g("sc_free").value) || 0; st.embroideryFee = Number(g("sc_emb").value) || 0; st.giftWrapFee = Number(g("sc_wrap").value) || 0;
    st.codFee = Number(g("sc_cod").value) || 0; st.setDiscountPct = Number(g("sc_set").value) || 0;
    st.zones = {}; Object.keys(window.LBN_ZONE_NAMES).forEach((k) => { st.zones[k] = { fee: Number(g("sz_fee_" + k).value) || 0, days: g("sz_days_" + k).value.trim() }; });
    st.promos = {}; g("sc_promos").value.split(/\n+/).forEach((line) => { const m = line.trim().match(/^([A-Za-z0-9_-]+)\s*=\s*(\d+(?:\.\d+)?)/); if (m) st.promos[m[1].toUpperCase()] = { pct: Number(m[2]) }; });
    st.whatsapp = g("sc_wa").value.trim(); st.email = g("sc_email").value.trim(); st.instagram = g("sc_ig").value.trim(); st.tiktok = g("sc_tt").value.trim(); st.pinterest = g("sc_pin").value.trim();
    if (!S.db) { g("scErr").textContent = a("no_store"); return; }
    try { await S.db.doc("settings/store").set(st); } catch (e) { g("scErr").textContent = a("no_store"); return; }
    S.settings = st; X.renderChrome(); X.toast(a("saved"));
  }

  /* ----- creators & subscribers ----- */
  function vCreators() {
    const list = A.creators.concat(X.lsGet("lbn_creators", []));
    if (!list.length) return `<div class="empty">${X.moon(36, "#6e2135")}<p>${esc(a("c_none"))}</p></div>`;
    return `<div class="adm-table"><table><thead><tr><th>${esc(a("date"))}</th><th>${esc(a("name"))}</th><th>${esc(a("phone"))}</th><th>${esc(a("email"))}</th><th>${esc(a("typeC"))}</th><th>${esc(a("links"))}</th></tr></thead><tbody>
      ${list.map((c) => `<tr class="click" data-act="acreator" data-v="${esc(c.id)}" tabindex="0"><td>${esc(dt(c.at))}</td><td>${esc(c.name)}</td><td dir="ltr">${esc(c.phone)}</td><td>${esc(c.email)}</td><td>${c.type ? esc(X.t("cr_" + c.type)) : ""}</td><td>${(c.links || []).map((l) => `<a href="${esc(/^https?:/i.test(l) ? l : "https://" + l)}" target="_blank" rel="noopener">${esc(l.replace(/^https?:\/\//, "").slice(0, 32))}</a>`).join("<br>")}</td></tr>`).join("")}
      </tbody></table></div>`;
  }
  function openCreator(id) {
    const c = A.creators.concat(X.lsGet("lbn_creators", [])).find((x) => x.id === id); if (!c) return;
    X.openModal(c.name, `<p><span dir="ltr">${esc(c.phone)}</span> · ${esc(c.email)} <button class="link" data-act="copy" data-v="${esc(c.email)}">${esc(X.t("copy"))}</button></p>
      ${c.type ? `<p class="note">${esc(X.t("cr_" + c.type))}</p>` : ""}
      <div><h3 style="font-size:1.1rem">${esc(a("links"))}</h3>${(c.links || []).map((l) => `<p><a href="${esc(/^https?:/i.test(l) ? l : "https://" + l)}" target="_blank" rel="noopener">${esc(l)}</a></p>`).join("")}</div>
      ${c.about ? `<div><h3 style="font-size:1.1rem">${esc(a("about"))}</h3><p>${esc(c.about)}</p></div>` : ""}
      ${c.portfolio ? `<div><h3 style="font-size:1.1rem">${esc(a("portfolio"))}</h3><p><a href="${esc(c.portfolio)}" target="_blank" rel="noopener">${esc(c.portfolio)}</a></p></div>` : ""}
      ${c.upload ? `<div><h3 style="font-size:1.1rem">${esc(a("portfolio"))}</h3><p><a href="${esc(c.upload.url || "/_blob/" + c.upload.id)}" target="_blank" rel="noopener">${esc(c.upload.name)}</a></p></div>` : ""}`);
  }
  function vSubs() {
    const list = A.subs.concat(X.lsGet("lbn_subs", []));
    if (!list.length) return `<div class="empty">${X.moon(36, "#6e2135")}<p>${esc(a("s_none"))}</p></div>`;
    const emails = list.map((s) => s.email).join(", ");
    return `<div class="adm-bar"><span class="note">${X.num(list.length)} ${esc(a("subs"))}</span><button class="btn ghost small" data-act="copy" data-v="${esc(emails)}">${esc(a("copy_all"))}</button></div>
      <div class="adm-table"><table><thead><tr><th>${esc(a("email"))}</th><th>${esc(a("date"))}</th></tr></thead><tbody>${list.map((s) => `<tr><td>${esc(s.email)}</td><td>${esc(dt(s.at))}</td></tr>`).join("")}</tbody></table></div>`;
  }

  /* ----- wiring ----- */
  Object.assign(ACT, {
    atab: (el) => { A.tab = el.dataset.v; X.renderMain(true); },
    aorder: (el) => openOrder(el.dataset.v),
    aticket: (el) => { const o = findOrder(el.dataset.v); if (o) X.copyText(ticketText(o), el); },
    awa: (el) => { const o = findOrder(el.dataset.v); if (o) X.copyText(waText(o), el); },
    acsv: () => exportCsv(),
    aprod: (el) => openProduct(el.dataset.v),
    abund: (el) => openBundle(el.dataset.v),
    acreator: (el) => openCreator(el.dataset.v),
    aseed: async (el) => { el.disabled = true; try { await seed(); } catch (e) { X.toast(a("no_store")); } },
    aadd_colour: () => { readProductForm(); A.edit.data.colors.push({ key: "new", name: { en: "", ar: "" }, base: "#f4cdd8", accent: "#6e2135" }); renderProductForm(); },
    arm_colour: (el) => { readProductForm(); A.edit.data.colors.splice(Number(el.dataset.i), 1); renderProductForm(); },
    arm_photo: () => { readProductForm(); delete A.edit.data.image; delete A.edit.data.imageId; renderProductForm(); },
    adel: () => { if (A.edit.kind === "product") readProductForm(); A.confirmDel = true; A.edit.kind === "product" ? renderProductForm() : renderBundleForm(); },
    adel_no: () => { A.confirmDel = false; A.edit.kind === "product" ? renderProductForm() : renderBundleForm(); },
    adel_yes: () => deleteEditing()
  });
  Object.assign(INPUT, {
    astatus: (el) => { A.status = el.value; X.renderMain(true); },
    aq: (el) => { A.q = el.value; const pos = el.selectionStart; X.renderMain(true); const n = document.getElementById("aq"); if (n) { n.focus(); try { n.setSelectionRange(pos, pos); } catch (e) {} } },
    aostatus: (el) => setStatus(el.dataset.v, el.value)
  });
  document.addEventListener("change", async (e) => {
    if (e.target && e.target.id === "pf_photo" && e.target.files && e.target.files[0] && S.assets) {
      try {
        readProductForm();
        const r = await S.assets.upload(e.target.files[0]);
        A.edit.data.imageId = r.id; A.edit.data.image = "/_blob/" + r.id;
        renderProductForm();
      } catch (err) { const pe = document.getElementById("pfErr"); if (pe) pe.textContent = (err && err.message) || a("no_store"); }
    }
    if (e.target && e.target.closest && e.target.closest("#pform") && /pf_shape|pf_print|pc_base|pc_acc/.test(e.target.id + " " + e.target.className)) {
      readProductForm(); const pv = document.getElementById("pfPrev"); if (pv && !A.edit.data.image) pv.innerHTML = Art.draw(A.edit.data);
    }
  });
  document.addEventListener("submit", (e) => {
    if (e.target.id === "pform") { e.preventDefault(); saveProduct(); }
    if (e.target.id === "bform") { e.preventDefault(); saveBundle(); }
    if (e.target.id === "sform") { e.preventDefault(); saveContent(); }
  });
  document.addEventListener("keydown", (e) => {
    if (e.key === "Enter" && e.target && e.target.matches && e.target.matches("tr.click")) e.target.click();
  });

  return { view, connect };
})();
