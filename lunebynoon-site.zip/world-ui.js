/* LuneByNoon — the world interface.
   Every page of the store lives inside one 3D world (world-core.js + world-rooms.js):
     home        a cinematic scroll through every room
     shop        the round boutique; its alcoves hold the collection
     product     the piece close up in its alcove, with the product panel
     customize   the embroidery atelier, a camera move for every step
     mix         the mix studio: tops and bottoms on two clothes lines
     bundles     the gift salon; a bundle opens its box and fans out its pieces
     story       the story gallery, walked as you scroll
     help, creators, checkout, orders   the lounge, behind a reading panel
   All shopping logic stays in app.js: this file renders the views with the same
   data-act / data-in controls, so sizes, colours, embroidery, bundles, the bag and
   checkout behave exactly as before. Without WebGL the same interface runs over
   still pictures of each room. Loaded before app.js; exposes window.LBNUI. */
(function () {
  "use strict";
  const $ = (s, r) => (r || document).querySelector(s);
  const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));
  const X = () => window.LBN;
  const mqReduce = window.matchMedia ? window.matchMedia("(prefers-reduced-motion: reduce)") : { matches: false };
  const coarse = window.matchMedia ? window.matchMedia("(pointer: coarse)").matches : false;
  const saveData = !!(navigator.connection && navigator.connection.saveData);
  const lite = coarse || (navigator.deviceMemory && navigator.deviceMemory <= 4) || (navigator.hardwareConcurrency && navigator.hardwareConcurrency <= 4);
  const can3D = (() => { try { const c = document.createElement("canvas"); const g = c.getContext("webgl2"); if (!g) return false; const e = g.getExtension("WEBGL_lose_context"); if (e) e.loseContext(); return true; } catch (e) { return false; } })();

  const U = {
    world: null, worldP: null, mode: "flat", route: null, lastKey: "",   /* photographic storefront: real room photos, no animated 3D */
    shopCol: "featured", list: [], idx: 0, czStep: 1, mxStep: 1, giftIdx: 0, chapter: -1,
    door: null, scrollRaf: 0, keep: {}, flatRoom: "hall", introDone: false, coachShown: false
  };

  const ICON = {
    left: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" aria-hidden="true"><path d="M15 5l-7 7 7 7"/></svg>',
    right: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" aria-hidden="true"><path d="M9 5l7 7-7 7"/></svg>',
    close: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18"/></svg>',
    arrow: '<svg class="arr" width="16" height="10" viewBox="0 0 16 10" aria-hidden="true"><path d="M0 5h14M10 1l4 4-4 4" stroke="currentColor" stroke-width="1.4" fill="none"/></svg>',
    moon: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M14.5 3.2a9 9 0 1 0 6.3 14.6a7.2 7.2 0 0 1 -6.3 -14.6z" fill="currentColor"/></svg>',
    list: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" aria-hidden="true"><path d="M4 6h16M4 12h16M4 18h16"/></svg>',
    down: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4" aria-hidden="true"><path d="M12 4v15M6 13l6 6 6-6"/></svg>',
    zoom: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" aria-hidden="true"><circle cx="11" cy="11" r="6.5"/><path d="M16 16l4.5 4.5M8.5 11h5M11 8.5v5"/></svg>'
  };
  const LOGO = (cls, alt) => `<img class="${cls || ""}" src="assets/logo-burgundy.svg" alt="${alt == null ? "LuneByNoon" : alt}" width="640" height="147" decoding="async">`;
  /* the four collection boxes on the home page: one still, printed-looking design per season */
  const flake = (x, y, r, o) => `<g transform="translate(${x} ${y})" opacity="${o}" stroke="#7f97ad" stroke-width="${(r / 9).toFixed(2)}" stroke-linecap="round" fill="none">${[0, 60, 120].map((a) => `<g transform="rotate(${a})"><path d="M0 ${-r}V${r}"/><path d="M${-r * .28} ${-r * .72}L0 ${-r * .45}L${r * .28} ${-r * .72}M${-r * .28} ${r * .72}L0 ${r * .45}L${r * .28} ${r * .72}"/></g>`).join("")}</g>`;
  const KIND_ART = {
    winter: `<svg viewBox="0 0 300 240" preserveAspectRatio="xMidYMid slice"><defs><linearGradient id="kgW" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#eef3f7"/><stop offset=".55" stop-color="#dbe5ee"/><stop offset="1" stop-color="#c7d4e0"/></linearGradient><radialGradient id="kgWf" cx=".5" cy="0" r="1"><stop offset="0" stop-color="#fff" stop-opacity=".9"/><stop offset=".6" stop-color="#fff" stop-opacity="0"/></radialGradient></defs><rect width="300" height="240" fill="url(#kgW)"/><rect width="300" height="240" fill="url(#kgWf)"/>${flake(250, 58, 22, .5)}${flake(276, 128, 9, .4)}${flake(206, 104, 7, .35)}${flake(160, 40, 6, .3)}${flake(232, 160, 6, .25)}<path d="M0 206c40-10 80-10 120-3s90 9 180-7V240H0z" fill="#fff" opacity=".75"/><path d="M0 222c50-7 100-4 150 1s100 4 150-4V240H0z" fill="#fff"/></svg>`,
    summer: `<svg viewBox="0 0 300 240" preserveAspectRatio="xMidYMid slice"><defs><linearGradient id="kgS" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fbe3cc"/><stop offset=".6" stop-color="#f6cdb0"/><stop offset="1" stop-color="#efb79a"/></linearGradient><radialGradient id="kgSs" cx=".86" cy=".2" r=".5"><stop offset="0" stop-color="#fff6dc"/><stop offset=".22" stop-color="#ffe2a8"/><stop offset=".5" stop-color="#ffd59a" stop-opacity=".35"/><stop offset="1" stop-color="#ffd59a" stop-opacity="0"/></radialGradient></defs><rect width="300" height="240" fill="url(#kgS)"/><rect width="300" height="240" fill="url(#kgSs)"/><g stroke="#e8a46e" stroke-width="1.2" opacity=".55" stroke-linecap="round">${Array.from({ length: 12 }, (_, i) => { const a = i * 30 * Math.PI / 180; return `<path d="M${258 + Math.cos(a) * 34} ${50 + Math.sin(a) * 34}L${258 + Math.cos(a) * 48} ${50 + Math.sin(a) * 48}"/>`; }).join("")}</g><circle cx="258" cy="50" r="25" fill="#fff1cf"/><g fill="none" stroke="#fff" stroke-width="1.4" opacity=".55"><path d="M0 196q37-8 75 0t75 0t75 0t75 0"/><path d="M0 212q37-8 75 0t75 0t75 0t75 0"/><path d="M0 228q37-8 75 0t75 0t75 0t75 0"/></g></svg>`,
    bridal: `<svg viewBox="0 0 300 240" preserveAspectRatio="xMidYMid slice"><defs><linearGradient id="kgB" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fdfbf5"/><stop offset="1" stop-color="#f1e9dc"/></linearGradient><pattern id="kgBl" width="30" height="30" patternUnits="userSpaceOnUse"><circle cx="15" cy="15" r="9" fill="none" stroke="#d9c7a3" stroke-width=".8"/><circle cx="15" cy="15" r="3" fill="none" stroke="#d9c7a3" stroke-width=".8"/><circle cx="0" cy="0" r="1.4" fill="#e3d4b8"/><circle cx="30" cy="30" r="1.4" fill="#e3d4b8"/></pattern></defs><rect width="300" height="240" fill="url(#kgB)"/><rect width="300" height="54" fill="url(#kgBl)" opacity=".7"/><path d="M0 54${Array.from({ length: 10 }, (_, i) => `a15 15 0 0 0 30 0`).join("")}V0H0z" fill="url(#kgBl)" opacity=".5"/><path d="M0 54${Array.from({ length: 10 }, () => `a15 15 0 0 0 30 0`).join("")}" fill="none" stroke="#c9ad7a" stroke-width="1"/>${Array.from({ length: 9 }, (_, i) => `<circle cx="${30 + i * 30}" cy="68" r="3" fill="#fffdf8" stroke="#d8c39a" stroke-width=".8"/>`).join("")}<path d="M250 150c-14-18-38-9-33 9c4 12 23 18 33 27c10-9 29-15 33-27c5-18-19-27-33-9z" fill="none" stroke="#e2d2b2" stroke-width="1" opacity=".7"/></svg>`,
    postpartum: `<svg viewBox="0 0 300 240" preserveAspectRatio="xMidYMid slice"><defs><linearGradient id="kgP" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#f8edf3"/><stop offset=".6" stop-color="#f1dce7"/><stop offset="1" stop-color="#e9cddb"/></linearGradient><radialGradient id="kgPg" cx=".72" cy=".2" r=".45"><stop offset="0" stop-color="#fff" stop-opacity=".95"/><stop offset="1" stop-color="#fff" stop-opacity="0"/></radialGradient></defs><rect width="300" height="240" fill="url(#kgP)"/><rect width="300" height="240" fill="url(#kgPg)"/><path d="M250 26a28 28 0 1 0 22 48a22 22 0 0 1 -22 -48z" fill="#fffaf2" stroke="#e6c9a0" stroke-width=".8"/><g fill="#fff" opacity=".75" transform="translate(0 -150)"><path d="M20 312a26 26 0 0 1 48-12a20 20 0 0 1 36 10a16 16 0 0 1 8 30H20a14 14 0 0 1 0-28z"/><path d="M168 330a22 22 0 0 1 40-10a17 17 0 0 1 30 9a14 14 0 0 1 6 25h-80a12 12 0 0 1 4-24z" opacity=".8"/></g>${[[170, 30], [210, 70], [276, 120], [150, 96]].map(([x, y]) => `<circle cx="${x}" cy="${y}" r="1.6" fill="#d9b88a"/>`).join("")}</svg>`
  };
  const KIND_ICON = {
    winter: '<svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"><path d="M12 2v20M3.3 7l17.4 10M3.3 17L20.7 7M9 4l3 2 3-2M9 20l3-2 3 2"/></svg>',
    summer: '<svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"><circle cx="12" cy="12" r="4.2"/><path d="M12 2v2.5M12 19.5V22M2 12h2.5M19.5 12H22M4.9 4.9l1.8 1.8M17.3 17.3l1.8 1.8M4.9 19.1l1.8-1.8M17.3 6.7l1.8-1.8"/></svg>',
    bridal: '<svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="12" cy="14" r="6"/><path d="M9.5 6.5L12 3l2.5 3.5L12 8z"/></svg>',
    postpartum: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M14.5 3.2a9 9 0 1 0 6.3 14.6a7.2 7.2 0 0 1 -6.3 -14.6z" fill="currentColor"/></svg>'
  };
  const RIBBON = () => {
    const one = `<span class="rb-brand">LuneByNoon</span><i></i><span>${esc(t("w_slogan"))}</span><i></i><span>${esc(t("w_made"))}</span>`;
    return `<div class="w-ribbon-in">${one}</div>`;
  };

  /* -------------------------------------------------------------- helpers */
  const t = (k, v) => X().t(k, v), L = (o) => X().L(o), fmt = (n) => X().fmt(n), esc = (s) => X().esc(s), num = (n) => X().num(n);
  const P = (id) => X().P(id), Bn = (id) => X().B(id);
  const S = () => X().S;
  const Art = () => X().Art;
  const pad2 = (v) => num(String(v).padStart(2, "0"));
  const isRTL = () => document.documentElement.dir === "rtl";
  const sideLayout = () => (window.innerWidth >= 900 && window.innerWidth / window.innerHeight > 1.05 ? "side" : "bottom");
  const COLS = ["original", "winter", "summer", "bridal", "postpartum"];
  function itemFor(p, colorKey, custom) {
    const col = (p.colors || []).find((c) => c.key === colorKey) || (p.colors || [])[0] || { key: "x", base: "#f4cdd8" };
    const rack = p.type === "set" || p.type === "robe";
    const ck = custom && custom.text ? ":" + [custom.text, custom.font, custom.thread, custom.placement, custom.icon].join(",") : "";
    return p.image && !ck ? { key: p.id + ":photo", photo: p.image, tint: col.base, mark: false }
      : { key: p.id + ":" + col.key + ck, svg: Art().draw(p, { color: col.key, rack, custom: custom || null }), tint: col.base, mark: true };
  }
  function productsFor(col) {
    const all = S().products;
    let list;
    if (col === "featured") { list = all.filter((p) => p.featured); if (!list.length) list = all.filter((p) => p.type === "set"); }
    else if (col === "all") list = all.slice();
    else list = all.filter((p) => (p.collections || []).includes(col));
    return list.slice().sort((a, b) => (a.order || 99) - (b.order || 99));
  }
  const tabs = () => [["featured", "b3_tab_featured"]].concat(COLS.filter((c) => S().products.some((p) => (p.collections || []).includes(c))).map((c) => [c, "b3_tab_" + c])).concat([["all", "b3_tab_all"]]);
  const routeOf = () => S().route;
  const swatch = (c, on, attrs) => `<button type="button" class="sw ${on ? "on" : ""}" ${attrs} aria-label="${esc(L(c.name))}" aria-pressed="${!!on}"><i style="background:${esc(c.base)}"></i><i style="background:${esc(c.accent)}"></i></button>`;

  /* ---------------------------------------------------------- the chrome */
  function header() {
    const x = X(), nav = [["home", t("nav_home")], ["customize", t("nav_customize")], ["mix", t("nav_mix")], ["shop", t("nav_collections")], ["bundles", t("nav_bundles")], ["story", t("nav_story")]];
    const r = routeOf().name;
    const on = (k) => (k === "shop" ? r === "shop" || r === "p" : k === "bundles" ? r === "bundles" || r === "b" : r === k);
    const link = ([k, v]) => `<a href="#${k}" class="${on(k) ? "on" : ""}" ${on(k) ? 'aria-current="page"' : ""}>${esc(v)}</a>`;
    const qty = S().cart.reduce((a, l) => a + l.qty, 0);
    return `<div class="w-hdr">
      <div class="w-hdr-l"><button class="w-ib" data-act="menu" aria-label="${esc(t("menu"))}">${x.ICON.menu}</button><nav class="w-nav" aria-label="Main">${nav.slice(0, 3).map(link).join("")}</nav></div>
      <a class="w-logo" href="#home" aria-label="LuneByNoon">${LOGO("", "")}</a>
      <div class="w-hdr-r"><nav class="w-nav" aria-label="Main, continued">${nav.slice(3).map(link).join("")}</nav>
        <button class="w-lang" data-act="lang">${esc(t("otherLang"))}</button>
        <button class="w-ib" data-act="search" aria-label="${esc(t("search"))}">${x.ICON.search}</button>
        <button class="w-ib w-bag" data-act="cart" aria-label="${esc(t("bag"))}">${x.ICON.bag}<span class="count" id="count" ${qty ? "" : "hidden"}>${num(qty)}</span></button>
      </div></div>`;
  }
  function footer() {
    const st = S().settings, x = X();
    const ext = (u, label) => `<a href="${esc(u || "#")}" target="_blank" rel="noopener">${esc(label)}</a>`;
    return `<div class="w-ftr">
      <div class="w-ftr-news">
        <div><span class="w-eyebrow">${esc(t("news_title"))}</span><p class="w-ftr-lede">${esc(t("news_sub"))}</p></div>
        <form class="newsform" id="newsform" novalidate><label class="sr" for="newsEmail">${esc(t("news_ph"))}</label>
          <input type="email" id="newsEmail" placeholder="${esc(t("news_ph"))}" autocomplete="email"><button class="w-btn" type="submit">${esc(t("news_btn"))} ${ICON.arrow}</button>
          <p class="note" id="newsMsg" aria-live="polite"></p></form>
      </div>
      <div class="w-ftr-cols">
        <div><h4>${esc(t("f_shop"))}</h4><a href="#shop">${esc(t("nav_collections"))}</a><a href="#customize">${esc(t("nav_customize"))}</a><a href="#mix">${esc(t("nav_mix"))}</a><a href="#bundles">${esc(t("nav_bundles"))}</a><a href="#story">${esc(t("nav_story"))}</a></div>
        <div><h4>${esc(t("f_support"))}</h4>${["shipping", "returns", "custom", "payment", "size", "care", "faq", "contact"].map((k) => `<a href="#help-${k}">${esc(t("h_" + k))}</a>`).join("")}<a href="#creators">${esc(t("h_creators"))}</a></div>
        <div><h4>${esc(t("f_follow"))}</h4>${ext(st.instagram, "Instagram")}${ext(st.tiktok, "TikTok")}${ext(st.pinterest, "Pinterest")}
          <p class="note" style="margin-top:1rem">${esc(t("tagline"))}<br>${esc(t("est"))}</p></div>
      </div>
      <div class="w-wordmark" aria-hidden="true">${LOGO("", "")}</div>
      <div class="w-ftr-base"><span>© 2026 LuneByNoon. ${esc(t("rights"))}</span><span><a href="#help-terms">${esc(t("h_terms"))}</a> · <button class="link" data-act="lang">${esc(t("otherLang"))}</button></span></div>
    </div>`;
    void x;
  }

  /* --------------------------------------------------------------- views */
  function view(r) {
    if (U.mode === "off") return null;
    switch (r.name) {
      case "home": return vHome();
      case "shop": return vShop(r.arg);
      case "p": return vProduct(r.arg);
      case "customize": return vCustomize();
      case "mix": return vMix();
      case "bundles": return vBundles();
      case "b": return vBundle(r.arg);
      case "story": return vStory();
      default: return null; // help, creators, checkout, pay, order, admin: app.js renders, we frame them
    }
  }

  /* ---- home: one cinematic scroll through the world ---- */
  function vHome() {
    const x = X(), st = S().settings;
    x.setMeta("", t("custom_sub"));
    const sets = productsFor("featured").filter((p) => p.type === "set").slice(0, 6);
    const colsK = ["winter", "summer", "bridal", "postpartum"];
    const tryV = S().homeTry;
    const si = Math.min(Math.max(0, U.setI || 0), Math.max(0, sets.length - 1)), s0 = sets[si];
    const POSTER = (n, cls) => `<img class="${cls || ""}" src="assets/posters/poster-${n}.jpg" alt="" loading="lazy" decoding="async">`;
    const T = (id) => P(id);
    return `<div class="w-home">
      <section class="w-ch w-ch-hero" data-room="hall" data-shot="hero" style="--h:100vh"><div class="w-sticky">
        <div class="w-hh">
          <div class="w-hh-copy">
            <span class="w-eyebrow w-rv">${LOGO("w-eyebrow-mark", "")}${esc(t("w_hero_eyebrow"))}</span>
            <h1 class="w-display w-rv">${esc(t("w_hero_a"))} <em style="color:#6e2135;-webkit-text-fill-color:#6e2135">${esc(t("w_hero_em"))}</em><br>${esc(t("w_hero_b"))}</h1>
            <p class="w-lede w-rv">${esc(t("w_hero_lede"))}</p>
            <div class="w-row w-rv"><a class="w-btn" href="#shop">${esc(t("b3_enter"))} ${ICON.arrow}</a><a class="w-btn ghost" href="#customize">${esc(t("custom_cta"))}</a></div>
          </div>
          <figure class="w-hh-arch w-rv"><span class="w-frame-im">${POSTER(1)}</span><figcaption>${LOGO("w-frame-mark", "")}<span>${esc(t("w_made"))}</span></figcaption></figure>
          <span class="w-hh-side" aria-hidden="true">${esc(t("w_side"))}</span>
          <div class="w-hh-trust w-rv">
            <span>${ICON.moon}${esc(t("w_trust1"))}</span>
            <span>${ICON.moon}${esc(t("w_trust2"))}</span>
            <span>${ICON.moon}${esc(t("w_trust3"))}</span>
          </div>
          <a class="w-scrollhint w-rv" href="#w-ch-arc" data-ui="scrollnext"><span>${esc(t("w_scroll"))}</span>${ICON.down}</a>
        </div>
      </div></section>
      <div class="w-ribbon" aria-hidden="true">${RIBBON()}</div>

      <section class="w-ch w-ch-arc" id="w-ch-arc" data-room="hall" data-shot="sets" style="--h:${100 + sets.length * 34}vh"><div class="w-sticky">
        <div class="w-arc-head w-rv"><span class="w-eyebrow">${LOGO("w-eyebrow-mark", "")}${esc(t("shelf_label"))}</span><span class="w-count" id="wSetCount">${pad2(si + 1)} / ${pad2(sets.length)}</span></div>
        <div class="w-arc" id="wArc">
          ${sets.map((p, i) => `<figure class="w-arc-card${i === si ? " on" : ""}" data-i="${i}"><a href="#p-${esc(p.id)}" aria-label="${esc(L(p.name))}">${p.image ? `<img src="${esc(p.image)}" alt="${esc(L(p.name))}" loading="${i < 2 ? "eager" : "lazy"}">` : Art().draw(p)}</a><figcaption><b>${esc(L(p.name))}</b><span>${fmt(p.price)}</span></figcaption></figure>`).join("")}
        </div>
        <div class="w-arc-foot w-rv">
          <a class="w-btn small" id="wArcCta" href="#p-${esc(s0 ? s0.id : "")}">${esc(t("w_arc_view"))} ${ICON.arrow}</a>
        </div>
        <span class="w-arc-hint" aria-hidden="true">${esc(t("w_arc_hint"))}</span>
      </div></section>

      <section class="w-ch w-ch-cz" data-room="atelier" data-shot="hero" style="--h:130vh"><div class="w-sticky">
        <div class="w-card w-card-side">
          <span class="w-eyebrow w-rv">${esc(t("truly_eyebrow"))}</span>
          <h2 class="w-title w-rv">${esc(t("custom_title"))}</h2>
          <p class="w-lede w-rv">${esc(t("custom_sub"))}</p>
          <div class="w-try w-rv">
            <label class="f" for="tryIn">${esc(t("choose_initials"))}<input type="text" id="tryIn" maxlength="12" value="${esc(tryV.text)}" data-in="try"></label>
            <div class="icon-pick" role="group" aria-label="${esc(t("c_icon_h"))}">${["moon", "heart", "star", "bow", "flower"].map((k) => `<button type="button" class="${tryV.icon === k ? "on" : ""}" data-act="tryicon" data-v="${k}" aria-pressed="${tryV.icon === k}" aria-label="${esc(t("icon_" + k))}">${Art().icon(k, 20, "#6e2135")}</button>`).join("")}</div>
            <p class="note">${esc(t("preview_note"))}</p>
          </div>
          <a class="w-btn w-rv" href="#customize">${esc(t("custom_cta"))} ${ICON.arrow}</a>
        </div>
      </div></section>

      <section class="w-ch w-ch-mix" data-room="mix" data-shot="hero" style="--h:130vh"><div class="w-sticky">
        <div class="w-card w-card-low">
          <span class="w-eyebrow w-rv">${esc(t("mix_eyebrow"))}</span>
          <h2 class="w-title w-rv">${esc(t("mix_title"))}</h2>
          <p class="w-lede w-rv">${esc(t("mix_sub"))}</p>
          <a class="w-btn w-rv" href="#mix">${esc(t("mix_cta"))} ${ICON.arrow}</a>
        </div>
        <div class="w-mixposters" aria-hidden="true"><figure class="w-poster">${POSTER(2)}</figure><figure class="w-poster">${POSTER(5)}</figure></div>
      </div></section>

      <section class="w-ch w-ch-kind" data-room="lounge" data-shot="bays" style="--h:150vh"><div class="w-sticky">
        <div class="w-kind-head w-rv">${LOGO("w-kind-logo", "")}<span class="w-eyebrow">${LOGO("w-eyebrow-mark", "")}${esc(t("nav_collections"))}</span><h2 class="w-title">${esc(t("comfort_title"))}</h2><p class="w-slogan">${esc(t("w_slogan"))}</p></div>
        <div class="w-kind-list">${colsK.map((c) => `<a class="w-kind w-kind-${c} w-rv" href="#shop-${c}">
          <span class="w-kind-art" aria-hidden="true">${KIND_ART[c]}</span>
          <span class="w-kind-chip">${KIND_ICON[c]}${esc(t("w_kind_" + c))}</span>
          <span class="w-kind-tx"><b>${esc(t("col_" + c))}</b><span>${esc(t("colh_" + c))}</span></span>
          <span class="w-kind-foot">${LOGO("w-kind-mark", "")}${ICON.arrow}</span></a>`).join("")}</div>
      </div></section>

      <section class="w-ch w-ch-gifts" data-room="gifts" data-shot="hero" style="--h:130vh"><div class="w-sticky">
        <div class="w-card w-card-low">
          <span class="w-eyebrow w-rv">${esc(t("nav_bundles"))}</span>
          <h2 class="w-title w-rv">${esc(t("b_title"))}</h2>
          <p class="w-lede w-rv">${esc(t("bundles_sub"))}</p>
          <p class="w-script w-rv">${esc(t("bundles_card"))}</p>
          <a class="w-btn w-rv" href="#bundles">${esc(t("bundles_cta"))} ${ICON.arrow}</a>
        </div>
        <div class="w-frames">
          <figure class="w-frame"><span class="w-frame-im"><img src="assets/posters/poster-4.jpg" alt="" decoding="async"></span><figcaption>${LOGO("w-frame-mark", "")}<span>${esc(t("b_title"))}</span></figcaption></figure>
          <figure class="w-frame"><span class="w-frame-im"><img src="assets/posters/poster-6.jpg" alt="" decoding="async"></span><figcaption>${LOGO("w-frame-mark", "")}<span>${esc(t("bundles_cta"))}</span></figcaption></figure>
        </div>
      </div></section>

      <section class="w-ch w-ch-story" data-room="gallery" data-shot="walk" style="--h:150vh"><div class="w-sticky">
        <div class="w-card w-card-side">
          <span class="w-eyebrow w-rv">${esc(t("st_eyebrow"))}</span>
          <h2 class="w-title w-rv">${esc(t("story_title"))}</h2>
          <p class="w-lede w-rv">${esc(t("story_sub"))}</p>
          <div class="w-values w-rv">${["v_comfort", "v_details", "v_timeless", "v_women"].map((k) => `<span>${LOGO("w-eyebrow-mark", "")}${esc(t(k))}</span>`).join("")}</div>
          <a class="w-btn w-rv" href="#story">${esc(t("story_cta"))} ${ICON.arrow}</a>
        </div>
        <div class="w-frames">
          <figure class="w-frame"><span class="w-frame-im"><img src="assets/brand-story.jpg" alt="${esc(t("story_title"))}" decoding="async"></span><figcaption>${LOGO("w-frame-mark", "")}<span>${esc(t("st_eyebrow"))}</span></figcaption></figure>
          <figure class="w-frame"><span class="w-frame-im"><img src="assets/posters/poster-2.jpg" alt="" decoding="async"></span><figcaption>${LOGO("w-frame-mark", "")}<span>${esc(t("w_made"))}</span></figcaption></figure>
        </div>
      </div></section>

      <section class="w-ch w-ch-end" data-room="gallery" data-shot="end" style="--h:130vh"><div class="w-sticky">
        <div class="w-close w-rv">
          <span class="w-eyebrow">${LOGO("w-eyebrow-mark", "")}${esc(t("w_hero_eyebrow"))}</span>
          <h2 class="w-close-line">${esc(t("w_slogan"))}</h2>
          <div class="w-end-strip" aria-hidden="true"><figure class="w-poster">${POSTER(1)}</figure><figure class="w-poster">${POSTER(3)}</figure><figure class="w-poster">${POSTER(5)}</figure><figure class="w-poster">${POSTER(6)}</figure></div>
          <div class="w-row"><a class="w-btn" href="#shop">${esc(t("b3_enter"))} ${ICON.arrow}</a><a class="w-btn ghost" href="${esc(st.instagram || "#")}" target="_blank" rel="noopener">Instagram</a></div>
        </div>
      </div></section>
    </div>`;
  }

  /* ---- shop: the round boutique ---- */
  function vShop(arg) {
    const x = X();
    const col = !arg ? "featured" : arg === "all" ? "all" : COLS.includes(arg) ? arg : "featured";
    if (U.shopCol !== col || !U.list.length) { U.shopCol = col; U.list = productsFor(col); U.idx = Math.min(U.idx, Math.max(0, U.list.length - 1)); if (U.lastShopCol !== col) U.idx = 0; }
    U.lastShopCol = col;
    const name = col === "featured" ? t("shelf_label") : col === "all" ? t("col_all") : t("col_" + col);
    x.setMeta(name, col === "featured" || col === "all" ? t("cold_all") : t("cold_" + col));
    const listOpen = U.listOpen;
    return `<div class="w-stage w-shop">
      ${tabBar(col)}
      <div class="w-stage-title w-rv"><span class="w-eyebrow">${esc(t("nav_collections"))}</span><h1 class="w-title">${esc(name)}</h1></div>
      ${caption()}
      <p class="w-coach" id="wCoach">${esc(coarse ? t("b3_coach_touch") : t("b3_coach"))}</p>
      <button type="button" class="w-chip w-listbtn" data-ui="list" aria-expanded="${!!listOpen}">${ICON.list} ${esc(t("w_list"))}</button>
      ${listOpen ? `<aside class="w-panel w-listpanel" aria-label="${esc(name)}"><button type="button" class="w-x" data-ui="list" aria-label="${esc(t("close"))}">${ICON.close}</button><div class="w-panel-in">${x.vCollection(col === "featured" ? "all" : col)}</div></aside>` : ""}
      <ul class="sr">${U.list.map((p) => `<li><a href="#p-${esc(p.id)}">${esc(L(p.name))}, ${esc(fmt(p.price))}</a></li>`).join("")}</ul>
      ${flatArt()}
    </div>
    <section class="w-shelf" aria-label="${esc(name)}">
      <div class="w-shelf-head"><span class="w-eyebrow">${ICON.moon}${esc(name)}</span>
        <p class="w-shelf-note">${esc(t("w_shelf_note"))}</p></div>
      <div class="w-shelf-grid">${U.list.map((p) => `<article class="w-shelfcard">
          <a class="w-shelf-img" href="#p-${esc(p.id)}" aria-label="${esc(L(p.name))}">
            ${p.image ? `<img src="${esc(p.image)}" alt="${esc(L(p.name))}" loading="lazy">` : Art().draw(p, { rack: p.type === "set" || p.type === "robe" })}
          </a>
          <div class="w-shelf-tx"><a href="#p-${esc(p.id)}"><b>${esc(L(p.name))}</b></a>
            <span class="w-shelf-price">${p.inStock === false ? esc(t("sold_out")) : fmt(p.price)}</span></div>
          <div class="w-shelf-acts">
            ${p.image ? `<button type="button" class="w-chip tn" data-ui="zoom" data-src="${esc(p.image)}" data-name="${esc(L(p.name))}">${ICON.zoom} ${esc(t("w_zoom"))}</button>` : ""}
            <a class="w-btn small" href="#p-${esc(p.id)}">${esc(t("b3_view"))}</a>
          </div>
        </article>`).join("")}</div>
    </section>`;
  }
  function tabBar(col) {
    return `<nav class="w-tabs" aria-label="${esc(t("b3_collections"))}">${tabs().map(([k, l]) => `<a href="#shop${k === "featured" ? "" : "-" + k}" class="${k === col ? "on" : ""}" ${k === col ? 'aria-current="true"' : ""}>${esc(t(l))}</a>`).join("")}</nav>`;
  }
  function caption() {
    const p = U.list[U.idx];
    return `<div class="w-caption">
      <button type="button" class="w-arrow" data-ui="prev" aria-label="${esc(t("b3_prev"))}" ${U.list.length < 2 ? "disabled" : ""}>${ICON.left}</button>
      <div class="w-cap-tx" aria-live="polite"><span class="w-count" id="wCapCount">${p ? pad2(U.idx + 1) + " / " + pad2(U.list.length) : ""}</span><span class="w-cap-name" id="wCapName">${p ? esc(L(p.name)) : ""}</span><span class="w-cap-price" id="wCapPrice">${p ? (p.inStock === false ? esc(t("sold_out")) : fmt(p.price)) : ""}</span></div>
      ${p && p.image ? `<button type="button" class="w-arrow" data-ui="zoom" data-src="${esc(p.image)}" data-name="${esc(L(p.name))}" aria-label="${esc(t("w_zoom"))}">${ICON.zoom}</button>` : ""}
      <a class="w-btn small" id="wCapView" href="#p-${p ? esc(p.id) : ""}">${esc(t("b3_view"))}</a>
      <button type="button" class="w-arrow" data-ui="next" aria-label="${esc(t("b3_next"))}" ${U.list.length < 2 ? "disabled" : ""}>${ICON.right}</button>
    </div>`;
  }
  function flatArt() {
    if (U.mode !== "flat") return "";
    const p = U.list[U.idx]; if (!p) return "";
    return `<div class="w-flatart">${p.image ? `<img src="${esc(p.image)}" alt="">` : Art().draw(p, { rack: p.type === "set" || p.type === "robe" })}</div>`;
  }

  /* ---- product: the piece in its alcove, with the product panel ---- */
  function vProduct(id) {
    const x = X(), p = P(id), s = S();
    if (!p) return null;
    if (s.pdp.id !== id) x.resetPdp(id);
    const st = s.pdp, col = x.colorOf(p, st.color);
    x.setMeta(L(p.name), L(p.desc)); x.productLd(p);
    if (s._viewed !== id) { s._viewed = id; x.track("view_item", { item_id: id, value: p.price, currency: "EGP" }); }
    // keep the boutique's list if the piece is in it, otherwise show its collection
    if (!U.list.some((q) => q.id === id)) { const c0 = (p.collections || [])[0]; U.shopCol = c0 || "all"; U.list = productsFor(U.shopCol); }
    U.idx = Math.max(0, U.list.findIndex((q) => q.id === id));
    const emb = x.canEmb(p), custom = st.c.on && st.c.text ? st.c : null;
    const unit = p.price + (custom ? x.fee() : 0);
    const n = U.list.length, prev = U.list[(U.idx - 1 + n) % n], next = U.list[(U.idx + 1) % n];
    const related = s.products.filter((q) => q.id !== p.id && (q.collections || []).some((c) => (p.collections || []).includes(c))).slice(0, 6);
    const col0 = (p.collections || [])[0], out = p.inStock === false;
    return `<div class="w-stage w-pdp">
      ${tabBar(U.shopCol)}
      <aside class="w-panel" aria-label="${esc(L(p.name))}" data-keep="pdp">
        <a class="w-x" href="#shop${U.shopCol === "featured" ? "" : "-" + U.shopCol}" aria-label="${esc(t("w_back_boutique"))}">${ICON.close}</a>
        <div class="w-panel-in">
          <div class="w-hop"><a href="#p-${esc(prev.id)}" class="w-arrow sm" aria-label="${esc(t("b3_prev"))}">${ICON.left}</a><span class="w-count">${pad2(U.idx + 1)} / ${pad2(n)}</span><a href="#p-${esc(next.id)}" class="w-arrow sm" aria-label="${esc(t("b3_next"))}">${ICON.right}</a></div>
          <span class="w-eyebrow">${esc(col0 ? t("col_" + col0) : "")}</span>
          <h1 class="w-title">${esc(L(p.name))}</h1>
          <div class="w-pricebig" id="pdpPrice">${fmt(unit)}${p.compareAt ? `<s>${fmt(p.compareAt)}</s>` : ""}</div>
          ${p.image ? `<button type="button" class="w-chip w-zoomb tn" data-ui="zoom" data-src="${esc(p.image)}" data-name="${esc(L(p.name))}">${ICON.zoom} ${esc(t("w_zoom"))}</button>` : ""}
          <div class="w-tags">${p.isNew ? `<span class="tag">${esc(t("badge_new"))}</span>` : ""}${emb ? `<span class="tag soft">${esc(t("badge_custom"))}</span>` : ""}${out ? `<span class="tag out">${esc(t("sold_out"))}</span>` : ""}</div>
          <p class="w-lede">${esc(L(p.desc))}</p>
          <div class="opt"><div class="opt-h"><span>${esc(t("colour"))}</span><span>${esc(col ? L(col.name) : "")}</span></div>
            <div class="sws">${p.colors.map((c) => swatch(c, c.key === st.color, `data-act="pcolor" data-v="${esc(c.key)}"`)).join("")}</div></div>
          <div class="opt"><div class="opt-h"><span>${esc(t("size"))}</span><a class="link" href="#help-size">${esc(t("size_guide"))}</a></div>
            <div class="chips">${p.sizes.map((z) => `<button type="button" class="chip ${st.size === z ? "on" : ""}" data-act="psize" data-v="${esc(z)}" aria-pressed="${st.size === z}" ${(p.soldOutSizes || []).includes(z) ? "disabled" : ""}>${esc(z)}</button>`).join("")}</div></div>
          ${emb ? `<div class="perso"><button type="button" class="perso-h" data-act="ptoggle" aria-expanded="${st.c.on}"><span>${ICON.moon} ${esc(t("personalize"))}</span><span class="note">${esc(t("personalize_fee", { p: fmt(x.fee()) }))}</span></button>
            ${st.c.on ? `<div class="in">${x.embControls("pdp", st.c, Art().placementsFor(p), "pdp")}<p class="note">${esc(t("c_note"))}</p></div>` : ""}</div>` : ""}
          ${st.err ? `<p class="err" role="alert">${esc(st.err)}</p>` : ""}
          <div class="buyrow"><div class="qty"><button type="button" data-act="pqty" data-d="-1" aria-label="-">−</button><span>${num(st.qty)}</span><button type="button" data-act="pqty" data-d="1" aria-label="+">+</button></div>
            <button type="button" class="w-btn addcart" data-act="padd" ${out ? "disabled" : ""}>${esc(out ? t("sold_out") : t("add_bag"))}</button></div>
          <div class="acc">
            <details open><summary>${esc(t("details"))}</summary><div class="body"><p>${esc(L(p.desc))}</p></div></details>
            <details><summary>${esc(t("fabric_care"))}</summary><div class="body"><p>${esc(L(p.fabric))}</p><a class="link" href="#help-care">${esc(t("h_care"))}</a></div></details>
            <details><summary>${esc(t("size_guide"))}</summary><div class="body"><p>${esc(x.SIZES.fit[s.lang])}</p><a class="link" href="#help-size">${esc(t("h_size"))}</a></div></details>
            <details><summary>${esc(t("delivery"))}</summary><div class="body"><p>${esc(t("delivery_line"))}</p><a class="link" href="#help-shipping">${esc(t("h_shipping"))}</a></div></details>
          </div>
          ${related.length ? `<div class="w-related"><h2 class="w-sub">${esc(t("you_may"))}</h2><div class="w-rail">${related.map((q) => `<a href="#p-${esc(q.id)}" class="w-mini"><span class="ph">${Art().draw(q)}</span><b>${esc(L(q.name))}</b><span>${fmt(q.price)}</span></a>`).join("")}</div></div>` : ""}
        </div>
      </aside>
      ${U.mode === "flat" ? `<div class="w-flatart">${p.image && !custom ? `<img src="${esc(p.image)}" alt="">` : Art().draw(p, { color: st.color, custom })}</div>` : ""}
    </div>`;
  }

  /* ---- customize: the atelier ---- */
  const CZ_STEPS = [[1, "c_step1", "piece"], [2, "c_step2", "text"], [3, "c_step3", "font"], [4, "c_step4", "thread"], [5, "c_step5", "place"], [6, "c_step6", "piece"]];
  function vCustomize() {
    const x = X(), s = S(), z = s.cz;
    x.setMeta(t("c_title"), t("c_sub"));
    const pieces = s.products.filter((p) => x.canEmb(p) && p.inStock !== false);
    if (!z.pid || !pieces.find((p) => p.id === z.pid)) z.pid = (pieces.find((p) => p.id === "classic-set") || pieces[0] || {}).id;
    const p = P(z.pid); if (!p) return null;
    if (!z.color || !p.colors.find((c) => c.key === z.color)) z.color = p.colors[0].key;
    const pls = Art().placementsFor(p);
    if (!pls.includes(z.placement)) z.placement = pls[0];
    if (z.size && !p.sizes.includes(z.size)) z.size = "";
    if (p.sizes.length === 1) z.size = p.sizes[0];
    const step = U.czStep;
    const FK = x.FONT_KEYS, TK = x.THREAD_KEYS, IK = x.ICON_KEYS;
    let body = "";
    if (step === 1) body = `<div class="piece-pick w-pick">${pieces.map((q) => `<button type="button" class="${q.id === p.id ? "on" : ""}" data-act="czp" data-v="${esc(q.id)}" aria-pressed="${q.id === p.id}"><span class="ph">${q.image ? `<img src="${esc(q.image)}" alt="" loading="lazy">` : Art().draw(q)}</span><span>${esc(L(q.name))}</span></button>`).join("")}</div>
        <div class="opt"><div class="opt-h"><span>${esc(t("colour"))}</span><span>${esc(L(x.colorOf(p, z.color).name))}</span></div><div class="sws">${p.colors.map((c) => swatch(c, c.key === z.color, `data-act="czc" data-v="${esc(c.key)}"`)).join("")}</div></div>
        <div class="opt"><div class="opt-h"><span>${esc(t("size"))}</span><a class="link" href="#help-size">${esc(t("size_guide"))}</a></div><div class="chips">${p.sizes.map((sz) => `<button type="button" class="chip ${z.size === sz ? "on" : ""}" data-act="czs" data-v="${esc(sz)}" aria-pressed="${z.size === sz}">${esc(sz)}</button>`).join("")}</div></div>`;
    else if (step === 2) body = `<label class="f" for="czText">${esc(t("c_step2"))}<input type="text" id="czText" maxlength="12" value="${esc(z.text)}" placeholder="${esc(t("c_text_ph"))}" data-in="embtext" data-scope="cz"><span class="hint">${esc(t("c_text_help"))}</span></label>
        <div class="opt"><div class="opt-h"><span>${esc(t("c_icon_h"))}</span><span>${esc(t("optional"))}</span></div><div class="icon-pick">${IK.map((k) => `<button type="button" class="${(z.icon || "") === k ? "on" : ""}" data-act="emb" data-scope="cz" data-k="icon" data-v="${k}" aria-pressed="${(z.icon || "") === k}" aria-label="${esc(t("icon_" + (k || "none")))}">${k ? Art().icon(k, 18, "#6e2135") : `<span style="font-size:.7rem">${esc(t("icon_none"))}</span>`}</button>`).join("")}</div></div>
        <label class="f" for="czNote">${esc(t("c_note_label"))} <span class="hint">${esc(t("optional"))}</span><textarea id="czNote" rows="2" maxlength="200" placeholder="${esc(t("c_note_ph"))}" data-in="embnote" data-scope="cz">${esc(z.note)}</textarea></label>`;
    else if (step === 3) body = `<div class="fontpick">${FK.map((k) => `<button type="button" class="${z.font === k ? "on" : ""}" data-act="emb" data-scope="cz" data-k="font" data-v="${k}" aria-pressed="${z.font === k}"><b style="font-family:${Art().FONTS[k]}">${esc(k === "mono" ? "M.a" : (z.text || "Aa").slice(0, 6))}</b><span>${esc(t("font_" + k))}</span></button>`).join("")}</div><p class="note">${esc(t("w_table_hint"))}</p>`;
    else if (step === 4) body = `<div class="threads">${TK.map((k) => `<button type="button" class="thread ${z.thread === k ? "on" : ""}" data-act="emb" data-scope="cz" data-k="thread" data-v="${k}" aria-pressed="${z.thread === k}"><i style="background:${Art().THREADS[k]}"></i>${esc(t("th_" + k))}</button>`).join("")}</div><p class="note">${esc(t("w_table_hint"))}</p>`;
    else if (step === 5) body = `<div class="placepick">${pls.map((k) => `<button type="button" class="${z.placement === k ? "on" : ""}" data-act="emb" data-scope="cz" data-k="placement" data-v="${k}" aria-pressed="${z.placement === k}">${x.glyph(k)}<span>${esc(t("pl_" + k))}</span></button>`).join("")}</div>`;
    else body = `<div class="cz-sum">
        <div class="ln"><span>${esc(L(p.name))} · ${esc(L(x.colorOf(p, z.color).name))}${z.size ? " · " + esc(z.size) : ""}</span><span>${fmt(p.price)}</span></div>
        <div class="ln"><span>${esc(t("c_fee"))}${z.text ? `: “${esc(z.text)}” · ${esc(t("font_" + z.font))} · ${esc(t("th_" + z.thread))} · ${esc(t("pl_" + z.placement))}${z.icon ? " · " + esc(t("icon_" + z.icon)) : ""}` : ""}</span><span>${fmt(x.fee())}</span></div>
        <div class="ln tot"><span>${esc(t("co_total"))}</span><span>${fmt(p.price + x.fee())}</span></div>
        <p class="note">${esc(t("c_note"))}</p></div>`;
    const done = { 1: !!z.size, 2: x.validText(z.text), 3: true, 4: true, 5: true, 6: false };
    const PLACE = { left: [53, 33], right: [43, 33], pocket: [55, 41], sleeve: [31, 48], trousers: [49, 66] };
    const pxy = PLACE[z.placement] || PLACE.left;
    const mono = z.text ? `<span class="w-cz-mono" data-place="${esc(z.placement)}" style="left:${pxy[0]}%;top:${pxy[1]}%;color:${Art().THREADS[z.thread] || "#6e2135"};font-family:${Art().FONTS[z.font] || Art().FONTS.script}">${esc(z.text)}</span>` : "";
    const stage = p.image
      ? `<figure class="w-cz-photo"><img src="${esc(p.image)}" alt="${esc(L(p.name))}" decoding="async"><figcaption>${esc(L(p.name))} · ${esc(L(x.colorOf(p, z.color).name))}</figcaption>${mono}</figure>`
      : `<div class="w-flatart">${Art().draw(p, { color: z.color, custom: { text: z.text || "L.N", font: z.font, thread: z.thread, placement: z.placement, icon: z.icon } })}</div>`;
    return `<div class="w-stage w-cz">
      ${stage}
      <div class="w-stage-title w-rv" ${step > 1 ? "hidden" : ""}><span class="w-eyebrow">${esc(t("nav_customize"))}</span><h1 class="w-title">${esc(t("c_tag"))}</h1></div>
      <aside class="w-panel" data-keep="cz" aria-label="${esc(t("c_title"))}">
        <div class="w-panel-in">
          <ol class="w-steps" aria-label="${esc(t("c_title"))}">${CZ_STEPS.map(([n, k]) => `<li><button type="button" data-ui="czstep" data-v="${n}" class="${n === step ? "on" : ""} ${done[n] ? "done" : ""}" aria-current="${n === step ? "step" : "false"}"><b>${num(n)}</b><span>${esc(t(k))}</span></button></li>`).join("")}</ol>
          <div class="w-stephead"><span class="w-count">${esc(t("w_step", { n: num(step), t: num(6) }))}</span><h2 class="w-sub">${esc(t("c_step" + step))}</h2><p class="note">${esc(t("c_step" + step + "s"))}</p></div>
          <div class="w-stepbody">${body}</div>
          ${z.err ? `<p class="err" role="alert">${esc(z.err)}</p>` : ""}
        </div>
        <div class="w-panel-foot">
          <div class="w-total"><span>${esc(t("co_total"))}</span><b>${fmt(p.price + x.fee())}</b></div>
          <div class="w-row">${step > 1 ? `<button type="button" class="w-btn ghost" data-ui="czstep" data-v="${step - 1}">${esc(t("w_back"))}</button>` : ""}
            ${step < 6 ? `<button type="button" class="w-btn" data-ui="czstep" data-v="${step + 1}">${esc(t("w_next"))} ${ICON.arrow}</button>` : `<button type="button" class="w-btn addcart" data-act="czadd">${esc(t("c_cta"))} ${ICON.arrow}</button>`}</div>
        </div>
      </aside>
      ${U.mode === "flat" ? `<div class="w-flatart">${Art().draw(p, { color: z.color, custom: { text: z.text || "Haya", font: z.font, thread: z.thread, placement: z.placement, icon: z.icon } })}</div>` : ""}
    </div>`;
  }

  /* ---- mix & match: the clothes lines ---- */
  const MX_STEPS = [[1, "pr_top"], [2, "pr_bottom"], [3, "pr_addons"], [4, "pr_custom"], [5, "pr_review"]];
  function mixLists() {
    const s = S().products;
    return {
      tops: s.filter((p) => p.type === "top" && p.inStock !== false),
      bottoms: s.filter((p) => p.type === "bottom" && p.inStock !== false),
      extras: s.filter((p) => (p.type === "robe" || p.type === "accessory") && p.inStock !== false && !(p.collections || []).includes("bridal") && !(p.collections || []).includes("postpartum"))
    };
  }
  function vMix() {
    const x = X(), s = S(), m = s.mix, lists = mixLists();
    x.setMeta(t("m_title"), t("m_sub"));
    // the line in view is always a choice: start with the first top and bottom
    if (!m.top && lists.tops[0]) { m.top = lists.tops[0].id; m.topColor = lists.tops[0].colors[0].key; }
    if (!m.bottom && lists.bottoms[0]) { m.bottom = lists.bottoms[0].id; m.bottomColor = lists.bottoms[0].colors[0].key; }
    const top = P(m.top), bot = P(m.bottom), q = x.mixQuote(), step = U.mxStep;
    const lineCtl = (which, list, cur, colKey, size) => {
      const i = Math.max(0, list.findIndex((p) => p.id === cur)), p = list[i];
      if (!p) return "";
      return `<div class="w-linectl">
        <div class="w-hop"><button type="button" class="w-arrow sm" data-ui="mxhop" data-w="${which}" data-d="-1" aria-label="${esc(t("b3_prev"))}">${ICON.left}</button>
          <div><span class="w-count">${pad2(i + 1)} / ${pad2(list.length)}</span><b class="w-hopname">${esc(L(p.name))}</b><span class="note">${fmt(p.price)}</span></div>
          <button type="button" class="w-arrow sm" data-ui="mxhop" data-w="${which}" data-d="1" aria-label="${esc(t("b3_next"))}">${ICON.right}</button></div>
        <div class="opt"><div class="opt-h"><span>${esc(t("colour"))}</span><span>${esc(L(x.colorOf(p, colKey).name))}</span></div><div class="sws">${p.colors.map((c) => swatch(c, c.key === colKey, `data-act="mxcol" data-w="${which}" data-p="${esc(p.id)}" data-v="${esc(c.key)}"`)).join("")}</div></div>
        <div class="opt"><div class="opt-h"><span>${esc(t("size"))}</span><a class="link" href="#help-size">${esc(t("size_guide"))}</a></div>
          <div class="chips">${p.sizes.map((sz) => `<button type="button" class="chip ${size === sz ? "on" : ""}" data-ui="mxsize" data-w="${which}" data-v="${esc(sz)}" aria-pressed="${size === sz}">${esc(sz)}</button>`).join("")}</div></div>
        ${p.image ? `<button type="button" class="w-linectl-img" data-ui="zoom" data-src="${esc(p.image)}" data-name="${esc(L(p.name))}" aria-label="${esc(t("w_zoom"))}"><img src="${esc(p.image)}" alt="${esc(L(p.name))}"></button>` : ""}
        <p class="note">${esc(t("w_mix_hint"))}</p>
      </div>`;
    };
    const embBlock = (scope, piece, stt, label, colKey) => !piece || !x.canEmb(piece) ? "" : `<div class="emb-block"><label class="check"><input type="checkbox" data-in="mxon" data-scope="${scope}" ${stt.on ? "checked" : ""}> ${esc(label)} <span class="note">${esc(t("personalize_fee", { p: fmt(x.fee()) }))}</span></label>
      ${stt.on ? `<div class="w-embgrid">${x.embControls(scope, stt, Art().placementsFor(piece), scope)}</div>` : ""}</div>`;
    void embBlock;
    let body = "";
    if (step === 1) body = lineCtl("top", lists.tops, m.top, m.topColor, m.topSize);
    else if (step === 2) body = lineCtl("bottom", lists.bottoms, m.bottom, m.bottomColor, m.bottomSize);
    else if (step === 3) body = `<div class="addons">${lists.extras.map((p) => { const a = m.addons[p.id]; return `<div class="addon ${a ? "on" : ""}"><span class="ph">${p.image ? `<img src="${esc(p.image)}" alt="">` : Art().draw(p)}</span><div><b>${esc(L(p.name))}</b><small>${fmt(p.price)}</small>
        ${a && p.sizes.length > 1 ? `<select data-in="mxasize" data-p="${esc(p.id)}" aria-label="${esc(t("size"))}">${p.sizes.map((sz) => `<option ${a.size === sz ? "selected" : ""}>${esc(sz)}</option>`).join("")}</select>` : ""}</div>
        <button type="button" data-act="mxadd" data-p="${esc(p.id)}" aria-pressed="${!!a}" aria-label="${esc(L(p.name))}">${a ? "✓" : "+"}</button></div>`; }).join("")}</div>`;
    else if (step === 4) body = (x.canEmb(top) || x.canEmb(bot)) ? [["mixtop", top, m.cTop, t("m_on_top") + (top ? ": " + L(top.name) : "")], ["mixbot", bot, m.cBot, t("personalize") + (bot ? ": " + L(bot.name) : "")]].map(([sc, pc, stt, lab]) => !pc || !x.canEmb(pc) ? "" : `<div class="emb-block"><label class="check"><input type="checkbox" data-in="mxon" data-scope="${sc}" ${stt.on ? "checked" : ""}> ${esc(lab)} <span class="note">${esc(t("personalize_fee", { p: fmt(x.fee()) }))}</span></label>${stt.on ? `<div class="w-embgrid">${x.embControls(sc, stt, Art().placementsFor(pc), sc)}</div>` : ""}</div>`).join("") : `<p class="note">${esc(t("w_mix_nocustom"))}</p>`;
    else {
      const lines = [];
      if (top) lines.push([t("m_top"), top, m.topColor, m.topSize, top.price, m.cTop.on && m.cTop.text ? m.cTop : null, 1]);
      if (bot) lines.push([t("m_bottom"), bot, m.bottomColor, m.bottomSize, bot.price, m.cBot.on && m.cBot.text ? m.cBot : null, 2]);
      Object.keys(m.addons).forEach((id) => { const p = P(id); if (p) lines.push([t("m_addon"), p, m.addons[id].color, m.addons[id].size, p.price, null, 3]); });
      body = `<div class="review">${lines.map(([lab, p, ck, sz, price, c, stp]) => `<div class="rv"><span class="th">${p.image && !c ? `<img src="${esc(p.image)}" alt="">` : Art().draw(p, { color: ck, custom: c })}</span>
          <span><b>${esc(lab)}</b> ${esc(L(p.name))}<br><span class="note">${esc(t("colour"))}: ${esc(L(x.colorOf(p, ck).name))} · ${esc(t("size"))}: ${esc(sz || "–")}</span>${c ? `<br><span class="emb">${x.embText(c)}</span>` : ""}</span>
          <span class="price">${fmt(price + (c ? x.fee() : 0))}</span><button type="button" class="link" data-ui="mxstep" data-v="${stp}">${esc(t("m_edit"))}</button></div>`).join("")}
        ${q.discount ? `<div class="rv tot ok"><span></span><span>${esc(t("m_save"))}</span><span class="price">−${fmt(q.discount)}</span><span></span></div>` : `<p class="note">${esc(t("m_save_note", { pct: num(S().settings.setDiscountPct || 0) }))}</p>`}</div>`;
    }
    /* what the customer is looking at: the top, the bottom, or both, in real photos */
    const view = U.mixView || "both";
    const figure = (which, piece, colKey) => {
      const p2 = piece; if (!p2) return "";
      const colName = L(x.colorOf(p2, colKey).name);
      const art = p2.image ? `<img src="${esc(p2.image)}" alt="${esc(L(p2.name))}">` : Art().draw(p2, { color: colKey });
      const zoom = p2.image ? `<button type="button" class="w-mixview-z" data-ui="zoom" data-src="${esc(p2.image)}" data-name="${esc(L(p2.name))}" aria-label="${esc(t("w_zoom"))}">${ICON.zoom}</button>` : "";
      return `<figure class="w-mixview-f" data-piece="${which}"><span class="w-mixview-im">${art}${zoom}</span>
        <figcaption><b>${esc(which === "top" ? t("w_piece_top") : t("w_piece_bottom"))}</b> ${esc(L(p2.name))}<span class="note">${esc(colName)} · ${esc(m[which + "Size"] || "–")}</span></figcaption></figure>`;
    };
    const viewer = `<div class="w-mixview" data-view="${esc(view)}">
      <div class="w-mixview-bar">
        <span class="w-eyebrow">${LOGO("w-eyebrow-mark", "")}${esc(t("w_looking_at"))}</span>
        <div class="w-mixview-seg" role="group" aria-label="${esc(t("w_looking_at"))}">
          <button type="button" data-ui="mixview" data-v="top" class="${view === "top" ? "on" : ""}" aria-pressed="${view === "top"}">${esc(t("w_piece_top"))}</button>
          <button type="button" data-ui="mixview" data-v="bottom" class="${view === "bottom" ? "on" : ""}" aria-pressed="${view === "bottom"}">${esc(t("w_piece_bottom"))}</button>
          <button type="button" data-ui="mixview" data-v="both" class="${view === "both" ? "on" : ""}" aria-pressed="${view === "both"}">${esc(t("w_piece_both"))}</button>
        </div>
      </div>
      <div class="w-mixview-grid">${figure("top", top, m.topColor)}${figure("bottom", bot, m.bottomColor)}</div>
    </div>`;
    const done = { 1: !!m.topSize, 2: !!m.bottomSize, 3: Object.keys(m.addons).length > 0, 4: (m.cTop.on && m.cTop.text) || (m.cBot.on && m.cBot.text), 5: false };
    return `<div class="w-stage w-mx">
      <div class="w-stage-title w-rv" ${step > 1 ? "hidden" : ""}><span class="w-eyebrow">${esc(t("m_eyebrow"))}</span><h1 class="w-title">${esc(t("mix_title"))}</h1></div>
      <aside class="w-panel" data-keep="mx" aria-label="${esc(t("m_title"))}">
        <div class="w-panel-in">
          <ol class="w-steps five">${MX_STEPS.map(([n, k]) => `<li><button type="button" data-ui="mxstep" data-v="${n}" class="${n === step ? "on" : ""} ${done[n] ? "done" : ""}" aria-current="${n === step ? "step" : "false"}"><b>${num(n)}</b><span>${esc(t(k))}</span></button></li>`).join("")}</ol>
          <div class="w-stephead"><span class="w-count">${esc(t("w_step", { n: num(step), t: num(5) }))}</span><h2 class="w-sub">${esc(t("m_s" + step))}</h2><p class="note">${esc(t("m_s" + step + "s"))}</p></div>
          ${step < 5 ? viewer : ""}
          <div class="w-stepbody">${body}</div>
          ${m.err ? `<p class="err" role="alert">${esc(m.err)}</p>` : ""}
        </div>
        <div class="w-panel-foot">
          <div class="w-total"><span>${esc(t("m_your"))}${q.discount ? ` <em>−${fmt(q.discount)}</em>` : ""}</span><b>${fmt(q.total)}</b></div>
          <div class="w-row">${step > 1 ? `<button type="button" class="w-btn ghost" data-ui="mxstep" data-v="${step - 1}">${esc(t("w_back"))}</button>` : ""}
            ${step < 5 ? `<button type="button" class="w-btn" data-ui="mxstep" data-v="${step + 1}">${esc(t("w_next"))} ${ICON.arrow}</button>` : `<button type="button" class="w-btn addcart" data-act="mxbag">${esc(t("m_add"))} ${ICON.arrow}</button>`}</div>
        </div>
      </aside>
      ${U.mode === "flat" ? `<div class="w-flatart two">${top ? Art().draw(top, { color: m.topColor }) : ""}${bot ? Art().draw(bot, { color: m.bottomColor }) : ""}</div>` : ""}
    </div>`;
  }

  /* ---- bundles: the gift salon ---- */
  const GIFT_COLORS = [["#f4cdd8", "#6e2135"], ["#fbf6ee", "#b88a5a"], ["#6e2135", "#f4cdd8"], ["#f6d6df", "#4f2b1f"]];
  function vBundles() {
    const x = X(), bs = S().bundles;
    x.setMeta(t("b_eyebrow"), t("b_sub"));
    U.giftIdx = Math.min(U.giftIdx, Math.max(0, bs.length - 1));
    const b = bs[U.giftIdx];
    const items = b ? b.items.map((id) => P(id)).filter(Boolean) : [];
    const lead = items.find((p) => p.image) || items[0];
    const figs = items.filter((p) => p.image).map((p) => `<figure class="w-gift-piece">${`<img src="${esc(p.image)}" alt="${esc(L(p.name))}" loading="lazy" decoding="async">`}<figcaption>${esc(L(p.name))}<span>${fmt(p.price)}</span></figcaption></figure>`).join("");
    const others = bs.map((q, i) => {
      const first = q.items.map((id) => P(id)).filter((p) => p && p.image)[0];
      return `<a class="w-shelfcard" href="#b-${esc(q.id)}" data-i="${i}">
        <span class="w-shelf-img">${first ? `<img src="${esc(first.image)}" alt="${esc(L(q.name))}" loading="lazy">` : ""}</span>
        <span class="w-shelf-tx"><b>${esc(L(q.name))}</b><span class="w-shelf-price">${fmt(q.price)}</span></span>
      </a>`;
    }).join("");
    return `<div class="w-stage w-gifts w-gifts-photo">
      <div class="w-gifts-head">
        <span class="w-eyebrow">${LOGO("w-eyebrow-mark", "")}${esc(t("b_eyebrow"))}</span>
        <h1 class="w-title">${esc(t("b_title"))}</h1>
        <p class="w-lede">${esc(t("b_sub"))}</p>
      </div>
      ${b ? giftCaption(b) : ""}
      <div class="w-gifts-body">
        ${lead ? `<figure class="w-gifts-lead">${lead.image ? `<img src="${esc(lead.image)}" alt="${esc(L(lead.name))}" decoding="async">` : ""}<figcaption>${esc(L(b.name))} · ${fmt(b.price)}</figcaption></figure>` : ""}
        <div class="w-gifts-pieces">${figs}</div>
      </div>
      <ul class="sr">${bs.map((q) => `<li><a href="#b-${esc(q.id)}">${esc(L(q.name))}, ${esc(fmt(q.price))}</a></li>`).join("")}</ul>
      <section class="w-shelf"><div class="w-shelf-head"><span class="w-eyebrow">${LOGO("w-eyebrow-mark", "")}${esc(t("nav_bundles"))}</span><p class="w-shelf-note">${esc(t("w_shelf_note"))}</p></div><div class="w-shelf-grid">${others}</div></section>
    </div>`;
  }


  function giftCaption(b) {
    const x = X(), worth = x.bWorth(b), bs = S().bundles;
    return `<div class="w-caption w-caption-gift">
      <button type="button" class="w-arrow" data-ui="gprev" aria-label="${esc(t("b3_prev"))}" ${bs.length < 2 ? "disabled" : ""}>${ICON.left}</button>
      <div class="w-cap-tx" aria-live="polite"><span class="w-count">${pad2(U.giftIdx + 1)} / ${pad2(bs.length)}</span><span class="w-cap-name">${esc(L(b.name))}</span>
        <span class="w-cap-price">${fmt(b.price)}${worth > b.price ? ` · <s>${esc(t("b_worth", { p: fmt(worth) }))}</s>` : ""}</span></div>
      <a class="w-btn small" href="#b-${esc(b.id)}">${esc(t("w_open_box"))}</a>
      <button type="button" class="w-arrow" data-ui="gnext" aria-label="${esc(t("b3_next"))}" ${bs.length < 2 ? "disabled" : ""}>${ICON.right}</button>
    </div>`;
  }
  function vBundle(id) {
    const x = X(), b = Bn(id);
    if (!b) return vBundles();
    x.setMeta(L(b.name), L(b.desc));
    U.giftIdx = Math.max(0, S().bundles.findIndex((q) => q.id === id));
    const sel = x.bState(b), worth = x.bWorth(b), out = x.bundleSoldOut(b);
    const fees = sel.filter((s) => x.validText(s.text)).length * x.fee();
    const FK = x.FONT_KEYS, TK = x.THREAD_KEYS, IK = x.ICON_KEYS;
    return `<div class="w-stage w-bundle">
      <aside class="w-panel" data-keep="bundle" aria-label="${esc(L(b.name))}">
        <a class="w-x" href="#bundles" aria-label="${esc(t("close"))}">${ICON.close}</a>
        <div class="w-panel-in">
          <span class="w-eyebrow">${esc(t("b_eyebrow"))}</span>
          <h1 class="w-title">${esc(L(b.name))}</h1>
          <div class="w-pricebig">${fmt(b.price)} <s>${esc(t("b_worth", { p: fmt(worth) }))}</s></div>
          ${worth > b.price ? `<span class="save">${esc(t("b_save", { p: fmt(worth - b.price) }))}</span>` : ""}
          <p class="w-lede">${esc(L(b.desc))}</p>
          ${sel.map((s, i) => {
            const p = P(s.pid); if (!p) return "";
            const pls = Art().placementsFor(p);
            const sb = (k, opts, label) => `<label class="f">${esc(label)}<select data-in="bopt" data-k="${k}" data-b="${esc(b.id)}" data-i="${i}">${opts.map(([v, l]) => `<option value="${v}" ${s[k] === v ? "selected" : ""}>${esc(l)}</option>`).join("")}</select></label>`;
            return `<div class="w-bpiece"><span class="ph">${Art().draw(p, { color: s.color, custom: x.validText(s.text) ? s : null })}</span><div class="opts">
              <b>${esc(t("b_each", { n: num(i + 1) }))}: ${esc(L(p.name))}</b>
              <div class="sws">${p.colors.map((c) => swatch(c, c.key === s.color, `data-act="bcol" data-b="${esc(b.id)}" data-i="${i}" data-v="${esc(c.key)}"`)).join("")}</div>
              <div class="chips">${p.sizes.map((sz) => `<button type="button" class="chip ${s.size === sz ? "on" : ""}" data-act="bsize" data-b="${esc(b.id)}" data-i="${i}" data-v="${esc(sz)}">${esc(sz)}</button>`).join("")}</div>
              ${x.canEmb(p) ? `<details class="bemb" ${s.text ? "open" : ""}><summary>${ICON.moon} ${esc(t("personalize"))} <span class="note">${esc(t("personalize_fee", { p: fmt(x.fee()) }))}</span></summary>
                <div class="row3">
                  <label class="f">${esc(t("c_step2"))}<input type="text" maxlength="12" value="${esc(s.text)}" placeholder="${esc(t("c_text_ph"))}" data-in="btext" data-b="${esc(b.id)}" data-i="${i}"></label>
                  ${sb("font", FK.map((k) => [k, t("font_" + k)]), t("font"))}${sb("thread", TK.map((k) => [k, t("th_" + k)]), t("thread"))}
                  ${sb("placement", pls.map((k) => [k, t("pl_" + k)]), t("placement"))}${sb("icon", IK.map((k) => [k, t("icon_" + (k || "none"))]), t("icon"))}
                  <label class="f">${esc(t("c_note_label"))}<input type="text" maxlength="200" value="${esc(s.note)}" data-in="bnote" data-b="${esc(b.id)}" data-i="${i}"></label>
                </div></details>` : ""}
            </div></div>`;
          }).join("")}
          <details class="w-defs"><summary>${esc(t("b_includes"))}</summary>${x.bDefs(b)}</details>
          <p class="note">${esc(t("b_future"))}</p>
          ${S().bErr ? `<p class="err" role="alert">${esc(S().bErr)}</p>` : ""}
        </div>
        <div class="w-panel-foot">
          <div class="w-total"><span>${esc(t("co_total"))}${fees ? ` <em>+${fmt(fees)}</em>` : ""}</span><b>${fmt(b.price + fees)}</b></div>
          <button type="button" class="w-btn addcart" data-act="badd" data-b="${esc(b.id)}" ${out ? "disabled" : ""}>${esc(out ? t("sold_out") : t("b_add"))} ${ICON.arrow}</button>
        </div>
      </aside>
      ${U.mode === "flat" ? `<div class="w-flatart three">${b.items.map((id) => P(id) ? Art().draw(P(id)) : "").join("")}</div>` : ""}
    </div>`;
  }

  /* ---- our story: the gallery ---- */
  function vStory() {
    const x = X(), st = S().settings;
    x.setMeta(t("st_title"), t("st_open"));
    const extra = (n) => n === 4 ? `<div class="palette-row">${["#fad6e1", "#f6e7f1", "#fbf8ef", "#6e2135", "#4f2b1f"].map((c) => `<i style="background:${c}"></i>`).join("")}</div>`
      : n === 5 ? `<div class="chips">${COLS.map((c) => `<a class="chip" href="#shop-${c}">${esc(t("col_" + c))}</a>`).join("")}</div>`
        : n === 6 ? `<div class="chips"><a class="chip" href="${esc(st.instagram || "#")}" target="_blank" rel="noopener">Instagram</a><a class="chip" href="${esc(st.tiktok || "#")}" target="_blank" rel="noopener">TikTok</a><a class="chip" href="${esc(st.pinterest || "#")}" target="_blank" rel="noopener">Pinterest</a></div>` : "";
    return `<div class="w-story" data-room="gallery">
      <section class="w-sch w-sch-open"><div class="w-card w-card-center w-rv"><span class="w-eyebrow">${esc(t("st_eyebrow"))}</span><h1 class="w-display">${esc(t("st_title"))}</h1><p class="w-lede">${esc(t("st_open"))}</p>
        <div class="w-values">${["v_comfort", "v_details", "v_timeless", "v_women"].map((k) => `<span>${LOGO("w-eyebrow-mark", "")}${esc(t(k))}</span>`).join("")}</div></div></section>
      ${[1, 2, 3, 4, 5, 6].map((n) => `<section class="w-sch ${n % 2 ? "r" : "l"}"><div class="w-card w-rv"><span class="w-count">${pad2(n)} / ${pad2(6)}</span><h2 class="w-title">${esc(t("st_h" + n))}</h2><p class="w-lede">${esc(t("st_p" + n))}</p>${extra(n)}</div></section>`).join("")}
    </div>`;
  }

  /* ------------------------------------------------ pages we only frame */
  const READ_ROUTES = ["help", "creators", "checkout", "pay", "order", "admin"];
  function frameRead() {
    const m = $("#main"); if (!m || m.querySelector(":scope > .w-read")) return;
    const wrap = document.createElement("div"); wrap.className = "w-read";
    const inner = document.createElement("div"); inner.className = "w-read-in";
    while (m.firstChild) inner.appendChild(m.firstChild);
    wrap.appendChild(inner); m.appendChild(wrap);
  }

  /* ----------------------------------------------- before / after render */
  function before() {
    U.keep = {};
    $$("[data-keep]").forEach((el) => { const s = el.querySelector(".w-panel-in"); if (s) U.keep[el.dataset.keep] = s.scrollTop; });
    const lp = $(".w-listpanel .w-panel-in"); if (lp) U.keep.list = lp.scrollTop;
  }
  function measureTop() {
    const h = document.getElementById("hdr"); if (!h) return;
    document.documentElement.style.setProperty("--top", Math.round(h.getBoundingClientRect().bottom) + "px");
  }
  function after(r, soft) {
    const body = document.body;
    const key = r.name + ":" + r.arg;
    const changed = key !== U.lastKey; U.lastKey = key;
    body.classList.toggle("w-on", true);
    const stage = ["shop", "p", "customize", "mix", "bundles", "b"].includes(r.name);
    body.classList.toggle("w-stage-on", stage);
    const scrollPage = r.name === "shop" || r.name === "bundles";
    body.classList.toggle("w-scroll", scrollPage);   // these two pages scroll like normal pages
    body.classList.toggle("w-photo-stage", r.name === "bundles" || r.name === "customize");   // photography; the shop keeps its room
    body.classList.toggle("w-photo-home", false);   // the home is a 3D journey again
    body.classList.toggle("w-scroll-on", r.name === "home" || r.name === "story");
    body.classList.toggle("w-read-on", READ_ROUTES.includes(r.name));
    body.dataset.route = r.name;
    if (READ_ROUTES.includes(r.name)) frameRead();
    // keep panel scroll positions through soft re-renders
    $$("[data-keep]").forEach((el) => { const s = el.querySelector(".w-panel-in"), v = U.keep[el.dataset.keep]; if (s && v != null && soft) s.scrollTop = v; });
    const lp = $(".w-listpanel .w-panel-in"); if (lp && U.keep.list != null && soft) lp.scrollTop = U.keep.list;
    if (changed) {
      const m = $("#main"); m.classList.remove("w-enter"); void m.offsetWidth; m.classList.add("w-enter");
      setTimeout(() => m.classList.remove("w-enter"), 1400);
      U.chapter = -1;
    }
    reveal();
    requestAnimationFrame(measureTop);
    sync(r, changed);
    if (r.name === "home" || r.name === "story") onScroll();
  }
  /* blur-to-sharp entrances as things come into view (Scrolltide-style focus reveal) */
  let io = null;
  function reveal() {
    if (!("IntersectionObserver" in window) || mqReduce.matches) { $$(".w-rv").forEach((e) => e.classList.add("in")); return; }
    if (!io) io = new IntersectionObserver((es) => es.forEach((e) => { if (e.isIntersecting) e.target.classList.add("in"); }), { threshold: 0.18 });
    $$(".w-rv:not(.in)").forEach((e) => io.observe(e));
  }

  /* -------------------------------------------- driving the 3D world */
  function sync(r, changed) {
    const W = U.world;
    const layout = (r.name === "p" || r.name === "customize" || r.name === "mix" || r.name === "b") ? sideLayout() : "full";
    if (W) W.setLayout(layout);
    if (r.name !== "home") setFlat(roomFor(r));   /* on the home the chapter watcher owns the backdrop */
    if (!W || U.door) return;
    switch (r.name) {
      case "home": syncHome(changed); break;
      case "shop": syncShop(changed); break;
      case "p": syncProduct(r.arg, changed); break;
      case "customize": syncCz(changed); break;
      case "mix": syncMix(changed); break;
      case "bundles": syncGifts(false, changed); break;
      case "b": syncGifts(true, changed); break;
      case "story": syncStory(changed); break;
      default: W.ensure("lounge").then((lg) => { dressLounge(lg); W.go("lounge", "reading"); });
    }
  }
  function roomFor(r) {
    return { home: "hall", shop: "hall", p: "dressing", customize: "atelier", mix: "mix", bundles: "gifts", b: "gifts", story: "gallery" }[r.name] || "lounge";
  }
  function setFlat(room) {
    if (U.mode !== "flat") return;
    const bg = $("#w3bg"); if (!bg) return;
    const img = room === "mix" ? "dressing" : room;   /* mix & match lives in the dressing room */
    if (room !== U.flatRoom || !bg.style.backgroundImage) { U.flatRoom = room; bg.style.backgroundImage = `url(assets/rooms/${img}.jpg)`; }
  }
  function hallItems() {
    const W = U.world, hall = W.get("hall");
    const sig = U.shopCol + ":" + U.list.map((p) => p.id).join(",");
    if (hall._sig !== sig) { hall._sig = sig; hall.setItems(U.list.map((p) => itemFor(p)), U.idx); hall.preload(U.list.slice(0, 10).map((p) => itemFor(p))); }
    return hall;
  }
  function syncShop() {
    const W = U.world;
    W.go("hall", "rotunda").then(() => {
      const hall = hallItems();
      if (hall.phase() !== "rotunda") hall.toRotunda();
      hall.focus(false);
      if (hall.current().index !== U.idx) hall.goToIndex(U.idx);
      hall.onIndex = (k, i) => { if (i !== U.idx && routeOf().name === "shop") { U.idx = i; refreshCaption(); } };
      // restore the colour of a plate changed on a product page
      if (U.recolored != null) { const p = U.list[U.recolored]; if (p) hall.refreshItem(U.recolored, itemFor(p)); U.recolored = null; }
    });
    coach();
  }
  function syncProduct(id) {
    const W = U.world, p = P(id); if (!p) return;
    W.go("hall", "rotunda").then(() => {
      const hall = hallItems();
      if (hall.phase() !== "rotunda") hall.toRotunda();
      const s = S().pdp, custom = s.c.on && s.c.text ? s.c : null;
      if (hall.current().index !== U.idx) hall.goToIndex(U.idx);
      const it = itemFor(p, s.color, custom);
      if (U.plateKey !== it.key) { U.plateKey = it.key; hall.refreshItem(U.idx, it); U.recolored = U.idx; }
      hall.focus(true);
      hall.onIndex = null;
    });
  }
  function refreshCaption() {
    const p = U.list[U.idx]; if (!p) return;
    const set = (id, v) => { const e = document.getElementById(id); if (e) e.textContent = v; };
    set("wCapCount", pad2(U.idx + 1) + " / " + pad2(U.list.length)); set("wCapName", L(p.name)); set("wCapPrice", p.inStock === false ? t("sold_out") : fmt(p.price));
    const v = $("#wCapView"); if (v) v.href = "#p-" + p.id;
    const fa = $(".w-flatart"); if (fa) fa.innerHTML = p.image ? `<img src="${esc(p.image)}" alt="">` : Art().draw(p, { rack: p.type === "set" || p.type === "robe" });
  }
  function czState() {
    const z = S().cz, p = P(z.pid); if (!p) return null;
    const col = (p.colors || []).find((c) => c.key === z.color) || p.colors[0];
    const custom = { text: z.text || "Haya", font: z.font, thread: z.thread, placement: z.placement, icon: z.icon };
    return { p, col, custom };
  }
  function pushAtelier() {
    const W = U.world, at = W && W.get("atelier"); if (!at) return;
    const c = czState(); if (!c) return;
    const labels = {}; ["script", "serif", "sans", "hand", "mono"].forEach((k) => { labels[k] = t("font_" + k); });
    at.set({
      board: c.p.image ? { photo: c.p.image } : Art().draw(c.p, { color: c.col.key, custom: c.custom, rack: c.p.type === "set" || c.p.type === "robe" }), tint: c.col.base,
      hoop: Art().draw(c.p, { color: c.col.key, custom: c.custom, zoom: true }), base: c.col.base,
      thread: c.custom.thread, font: c.custom.font, labels, sample: (S().cz.text || "Aa").slice(0, 6)
    });
  }
  function syncCz() {
    const W = U.world, shot = CZ_STEPS[U.czStep - 1][2];
    W.ensure("atelier").then(() => { pushAtelier(); W.go("atelier", U.czStep === 6 ? "piece" : shot); });
  }
  function syncMix() {
    const W = U.world;
    W.ensure("mix").then((mx) => {
      const m = S().mix, lists = mixLists();
      /* the key never contains the colour: choosing another colour only re-renders the panel,
         it must not rebuild the hanging piece (that was the texture flash) */
      const line = (arr, cur, colKey) => arr.map((p) => {
        if (p.image) return { key: p.id + ":photo", id: p.id, photo: p.image, tint: p.colors[0].base };
        const ck = p.id === cur ? colKey : p.colors[0].key;
        return { key: p.id + ":" + ck, id: p.id, svg: Art().draw(p, { color: ck }) }; });
      const ti = Math.max(0, lists.tops.findIndex((p) => p.id === m.top)), bi = Math.max(0, lists.bottoms.findIndex((p) => p.id === m.bottom));
      mx.setLine("top", line(lists.tops, m.top, m.topColor), ti, U.mxStep === 1);
      mx.setLine("bottom", line(lists.bottoms, m.bottom, m.bottomColor), bi, U.mxStep === 2);
      W.go("mix", U.mxStep === 1 ? "top" : U.mxStep === 2 ? "bottom" : "wide");
    });
  }
  function giftData() {
    return S().bundles.map((b, i) => ({ key: b.id, color: GIFT_COLORS[i % 4][0], accent: GIFT_COLORS[i % 4][1], items: b.items.map((id) => P(id)).filter(Boolean).map((p) => (p.image ? { key: "g:" + p.id + ":photo", photo: p.image, tint: p.colors[0].base } : { key: "g:" + p.id, svg: Art().draw(p), tint: p.colors[0].base })) }));
  }
  function syncGifts(open) {
    const W = U.world;
    W.ensure("gifts").then((g) => {
      g.setGifts(giftData()); g.select(U.giftIdx, open);
      W.go("gifts", open ? "open" : "box", { index: U.giftIdx });
    });
  }
  function storyPanels() {
    const pr = (id, o) => { const p = P(id); return p ? Art().draw(p, o || {}) : ""; };
    return [
      { key: "s1", photo: "assets/brand-bedroom.jpg" },
      { key: "s2", svg: pr("classic-set", { custom: { text: "L.N", font: "script", thread: "burgundy", placement: "left", icon: "moon" }, rack: true }), tint: "#f4cdd8" },
      { key: "s3", svg: pr("classic-top", { custom: { text: "Noon", font: "script", thread: "burgundy", placement: "pocket", icon: "heart" }, zoom: true }), tint: "#f4cdd8" },
      { key: "s4", tint: "#fad6e1", draw: async (x, w, h, s) => { const cols = ["#fad6e1", "#f6e7f1", "#fbf8ef", "#6e2135", "#4f2b1f"]; cols.forEach((c, i) => { x.fillStyle = c; x.beginPath(); x.arc(w * (0.2 + i * 0.15), h * 0.62, 52 * s, 0, Math.PI * 2); x.fill(); x.strokeStyle = "rgba(184,149,90,.6)"; x.lineWidth = 3 * s; x.stroke(); }); const lg = U.world && U.world.debug ? null : null; void lg; x.fillStyle = "#b88a5a"; x.beginPath(); x.arc(w / 2, h * 0.3, 70 * s, 0, Math.PI * 2); x.arc(w / 2 + 30 * s, h * 0.3 - 18 * s, 58 * s, 0, Math.PI * 2, true); x.fill("evenodd"); } },
      { key: "s5", svg: pr("crescent-set", { rack: true }), tint: "#fbf6ee" },
      { key: "s6", photo: "assets/brand-crescents.jpg" }
    ];
  }
  function syncStory() {
    const W = U.world;
    W.ensure("gallery").then((g) => { g.setPanels(storyPanels()); W.go("gallery", "walk"); onScroll(); });
  }
  function dressLounge(lg) {
    const bays = ["winter", "summer", "bridal", "postpartum"].map((c) => ({ key: c, colors: S().products.filter((p) => (p.collections || []).includes(c)).flatMap((p) => p.colors.map((x) => ({ base: x.base, accent: x.accent }))) }));
    lg.setBays(bays);
  }
  /* home: each chapter is a room; scrolling inside a chapter moves the camera */
  function syncHome() { onScroll(true); }
  function chapterGo(el, i, force) {
    const W = U.world; if (!W) return;
    const room = el.dataset.room, shot = el.dataset.shot;
    if (!room) { U.chapter = i; return; }
    U.chapter = i;
    W.ensure(room).then((r) => {
      if (room === "hall") { hallHome(); if (r.phase() !== "rotunda") r.toRotunda(); r.focus(shot === "sets"); if (shot === "sets") r.goToIndex(U.setI || 0); }
      if (room === "atelier") pushTry();
      if (room === "mix") syncMixHome(r);
      if (room === "gifts") { r.setGifts(giftData()); r.select(-1, false); }
      if (room === "gallery") r.setPanels(storyPanels());
      if (room === "lounge") dressLounge(r);
      W.go(room, shot);
    });
    void force;
  }
  function hallHome() {
    const W = U.world, hall = W.get("hall"); if (!hall) return;
    const sets = productsFor("featured").filter((p) => p.type === "set").slice(0, 6);
    if (U.shopCol !== "featured" || U.list.length !== sets.length) { U.shopCol = "featured-home"; U.list = sets; }
    hallItems();
  }
  function pushTry() {
    const at = U.world && U.world.get("atelier"); if (!at) return;
    const p = P("classic-set") || S().products.find((q) => q.customizable); if (!p) return;
    const tr = S().homeTry, custom = { text: tr.text || "L.N", font: "script", thread: "burgundy", placement: "left", icon: tr.icon };
    const labels = {}; ["script", "serif", "sans", "hand", "mono"].forEach((k) => { labels[k] = t("font_" + k); });
    at.set({ board: p.image ? { photo: p.image } : Art().draw(p, { color: p.colors[0].key, custom, rack: true }), tint: p.colors[0].base, hoop: Art().draw(p, { color: p.colors[0].key, custom, zoom: true }), base: p.colors[0].base, thread: "burgundy", font: "serif", labels, sample: (tr.text || "Aa").slice(0, 6) });
  }
  function syncMixHome(mx) {
    const lists = mixLists();
    const item = (p) => p.image
      ? { key: p.id + ":photo", id: p.id, photo: p.image, tint: p.colors[0].base }
      : { key: p.id + ":" + p.colors[0].key, id: p.id, svg: Art().draw(p) };   /* colour-free key */
    mx.setLine("top", lists.tops.map(item), 0, false);
    mx.setLine("bottom", lists.bottoms.map(item), 0, false);
  }
  /* the 3D reads how hard the visitor is scrolling: fast flicks move the camera at once */
  function feedSpeed(dy, dt) {
    const W = U.world; if (!W) return;
    const v = Math.min(1, (dy / Math.max(8, dt)) / 3.2);
    const s = Math.max(v, (U.speedSmooth || 0) * 0.55);
    U.speedSmooth = s; W.setSpeed(s);
  }
  function onScroll() {
    cancelAnimationFrame(U.scrollRaf);
    U.scrollRaf = requestAnimationFrame(() => {
      const r = routeOf().name, W = U.world;
      const y0 = window.scrollY || document.documentElement.scrollTop || 0, now = performance.now();
      const hdrS = $("#hdr"); if (hdrS) hdrS.classList.toggle("w-solid", y0 > 24);
      if (W) { feedSpeed(Math.abs(y0 - (U.lastY == null ? y0 : U.lastY)), now - (U.lastT || now - 16)); }
      U.lastY = y0; U.lastT = now;
      if (r === "home") {
        const chs = $$(".w-ch"); if (!chs.length) return;
        const vh = window.innerHeight;
        let active = 0;
        chs.forEach((el, i) => { const b = el.getBoundingClientRect(); if (b.top <= vh * 0.5) active = i; });
        const el = chs[active], b = el.getBoundingClientRect();
        const prog = Math.min(1, Math.max(0, -b.top / Math.max(1, b.height - vh)));
        if (active !== U.chapter) { if (U.mode === "flat") { U.chapter = active; setFlat(el.dataset.room); } else chapterGo(el, active); }
        /* the photograph breathes with the scroll: a slow drift, never a bounce */
        if (U.mode === "flat") {
          const bg = $("#w3bg");
          if (bg) bg.style.transform = "scale(" + (1.05 + prog * 0.05).toFixed(3) + ") translateY(" + ((prog - 0.5) * -16).toFixed(1) + "px)";
        }
        if (W) W.setProgress(prog);
        chs.forEach((c, i) => c.classList.toggle("active", i === active));

        if (el.dataset.room === "lounge") { const i = Math.min(3, Math.floor(prog * 4)); $$(".w-kind").forEach((k, j) => k.classList.toggle("on", j === i)); }
        if (el.classList.contains("w-ch-arc")) arcApply(prog);
        const hdr = $("#hdr"); if (hdr) hdr.classList.toggle("w-solid", active > 0 || b.top < -40);
      } else if (r === "story") {
        const doc = document.documentElement, max = Math.max(1, doc.scrollHeight - window.innerHeight);
        const prog = Math.min(1, window.scrollY / max);
        if (W) W.setProgress(prog);
      }
    });
  }
  /* ---------------------------------------------------------- concave rail
     The rail turns with the scroll: the middle frame faces you, its neighbours
     lean away and fall back. Nothing snaps — every frame is a pure function of
     the scroll position, so it is smooth at any scroll speed and cannot glitch. */
  function arcApply(prog) {
    const arc = document.querySelector("#wArc"); if (!arc) return;
    const cards = arc.querySelectorAll(".w-arc-card"); const n = cards.length; if (!n) return;
    const a = Math.max(0, Math.min(n - 1, prog * (n - 1)));
    cards.forEach((c, i) => {
      const off = i - a, ab = Math.abs(off);
      const near = Math.min(1, ab);
      const rot = Math.max(-48, Math.min(48, off * 19));
      const x = off * (cardW() * 1.02);
      const z = -Math.pow(near, 1.2) * cardW() * 0.52;
      const sc = 1 - near * 0.06;
      c.style.transform = "translate3d(" + x.toFixed(1) + "px,0," + z.toFixed(1) + "px) rotateY(" + (-rot).toFixed(2) + "deg) scale(" + sc.toFixed(3) + ")";
      c.style.opacity = "1";
      c.style.zIndex = String(1000 - Math.round(ab * 100));
      c.classList.toggle("on", Math.round(a) === i);
    });
    const i0 = Math.round(a);
    if (U.arcI !== i0) {
      U.arcI = i0;
      const sets = productsFor("featured").filter((p) => p.type === "set").slice(0, 6), pp = sets[i0];
      if (pp) {
        const nm = document.getElementById("wArcName"); if (nm) nm.textContent = L(pp.name);
        const ct = document.getElementById("wArcCta"); if (ct) ct.href = "#p-" + pp.id;
        const cn = document.getElementById("wSetCount"); if (cn) cn.textContent = pad2(i0 + 1) + " / " + pad2(n);
      }
    }
  }
  function cardW() { const c = document.querySelector(".w-arc-card"); return c ? c.offsetWidth : 300; }

  /* the signature sets: one screen, a set changes only when its thumbnail is clicked */
  function showSet(i, force) {
    const sets = productsFor("featured").filter((p) => p.type === "set").slice(0, 6), n = sets.length; if (!n) return;
    i = Math.max(0, Math.min(n - 1, i | 0));
    if (U.setI === i && !force) return; U.setI = i;
    const p = sets[i];
    const set = (id, v) => { const e = document.getElementById(id); if (e) e.textContent = v; };
    const nm = $("#wSetName"); if (nm) { nm.classList.remove("swap"); void nm.offsetWidth; nm.classList.add("swap"); }
    set("wSetName", L(p.name)); set("wSetPrice", fmt(p.price)); set("wSetCount", pad2(i + 1) + " / " + pad2(n));
    const cta = $("#wSetCta"); if (cta) cta.href = "#p-" + p.id;
    const bigImg = $("#wSetImg"); if (bigImg && p.image && bigImg.src !== p.image) bigImg.src = p.image;
    $$(".w-thumbs button").forEach((b, j) => { b.classList.toggle("on", j === i); b.setAttribute("aria-pressed", String(j === i)); });
    const hall = U.world && U.world.get("hall"); if (hall && U.world.room() === "hall") hall.goToIndex(i);
  }

  /* ------------------------------------------------------------ zoom view */
  function zoomDom() {
    let z = $("#wzoom");
    if (z) return z;
    z = document.createElement("div");
    z.id = "wzoom"; z.className = "w-zoom"; z.hidden = true;
    z.setAttribute("role", "dialog"); z.setAttribute("aria-modal", "true"); z.setAttribute("aria-label", t("w_zoom"));
    z.innerHTML = `<div class="w-zoom-bar">
        <span class="w-zoom-name"></span>
        <button type="button" class="w-zoom-b" data-z="out" aria-label="−">−</button>
        <button type="button" class="w-zoom-b" data-z="in" aria-label="+">+</button>
        <button type="button" class="w-zoom-b" data-z="reset" aria-label="${esc(t("w_zoom_reset"))}">1:1</button>
        <button type="button" class="w-zoom-b w-zoom-x" data-z="close" aria-label="${esc(t("close"))}">${ICON.close}</button>
      </div>
      <div class="w-zoom-stage"><img alt=""></div>`;
    document.body.appendChild(z);
    let sc = 1, tx = 0, ty = 0, drag = null;
    const img = z.querySelector("img"), stage = z.querySelector(".w-zoom-stage");
    const apply = () => { img.style.transform = `translate(${tx}px, ${ty}px) scale(${sc})`; z.classList.toggle("zoomed", sc > 1.02); };
    const reset = () => { sc = 1; tx = 0; ty = 0; apply(); };
    z.addEventListener("click", (e) => {
      const b = e.target.closest("[data-z]");
      if (!b) { if (e.target === z || e.target === stage) close(); return; }
      const k = b.dataset.z;
      if (k === "close") return close();
      if (k === "reset") return reset();
      sc = Math.min(6, Math.max(1, sc * (k === "in" ? 1.35 : 1 / 1.35)));
      if (sc === 1) { tx = 0; ty = 0; }
      apply();
    });
    stage.addEventListener("wheel", (e) => { e.preventDefault(); sc = Math.min(6, Math.max(1, sc * (e.deltaY < 0 ? 1.12 : 1 / 1.12))); if (sc === 1) { tx = 0; ty = 0; } apply(); }, { passive: false });
    stage.addEventListener("pointerdown", (e) => { if (sc <= 1) return; drag = { x: e.clientX - tx, y: e.clientY - ty }; try { stage.setPointerCapture(e.pointerId); } catch (err) {} });
    stage.addEventListener("pointermove", (e) => { if (!drag) return; tx = e.clientX - drag.x; ty = e.clientY - drag.y; apply(); });
    stage.addEventListener("pointerup", () => { drag = null; });
    stage.addEventListener("dblclick", () => { sc = sc > 1 ? 1 : 2.4; if (sc === 1) { tx = 0; ty = 0; } apply(); });
    function close() { z.hidden = true; document.body.classList.remove("w-zoom-on"); reset(); }
    z._open = (src, name) => { img.src = src; img.alt = name || ""; z.querySelector(".w-zoom-name").textContent = name || ""; z.hidden = false; document.body.classList.add("w-zoom-on"); reset(); };
    document.addEventListener("keydown", (e) => { if (!z.hidden && e.key === "Escape") close(); });
    return z;
  }
  function openZoom(src, name) { if (!src) return; zoomDom()._open(src, name); }

  /* --------------------------------------------------------------- input */
  function step(d) {
    const r = routeOf().name;
    if (r === "shop") {
      if (U.list.length < 2) return;
      const W = U.world, hall = W && W.get("hall");
      if (hall && W.room() === "hall") { hall.go(d); U.idx = hall.current().index; }
      else U.idx = (U.idx + d + U.list.length) % U.list.length;
      refreshCaption();
    }
  }
  document.addEventListener("click", (e) => {
    const el = e.target.closest("[data-ui]"); if (!el) return;
    const k = el.dataset.ui, x = X();
    if (el.tagName === "BUTTON" || k === "scrollnext") e.preventDefault();
    if (k === "prev" || k === "next") step(k === "next" ? 1 : -1);
    else if (k === "list") { U.listOpen = !U.listOpen; x.renderMain(true); }
    else if (k === "czstep") { U.czStep = Math.max(1, Math.min(6, Number(el.dataset.v))); x.renderMain(true); scrollPanelTop(); }
    else if (k === "mxstep") { U.mxStep = Math.max(1, Math.min(5, Number(el.dataset.v))); U.mixView = U.mxStep === 1 ? "top" : U.mxStep === 2 ? "bottom" : "both"; x.renderMain(true); scrollPanelTop(); }
    else if (k === "mxhop") {
      const w = el.dataset.w, lists = mixLists(), arr = w === "top" ? lists.tops : lists.bottoms, m = S().mix;
      const cur = w === "top" ? m.top : m.bottom, i = arr.findIndex((p) => p.id === cur), nx = arr[(i + Number(el.dataset.d) + arr.length) % arr.length];
      if (nx) x.ACT.mxpick({ dataset: { w, v: nx.id } });
    }
    else if (k === "mxsize") { const m = S().mix; if (el.dataset.w === "top") m.topSize = el.dataset.v; else m.bottomSize = el.dataset.v; m.err = ""; x.renderMain(true); }
    else if (k === "gprev" || k === "gnext") { const n = S().bundles.length; U.giftIdx = (U.giftIdx + (k === "gnext" ? 1 : -1) + n) % n; x.renderMain(true); }
    else if (k === "setjump") showSet(Number(el.dataset.i));
    else if (k === "zoom") { openZoom(el.dataset.src, el.dataset.name); }
    else if (k === "mixview") { U.mixView = el.dataset.v; x.renderMain(true); }
    else if (k === "mixzoom") { const v = U.mixView || "both"; const p = v === "bottom" ? P(S().mix.bottom) : P(S().mix.top); if (p && p.image) openZoom(p.image, L(p.name)); }
    else if (k === "scrollnext") { const n = $(el.getAttribute("href")); if (n) window.scrollTo({ top: n.offsetTop + 2, behavior: mqReduce.matches ? "auto" : "smooth" }); }
  });
  function scrollPanelTop() { const s = $(".w-panel .w-panel-in"); if (s) s.scrollTop = 0; }

  /* the canvas: hover, click, drag, wheel */
  function bindCanvas(cv) {
    let down = null;
    const rel = (e) => { const b = cv.getBoundingClientRect(); return [e.clientX - b.left, e.clientY - b.top, b.width, b.height]; };
    cv.addEventListener("pointermove", (e) => {
      const W = U.world; if (!W) return;
      const [x, y, w, h] = rel(e);
      if (e.pointerType === "mouse") W.setPointer((x / w) * 2 - 1, -((y / h) * 2 - 1));
      if (down) {
        const dx = e.clientX - down.x;
        if (!down.drag && Math.abs(dx) > 7 && W.room() === "hall" && routeOf().name === "shop") { down.drag = true; W.get("hall").dragStart(); cv.classList.add("grabbing"); hideCoach(); }
        if (down.drag) { const now = performance.now(), ddx = e.clientX - down.lx; down.v = ddx / Math.max(1, now - down.lt) * 1000; down.lx = e.clientX; down.lt = now; W.get("hall").dragBy(ddx); }
        return;
      }
      if (e.pointerType === "mouse") { const hit = W.hover(x, y); cv.style.cursor = hit ? "pointer" : (W.room() === "hall" && routeOf().name === "shop" ? "grab" : "default"); }
    });
    cv.addEventListener("pointerleave", () => { if (U.world && !down) { U.world.hover(null); U.world.setPointer(0, 0); } });
    cv.addEventListener("pointerdown", (e) => {
      if (!U.world) return;
      if (U.door && U.door.state === "opening") { U.world.get("hall").skip(); return; }
      down = { x: e.clientX, lx: e.clientX, lt: performance.now(), v: 0, drag: false };
      try { cv.setPointerCapture(e.pointerId); } catch (err) {}
    });
    cv.addEventListener("pointerup", (e) => {
      const W = U.world; if (!down || !W) { down = null; return; }
      const d = down; down = null; cv.classList.remove("grabbing");
      if (d.drag) { W.get("hall").dragEnd(d.v); setTimeout(() => { U.idx = W.get("hall").current().index; refreshCaption(); }, 50); return; }
      const [x, y] = rel(e), hit = W.pick(x, y); if (!hit) return;
      onPick(hit);
    });
    cv.addEventListener("pointercancel", () => { if (down && down.drag && U.world) U.world.get("hall").dragEnd(0); down = null; cv.classList.remove("grabbing"); });
    /* scrolling is never taken away from the visitor: a wheel over the room
       scrolls the reading panel (or the page), it never steps the collection */
    cv.addEventListener("wheel", (e) => {
      if (e.ctrlKey) return;
      const pan = $(".w-panel .w-panel-in") || $(".w-listpanel .w-panel-in");
      if (pan && pan.scrollHeight > pan.clientHeight + 4 && !(e.target.closest && e.target.closest(".w-panel"))) {
        pan.scrollTop += e.deltaY; e.preventDefault();
      }
    }, { passive: false });
  }
  function onPick(hit) {
    const x = X(), r = routeOf().name;
    if (hit.type === "door") { doorOpen(); return; }
    if (hit.type === "slot") { const p = U.list[hit.index]; if (p) location.hash = "p-" + p.id; return; }
    if (hit.type === "thread" && r === "customize") { x.ACT.emb({ dataset: { scope: "cz", k: "thread", v: hit.key } }); if (U.czStep !== 4) { U.czStep = 4; x.renderMain(true); } return; }
    if (hit.type === "font" && r === "customize") { x.ACT.emb({ dataset: { scope: "cz", k: "font", v: hit.key } }); if (U.czStep !== 3) { U.czStep = 3; x.renderMain(true); } return; }
    if (hit.type === "hoop" && r === "customize") { U.czStep = 2; x.renderMain(true); setTimeout(() => { const i = $("#czText"); if (i) i.focus(); }, 60); return; }
    if (hit.type === "board" && r === "customize") { U.czStep = 5; x.renderMain(true); return; }
    if ((hit.type === "top" || hit.type === "bottom") && r === "mix") {
      const lists = mixLists(), arr = hit.type === "top" ? lists.tops : lists.bottoms, p = arr[hit.index];
      if (p) { U.mxStep = hit.type === "top" ? 1 : 2; x.ACT.mxpick({ dataset: { w: hit.type, v: p.id } }); }
      return;
    }
    if (hit.type === "gift") { const b = S().bundles[hit.index]; if (b) location.hash = "b-" + b.id; return; }
    if (hit.type === "bay") { const c = ["winter", "summer", "bridal", "postpartum"][hit.index]; if (c) location.hash = "shop-" + c; }
  }
  document.addEventListener("keydown", (e) => {
    if (U.door) { if (e.key === "Escape") doorSkip(); return; }
    const tag = (document.activeElement && document.activeElement.tagName) || "";
    if (/INPUT|TEXTAREA|SELECT/.test(tag) || $(".drawer.on") || ($("#modal") && !$("#modal").hidden)) return;
    const r = routeOf().name, rtl = isRTL();
    if (r === "shop" && (e.key === "ArrowRight" || e.key === "ArrowLeft")) { e.preventDefault(); step((e.key === "ArrowRight" ? 1 : -1) * (rtl ? -1 : 1)); }
  });
  function coach() {
    if (U.coachShown || !$("#wCoach")) return; U.coachShown = true;
    const c = $("#wCoach"); c.classList.add("on"); setTimeout(() => c && c.classList.remove("on"), 5200);
  }
  function hideCoach() { const c = $("#wCoach"); if (c) c.classList.remove("on"); }

  /* hooks from app.js */
  function onCz() { if (routeOf().name === "customize") { pushAtelier(); const fl = $(".w-flatart"); if (fl) { const c = czState(); if (c) fl.innerHTML = Art().draw(c.p, { color: c.col.key, custom: c.custom }); } } }
  function onEmb(scope) { if (scope === "pdp" && routeOf().name === "p") syncProduct(routeOf().arg); }
  function onTry() {
    const m = $("#wTryMonogram"); if (m) m.textContent = (S().homeTry.text || "L.N").slice(0, 12);
    pushTry();
  }

  /* --------------------------------------------------- the door (intro) */
  function doorDom() {
    let d = $("#w3door"); if (d) return d;
    d = document.createElement("div"); d.id = "w3door"; d.className = "w3door"; d.hidden = true;
    d.setAttribute("role", "dialog"); d.setAttribute("aria-modal", "true");
    d.innerHTML = `<div class="w3d-leaves" aria-hidden="true"><span class="lf l"></span><span class="lf r"></span></div>
      <div class="w3door-brand" aria-hidden="true">${LOGO("w3door-logo", "")}</div>
      <div class="w3door-tools"><button type="button" class="w-chip" data-door="sound" aria-pressed="false"></button><button type="button" class="w-chip" data-door="skip"></button></div>
      <div class="w3door-sign"><p class="w3door-msg"></p><button type="button" class="w-btn" data-door="open"></button><p class="w3door-hint"></p></div>`;
    document.body.appendChild(d);
    d.addEventListener("click", (e) => { const b = e.target.closest("[data-door]"); if (!b) return; const k = b.dataset.door; if (k === "open") doorOpen(); else if (k === "skip") doorSkip(); else if (k === "sound") { S().soundOn = !S().soundOn; doorTexts(); } });
    return d;
  }
  function doorTexts() {
    const d = $("#w3door"); if (!d) return;
    $(".w3door-msg", d).textContent = t("intro_msg"); $("[data-door=open]", d).textContent = t("intro_open");
    $(".w3door-hint", d).textContent = coarse ? t("b3_hint_tap") : t("b3_hint_click");
    $("[data-door=skip]", d).textContent = t("intro_skip");
    const snd = $("[data-door=sound]", d); snd.textContent = S().soundOn ? t("sound_on") : t("sound_off"); snd.setAttribute("aria-pressed", String(!!S().soundOn));
    d.setAttribute("aria-label", t("b3_label"));
  }
  function introAlive() { const el = $("#intro"); return !!(el && !el.hidden && document.body.contains(el) && !el.classList.contains("open") && !el.classList.contains("gone")); }
  function markIntroSeen() { try { sessionStorage.setItem("lbn_intro", "1"); } catch (e) {} const intro = $("#intro"); if (intro) intro.remove(); }
  function showPhotoDoor() {
    U.door = { state: "door" };
    document.body.classList.add("w-door-on");
    const d = doorDom();
    d.hidden = false;
    d.classList.remove("opening");
    requestAnimationFrame(() => d.classList.add("on"));
    doorTexts();
    const intro = $("#intro"); if (intro) setTimeout(() => { intro.style.visibility = "hidden"; }, 700);
    setTimeout(() => { const o = $("[data-door=open]"); if (o && U.door && U.door.state === "door") o.focus({ preventScroll: true }); }, 500);
  }
  function showDoor() {
    const W = U.world, hall = W.get("hall");
    U.door = { state: "door" };
    document.body.classList.add("w-door-on");
    hall.showDoor(); W.go("hall", "door", {}, { instant: true }); W.setLayout("full");
    const d = doorDom(); doorTexts(); d.hidden = false;
    requestAnimationFrame(() => d.classList.add("on"));
    const intro = $("#intro"); if (intro) setTimeout(() => { intro.style.visibility = "hidden"; }, 700);
    const tick = () => {
      if (!U.door) return;
      requestAnimationFrame(tick);
      if (U.door.state === "door" && hall && hall.doorAnchor) { const a = hall.doorAnchor(), sign = $(".w3door-sign"); if (sign) { sign.style.transform = `translate(${Math.round(a.sign[0])}px, ${Math.round(a.sign[1])}px) translate(-50%, -50%)`; sign.style.width = Math.max(170, Math.round(a.w)) + "px"; } }
    };
    tick();
    setTimeout(() => { const o = $("[data-door=open]"); if (o && U.door && U.door.state === "door") o.focus({ preventScroll: true }); }, 500);
  }
  function doorOpen() {
    if (!U.door || U.door.state !== "door") return;
    U.door.state = "opening";
    markIntroSeen();
    const x = X(); if (S().soundOn && x.playDoor) x.playDoor();
    const d = $("#w3door"); if (d) d.classList.remove("on");
    const arrive = () => { if (U.door) doorDone(); };
    if (U.mode !== "3d") {
      /* the photographic leaves swing apart and the hall is already behind them */
      if (d) d.classList.add("opening");
      setTimeout(arrive, 1500);
      return;
    }
    const hall = U.world && U.world.get("hall");
    if (!hall) { setTimeout(arrive, 400); return; }
    try { hall.open(arrive); } catch (e) { hall.toRotunda(); arrive(); }
    setTimeout(arrive, 7000);
  }
  function doorSkip() {
    if (!U.door) return;
    markIntroSeen();
    const hall = U.world && U.world.get("hall");
    if (hall) { if (U.door.state === "opening") hall.skip(); else { hall.toRotunda(); doorDone(); } }
    else doorDone();
  }
  function doorDone() {
    if (!U.door) return;
    U.door = null;
    const d = $("#w3door"); if (d) { d.classList.remove("on"); setTimeout(() => { d.hidden = true; }, 600); }
    document.body.classList.remove("w-door-on");
    window.scrollTo(0, 0);
    sync(routeOf(), true);
    const m = $("#main"); if (m) { m.classList.remove("w-enter"); void m.offsetWidth; m.classList.add("w-enter"); m.focus({ preventScroll: true }); }
  }

  /* ---------------------------------------------------------------- boot */
  function mountCanvas() {
    let cv = $("#w3c");
    if (!cv) { cv = document.createElement("canvas"); cv.id = "w3c"; cv.setAttribute("aria-hidden", "true"); document.body.insertBefore(cv, document.body.firstChild); }
    let bg = $("#w3bg"); if (!bg) { bg = document.createElement("div"); bg.id = "w3bg"; bg.setAttribute("aria-hidden", "true"); document.body.insertBefore(bg, document.body.firstChild); }
    const vg = document.createElement("div"); vg.className = "w3vignette"; vg.setAttribute("aria-hidden", "true"); document.body.insertBefore(vg, cv.nextSibling);
    return cv;
  }
  function waitCatalog() {
    return new Promise((res) => { const t0 = Date.now(); (function check() { const s = window.LBN && window.LBN.S; if ((s && s.products && s.products.length) || Date.now() - t0 > 8000) res(); else setTimeout(check, 50); })(); });
  }
  async function start() {
    document.body.classList.add("w-on", U.mode === "3d" ? "w-3d" : "w-flat");
    document.body.classList.toggle("w-scroll", routeOf().name === "shop");
    const cv = mountCanvas();
    if (U.mode !== "3d") {
      setFlat(roomFor(routeOf()));
      let seen = false; try { seen = !!sessionStorage.getItem("lbn_intro"); } catch (e) {}
      if (!seen) showPhotoDoor(); else sync(routeOf(), true);
      document.body.classList.add("w-ready");
      /* the photographic store still walks: each chapter swaps its room photograph.
         Self-contained watcher so it never depends on the WebGL engine's scroll hook. */
      /* the photographic store still walks: each chapter swaps its room photograph.
         Driven by scroll + a light timer, never by the WebGL engine. */
      (function watch() {
        let lastRoom = null;
        const apply = () => {
          if ((document.body.dataset.route || "home") !== "home") return;
          const chs = $$(".w-ch"); if (!chs.length) return;
          const vh = window.innerHeight;
          let active = 0;
          chs.forEach((el, i) => { if (el.getBoundingClientRect().top <= vh * 0.5) active = i; });
          const el = chs[active]; if (!el) return;
          if (el.dataset.room !== lastRoom) { lastRoom = el.dataset.room; setFlat(el.dataset.room); }
          const b = el.getBoundingClientRect();
          const prog = Math.min(1, Math.max(0, -b.top / Math.max(1, b.height - vh)));
          const bg = $("#w3bg");
          if (bg) bg.style.transform = "scale(" + (1.05 + prog * 0.05).toFixed(3) + ") translateY(" + ((prog - 0.5) * -16).toFixed(1) + "px)";
        };
        window.addEventListener("scroll", apply, { passive: true });
        window.addEventListener("resize", () => { lastRoom = null; apply(); }, { passive: true });
        setInterval(apply, 400);
        apply();
      })();
      return;
    }
    try {
      await waitCatalog();
      const W = window.LBNW.create(cv, { lite, reduce: mqReduce.matches });
      await W.init();
      U.world = W;
      bindCanvas(cv);
      W.setReduce(mqReduce.matches);
      const doDoor = introAlive();   /* the 3D door; the DOM door is display:none, so only one is ever seen */
      if (!doDoor) await W.go("hall", "rotunda", {}, { instant: true });
      W.start();
      document.body.classList.add("w-ready");
      if (doDoor) showDoor(); else sync(routeOf(), true);
      window.addEventListener("resize", () => { W.resize(); const r = routeOf(); if (["p", "customize", "mix", "b"].includes(r.name)) W.setLayout(sideLayout()); });
      if (mqReduce.addEventListener) mqReduce.addEventListener("change", () => W.setReduce(mqReduce.matches));
      document.addEventListener("visibilitychange", () => { if (document.hidden) W.stop(); else W.start(); });
      cv.addEventListener("webglcontextlost", (e) => { e.preventDefault(); U.world = null; U.mode = "flat"; document.body.classList.remove("w-3d"); document.body.classList.add("w-flat"); setFlat(roomFor(routeOf())); });
      // build the other rooms quietly once the first one is on screen
      const idle = window.requestIdleCallback || ((f) => setTimeout(f, 400));
      ["atelier", "mix", "gifts", "gallery", "lounge"].reduce((pr, n) => pr.then(() => new Promise((res) => idle(() => W.ensure(n).then(res, res), { timeout: 3000 }))), new Promise((r) => setTimeout(r, 1800)));
      // redraw the atelier font cards once the web fonts arrive
      if (document.fonts && document.fonts.ready) document.fonts.ready.then(() => { const at = W.get("atelier"); if (at) { const labels = {}; ["script", "serif", "sans", "hand", "mono"].forEach((k) => { labels[k] = t("font_" + k); }); at.redrawFonts(labels, (S().cz.text || "Aa").slice(0, 6)); } });
    } catch (e) {
      if (window.console) console.warn("[LBN] 3D unavailable:", e && e.message);
      U.world = null; U.mode = "flat"; document.body.classList.remove("w-3d"); document.body.classList.add("w-flat");
      if (U.door) doorDone();
      X().renderMain(true);
    }
  }
  window.addEventListener("scroll", onScroll, { passive: true });
  let pY = null, pT = 0;
  document.addEventListener("scroll", (e) => {
    const el = e.target;
    if (!el || !el.classList || !el.classList.contains("w-panel-in")) return;
    const now = performance.now();
    if (pY != null) feedSpeed(Math.abs(el.scrollTop - pY), now - pT);
    pY = el.scrollTop; pT = now;
  }, true);
  window.addEventListener("resize", () => measureTop());
  window.addEventListener("hashchange", () => { if (location.hash === "#boutique") { try { history.replaceState(null, "", "#shop"); } catch (e) {} } });
  new MutationObserver(() => { doorTexts(); }).observe(document.documentElement, { attributes: true, attributeFilter: ["lang"] });

  window.LBNUI = { view, before, after, header, footer, onCz, onEmb, onTry, state: U, get world() { return U.world; } };
  if (location.hash === "#boutique") { try { history.replaceState(null, "", "#shop"); } catch (e) {} }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", start); else setTimeout(start, 0);
})();
