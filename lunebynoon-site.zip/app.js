/* LuneByNoon storefront app.
   Built to the LuneByNoon website guidelines: six-section navigation, the door intro,
   the interactive rack, customization, mix and match, collections, bundles, about us,
   help and policies, and creator collaborations, in English and Arabic.
   Data comes from the shared store on staging, and from catalog.json plus LBN_CONFIG
   when deployed on a normal host. */
(function () {
  "use strict";
  const I = window.LBN_I18N, Art = window.LBNArt, GOVS = window.LBN_GOVS, HELP = window.LBN_HELP, SIZES = window.LBN_SIZES;
  const CFG = window.LBN_CONFIG || {};
  const esc = Art.esc;
  const $ = (s, r) => (r || document).querySelector(s);
  const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));

  const blankEmb = (placement) => ({ on: false, text: "", font: "script", thread: "burgundy", placement: placement || "left", icon: "", note: "" });
  const S = {
    lang: "en", products: [], bundles: [], settings: {}, source: "none", ready: false,
    cart: [], route: { name: "home", arg: "" }, heroIdx: 0,
    homeTry: { text: "L.N", icon: "moon", font: "script" }, mixTab: "top",
    shop: { type: [], size: [], color: [], price: "", custom: false, stock: false, sort: "featured", q: "", show: false },
    pdp: { id: null, color: null, size: "", qty: 1, c: blankEmb(), view: "full", err: "" },
    cz: { pid: null, color: null, size: "", text: "", font: "script", thread: "burgundy", placement: "left", icon: "", note: "", err: "" },
    mix: null,
    bsel: {}, bErr: "",
    co: { promo: "", promoPct: 0, promoMsg: "", f: { pay: "cod" }, errs: {}, placing: false, top: "" },
    cr: null,
    db: null, user: null, uid: null, canEdit: false, assets: null, downloads: null,
    soundOn: false, pendingRender: false
  };
  const freshMix = () => ({ top: null, topColor: null, topSize: "", bottom: null, bottomColor: null, bottomSize: "", addons: {}, cTop: blankEmb("left"), cBot: blankEmb("trousers"), err: "" });
  S.mix = freshMix();
  const freshCr = () => ({ links: [""], type: "", done: false, errs: {}, upload: null, uploading: false });
  S.cr = freshCr();

  /* ---------- helpers ---------- */
  const lsGet = (k, d) => { try { const v = localStorage.getItem(k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } };
  const lsSet = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} };
  function t(key, vars) {
    let s = (I[S.lang] && I[S.lang][key]) != null ? I[S.lang][key] : (I.en[key] != null ? I.en[key] : key);
    if (vars) Object.keys(vars).forEach((k) => { s = s.split("{" + k + "}").join(vars[k]); });
    return s;
  }
  const L = (o) => (o ? (o[S.lang] || o.en || "") : "");
  function fmt(n) {
    n = Math.round(Number(n) || 0);
    return S.lang === "ar" ? n.toLocaleString("ar-EG") + " ج.م" : "EGP " + n.toLocaleString("en-US");
  }
  const num = (n) => (S.lang === "ar" ? Number(n).toLocaleString("ar-EG") : String(n));
  const P = (id) => S.products.find((p) => p.id === id);
  const B = (id) => S.bundles.find((b) => b.id === id);
  const colorOf = (p, key) => (p && p.colors ? (p.colors.find((c) => c.key === key) || p.colors[0]) : null);
  const canEmb = (p) => !!(p && p.customizable && Art.placementsFor(p).length);
  const ARROW = '<svg class="arr" width="16" height="10" viewBox="0 0 16 10" aria-hidden="true"><path d="M0 5h14M10 1l4 4-4 4" stroke="currentColor" stroke-width="1.4" fill="none"/></svg>';
  const ICON = {
    lock: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" aria-hidden="true"><rect x="5" y="10.5" width="14" height="10" rx="2"/><path d="M8 10.5V8a4 4 0 0 1 8 0v2.5"/></svg>',
    search: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/></svg>',
    bag: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" aria-hidden="true"><path d="M5 8h14l-1 12H6L5 8z"/><path d="M9 8V6a3 3 0 0 1 6 0v2"/></svg>',
    menu: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" aria-hidden="true"><path d="M4 7h16M4 12h16M4 17h10"/></svg>',
    close: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18"/></svg>',
    left: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" aria-hidden="true"><path d="M15 5l-7 7 7 7"/></svg>',
    right: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" aria-hidden="true"><path d="M9 5l7 7-7 7"/></svg>',
    gift: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4" aria-hidden="true"><rect x="3" y="9" width="18" height="11" rx="1"/><path d="M3 13h18M12 9v11M12 9c-2-4-6-4-6-1.5S12 9 12 9zm0 0c2-4 6-4 6-1.5S12 9 12 9z"/></svg>',
    truck: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4" aria-hidden="true"><path d="M2 6h12v10H2zM14 10h4l3 3v3h-7"/><circle cx="6" cy="18" r="1.8"/><circle cx="17" cy="18" r="1.8"/></svg>',
    hanger: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4" aria-hidden="true"><path d="M12 7a2 2 0 1 1 2-2c0 1.2-2 1.6-2 3v1"/><path d="M12 9L3 16.5c-.6.5-.2 1.5.6 1.5h16.8c.8 0 1.2-1 .6-1.5L12 9z"/></svg>'
  };
  const moon = (s, c) => Art.crescent(s, c);
  /* Small garment glyphs for the placement picker, as in the customization mockup. */
  const PLACE_GLYPH = {
    left: '<path d="M8 4l4 2 4-2 4 2 2 6-3 1-1-3v11H6V10l-1 3-3-1 2-6z" fill="none" stroke="currentColor"/><circle cx="15" cy="9" r="1.4" fill="currentColor"/>',
    right: '<path d="M8 4l4 2 4-2 4 2 2 6-3 1-1-3v11H6V10l-1 3-3-1 2-6z" fill="none" stroke="currentColor"/><circle cx="9" cy="9" r="1.4" fill="currentColor"/>',
    pocket: '<path d="M8 4l4 2 4-2 4 2 2 6-3 1-1-3v11H6V10l-1 3-3-1 2-6z" fill="none" stroke="currentColor"/><rect x="13.5" y="10" width="3.5" height="3.5" fill="currentColor"/>',
    sleeve: '<path d="M8 4l4 2 4-2 4 2 2 6-3 1-1-3v11H6V10l-1 3-3-1 2-6z" fill="none" stroke="currentColor"/><path d="M19 12l3-1" stroke="currentColor" stroke-width="2"/>',
    shorts: '<path d="M5 6h14l1 9-6 1-2-5-2 5-6-1z" fill="none" stroke="currentColor"/>',
    trousers: '<path d="M7 3h10l1 18h-4l-2-12-2 12H6z" fill="none" stroke="currentColor"/>'
  };
  const glyph = (k) => `<svg width="30" height="30" viewBox="0 0 24 24" aria-hidden="true" stroke-width="1.1">${PLACE_GLYPH[k] || ""}</svg>`;

  /* ---------- analytics hooks (IDs set in config.js on deployment) ---------- */
  function track(event, params) {
    try {
      window.dataLayer = window.dataLayer || [];
      window.dataLayer.push(Object.assign({ event }, params || {}));
      if (typeof window.gtag === "function") window.gtag("event", event, params || {});
      const fbMap = { view_item: "ViewContent", add_to_cart: "AddToCart", begin_checkout: "InitiateCheckout", purchase: "Purchase", sign_up: "CompleteRegistration", generate_lead: "Lead" };
      if (typeof window.fbq === "function" && fbMap[event]) window.fbq("track", fbMap[event], { value: params && params.value, currency: "EGP" });
      const ttMap = { view_item: "ViewContent", add_to_cart: "AddToCart", begin_checkout: "InitiateCheckout", purchase: "CompletePayment", sign_up: "CompleteRegistration", generate_lead: "SubmitForm" };
      if (window.ttq && ttMap[event]) window.ttq.track(ttMap[event], { value: params && params.value, currency: "EGP" });
    } catch (e) {}
  }

  /* ---------- data ---------- */
  function setCatalog(products, bundles, settings, source) {
    if (products) S.products = products.slice().sort((a, b) => (a.order || 99) - (b.order || 99));
    if (bundles) S.bundles = bundles.slice().sort((a, b) => (a.order || 99) - (b.order || 99));
    if (settings) S.settings = Object.assign({}, S.settings, settings);
    S.source = source; S.ready = true;
  }
  async function loadFile() {
    try {
      const r = await fetch(CFG.catalogUrl || "catalog.json", { cache: "no-cache" });
      const j = await r.json();
      S.fileCatalog = j;
      if (S.source !== "db") setCatalog(j.products, j.bundles, j.settings, "file");
      else S.settings = Object.assign({}, j.settings, S.settings);
    } catch (e) { S.ready = true; }
    renderChrome(); renderMain();
  }
  async function initClaude() {
    if (!window.claude || typeof window.claude.use !== "function") return;
    let db = null, user = null;
    try { [db, user] = await Promise.all([window.claude.use("db"), window.claude.use("user")]); } catch (e) {}
    S.user = user;
    if (user) {
      try { S.canEdit = !!(await user.canEdit()); } catch (e) {}
      try { S.uid = await user.id(); } catch (e) {}
    }
    try { S.assets = await window.claude.use("assets"); } catch (e) {}
    if (db) {
      S.db = db;
      db.collection("products").onSnapshot((snap) => {
        if (!snap.empty) { S.products = snap.docs.map((d) => Object.assign({}, d.data(), { id: d.id })).sort((a, b) => (a.order || 99) - (b.order || 99)); S.source = "db"; S.ready = true; }
        softRender();
      }, () => {});
      db.collection("bundles").onSnapshot((snap) => {
        if (!snap.empty) S.bundles = snap.docs.map((d) => Object.assign({}, d.data(), { id: d.id })).sort((a, b) => (a.order || 99) - (b.order || 99));
        softRender();
      }, () => {});
      db.doc("settings/store").onSnapshot((d) => { if (d.exists) { S.settings = Object.assign({}, S.settings, d.data()); renderChrome(); softRender(); } }, () => {});
    }
    if (S.canEdit) {
      try { S.downloads = await window.claude.use("downloads"); } catch (e) {}
      if (window.LBNAdmin) window.LBNAdmin.connect();
    }
    renderChrome();
    if (S.route.name === "admin" || S.route.name === "creators") renderMain(true);
  }
  function softRender() {
    const a = document.activeElement;
    if (a && $("#main").contains(a) && /INPUT|TEXTAREA|SELECT/.test(a.tagName)) { S.pendingRender = true; return; }
    if (!$("#modal").hidden) return;
    renderMain(true);
  }
  document.addEventListener("focusout", () => {
    setTimeout(() => {
      const a = document.activeElement;
      if (S.pendingRender && !(a && /INPUT|TEXTAREA|SELECT/.test(a.tagName))) { S.pendingRender = false; renderMain(true); }
    }, 60);
  });

  /* ---------- bag ---------- */
  const saveCart = () => { lsSet("lbn_cart", S.cart); updateCount(); };
  const cartQty = () => S.cart.reduce((a, l) => a + l.qty, 0);
  const cartSub = () => S.cart.reduce((a, l) => a + l.unit * l.qty, 0);
  const fee = () => Number(S.settings.embroideryFee) || 0;
  const lid = () => "l" + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
  const embOf = (c) => (c && c.on !== false && (c.text || "").trim() ? { text: c.text.trim(), font: c.font, thread: c.thread, placement: c.placement, icon: c.icon || "", note: (c.note || "").trim() } : null);

  function addLine(line) {
    const sig = JSON.stringify([line.kind, line.ref, line.parts]);
    const same = S.cart.find((l) => JSON.stringify([l.kind, l.ref, l.parts]) === sig);
    if (same) same.qty += line.qty; else S.cart.push(Object.assign({ lid: lid() }, line));
    saveCart();
    track("add_to_cart", { value: line.unit * line.qty, currency: "EGP", item_id: line.ref });
    renderCart(); openDrawer("cart");
  }
  function lineName(l) {
    if (l.kind === "set") return t("built_set");
    if (l.kind === "bundle") return L((B(l.ref) || {}).name) || l.ref;
    return L((P(l.ref) || {}).name) || l.ref;
  }
  function partText(pt) {
    const p = P(pt.pid); if (!p) return "";
    const c = colorOf(p, pt.color);
    return [L(p.name), c ? L(c.name) : "", pt.size].filter(Boolean).join(" · ");
  }
  function embText(c) {
    if (!c || !c.text) return "";
    return `${t("embroidery")}: “${esc(c.text)}” · ${t("font_" + c.font)} · ${t("th_" + c.thread)} · ${t("pl_" + c.placement)}${c.icon ? " · " + t("icon_" + c.icon) : ""}${c.note ? ` · ${t("instructions")}: ${esc(c.note)}` : ""}`;
  }
  function lineArt(l) {
    const pt = l.parts[0], p = pt && P(pt.pid);
    if (!p) return "";
    if (p.image) return `<img src="${esc(p.image)}" alt="">`;
    return Art.draw(p, { color: pt.color, custom: pt.custom });
  }

  /* ---------- chrome ---------- */
  function applyLang() {
    document.documentElement.lang = S.lang === "ar" ? "ar-EG" : "en";
    document.documentElement.dir = I[S.lang].dir;
  }
  const NAV = () => [["home", t("nav_home")], ["customize", t("nav_customize")], ["mix", t("nav_mix")], ["shop", t("nav_collections")], ["bundles", t("nav_bundles")], ["story", t("nav_story")]];
  function navOn(k) {
    const r = S.route.name;
    if (k === "shop") return r === "shop" || r === "p";
    if (k === "bundles") return r === "bundles" || r === "b";
    return r === k;
  }
  function renderChrome() {
    const st = S.settings;
    $("#topbars").innerHTML =
      (st.staging !== false ? `<div class="staging"><div class="wrap">${esc(t("staging"))}</div></div>` : "") +
      (L(st.announcement) ? `<div class="announce"><div class="wrap">${esc(L(st.announcement))}</div></div>` : "");
    if (window.LBNUI) { $("#hdr").innerHTML = window.LBNUI.header(); $("#ftr").innerHTML = window.LBNUI.footer(); }
    else {
    const nav = NAV();
    const link = ([k, v]) => `<a href="#${k}" class="${navOn(k) ? "on" : ""}" ${navOn(k) ? 'aria-current="page"' : ""}>${esc(v)}</a>`;
    $("#hdr").innerHTML = `<div class="wrap">
      <div class="hdr-l"><button class="iconbtn menu-btn" data-act="menu" aria-label="${esc(t("menu"))}">${ICON.menu}</button>
        <nav class="nav desk" aria-label="Main">${nav.slice(0, 3).map(link).join("")}</nav></div>
      <a class="logo" href="#home" aria-label="LuneByNoon"><img src="assets/logo-burgundy.svg" alt="LuneByNoon" width="640" height="147"></a>
      <div class="tools"><nav class="nav desk" aria-label="Main, continued">${nav.slice(3).map(link).join("")}</nav>
        <button class="langbtn" data-act="lang">${esc(t("otherLang"))}</button>
        <button class="iconbtn" data-act="search" aria-label="${esc(t("search"))}">${ICON.search}</button>
        <button class="iconbtn" data-act="cart" aria-label="${esc(t("bag"))}">${ICON.bag}<span class="count" id="count" ${cartQty() ? "" : "hidden"}>${num(cartQty())}</span></button>
      </div></div>`;
    renderFooter(); }
    renderMenu(); renderCart();
    const set = (id, v) => { const e = $(id); if (e) e.textContent = v; };
    set("#introMsg", t("intro_msg")); set("#introOpen", t("intro_open")); set("#introSkip", t("intro_skip"));
    set("#introSound", S.soundOn ? t("sound_on") : t("sound_off"));
  }
  function updateCount() { const c = $("#count"); if (c) { c.textContent = num(cartQty()); c.hidden = !cartQty(); } }
  function renderMenu() {
    const items = NAV().concat([["help-faq", t("help_title")], ["creators", t("h_creators")]]);
    if (S.canEdit) items.push(["admin", t("admin")]);
    $("#menu").innerHTML = `<header><h2>${esc(t("menu"))}</h2><button class="iconbtn" data-act="close" aria-label="${esc(t("close"))}">${ICON.close}</button></header>
      <div class="body"><nav class="drawer-nav">${items.map(([k, v]) => `<a href="#${k}" data-act="close-nav">${esc(v)}</a>`).join("")}</nav>
      <button class="langbtn" data-act="lang" style="justify-self:start">${esc(t("otherLang"))}</button></div><footer><span class="note">${esc(t("tagline"))}</span></footer>`;
  }
  function renderFooter() {
    const st = S.settings;
    const ext = (u, label) => `<a href="${esc(u || "#")}" target="_blank" rel="noopener">${esc(label)}</a>`;
    $("#ftr").innerHTML = `
      <div class="news"><div class="wrap">
        <div class="news-copy">${moon(34, "#fad6e1")}<div><h3>${esc(t("news_title"))}</h3><p>${esc(t("news_sub"))}</p></div></div>
        <form class="newsform" id="newsform" novalidate>
          <label class="sr" for="newsEmail">${esc(t("news_ph"))}</label>
          <input type="email" id="newsEmail" placeholder="${esc(t("news_ph"))}" autocomplete="email">
          <button class="btn light" type="submit">${esc(t("news_btn"))} ${ARROW}</button>
          <p class="note" id="newsMsg" aria-live="polite"></p>
        </form>
      </div></div>
      <div class="wrap">
        <div class="cols">
          <div class="brand"><img src="assets/logo-cream.svg" alt="LuneByNoon" width="640" height="147"><p class="script-line">${esc(t("tagline"))}</p><p>${esc(t("est"))}</p></div>
          <div><h4>${esc(t("f_shop"))}</h4><ul>${NAV().map(([k, v]) => `<li><a href="#${k}">${esc(v)}</a></li>`).join("")}</ul></div>
          <div><h4>${esc(t("help_title"))}</h4><ul>${["shipping", "returns", "custom", "payment", "terms", "size", "care", "faq"].map((k) => `<li><a href="#help-${k}">${esc(t("h_" + k))}</a></li>`).join("")}</ul></div>
          <div><h4>${esc(t("f_support"))}</h4><ul>
            <li><a href="#help-contact">${esc(t("h_contact"))}</a></li>
            <li><a href="#creators">${esc(t("h_creators"))}</a></li>
            ${S.canEdit ? `<li><a href="#admin">${esc(t("admin"))}</a></li>` : ""}</ul>
            <h4 style="margin-top:1.4rem">${esc(t("f_follow"))}</h4><ul>
            <li>${ext(st.instagram, "Instagram")}</li><li>${ext(st.tiktok, "TikTok")}</li><li>${ext(st.pinterest, "Pinterest")}</li></ul></div>
        </div>
        <div class="base"><span>© 2026 LuneByNoon. ${esc(t("rights"))}</span><span style="display:flex;gap:1rem"><a href="#help-terms">${esc(t("h_terms"))}</a><button class="link" style="color:#f2dfe5" data-act="lang">${esc(t("otherLang"))}</button></span></div>
      </div>`;
  }

  /* ---------- drawers, modal, toast ---------- */
  function openDrawer(id) {
    closeAll(true);
    const d = $("#" + id); d.classList.add("on"); d.setAttribute("aria-hidden", "false");
    $("#scrim").classList.add("on");
    const f = d.querySelector("button, a, input"); if (f) setTimeout(() => f.focus(), 50);
  }
  function closeAll(keepModal) {
    $$(".drawer").forEach((d) => { d.classList.remove("on"); d.setAttribute("aria-hidden", "true"); });
    if (!keepModal) closeModal();
    if ($("#modal").hidden) $("#scrim").classList.remove("on");
  }
  function openModal(title, html, wide) {
    const m = $("#modal");
    m.innerHTML = `<div class="box" role="dialog" aria-modal="true" aria-label="${esc(title)}" style="${wide ? "width:min(980px,100%)" : ""}"><header><h2 style="font-size:1.5rem">${esc(title)}</h2><button class="iconbtn" data-act="close" aria-label="${esc(t("close"))}">${ICON.close}</button></header><div class="in">${html}</div></div>`;
    m.hidden = false; $("#scrim").classList.add("on");
    const f = m.querySelector("input, select, textarea, button"); if (f) setTimeout(() => f.focus(), 40);
  }
  function closeModal() { const m = $("#modal"); m.hidden = true; m.innerHTML = ""; if (!$(".drawer.on")) $("#scrim").classList.remove("on"); }
  let toastT;
  function toast(msg) {
    const el = $("#toast"); el.innerHTML = moon(16, "#fad6e1") + "<span>" + esc(msg) + "</span>"; el.classList.add("on");
    clearTimeout(toastT); toastT = setTimeout(() => el.classList.remove("on"), 2600);
  }
  async function copyText(text, btn) {
    try { await navigator.clipboard.writeText(text); if (btn) { const o = btn.textContent; btn.textContent = t("copied"); setTimeout(() => (btn.textContent = o), 1400); } }
    catch (e) { toast(text); }
  }

  /* ---------- bag drawer ---------- */
  function renderCart() {
    const el = $("#cart"); if (!el) return;
    const head = `<header><h2>${esc(t("cart_title"))}</h2><button class="iconbtn" data-act="close" aria-label="${esc(t("close"))}">${ICON.close}</button></header>`;
    if (!S.cart.length) {
      el.innerHTML = head + `<div class="body"><div class="empty">${moon(40, "#6e2135")}<p>${esc(t("cart_empty"))}</p><a class="btn" href="#shop" data-act="close-nav">${esc(t("cart_empty_cta"))}</a></div></div><footer></footer>`;
      return;
    }
    const sub = cartSub(), thr = Number(S.settings.freeDeliveryOver) || 0;
    const pct = thr ? Math.min(100, (sub / thr) * 100) : 100;
    el.innerHTML = head + `<div class="body">
        <div class="freebar"><span>${sub >= thr ? esc(t("cart_free_yes")) : esc(t("cart_free_left", { p: fmt(thr - sub) }))}</span><div class="bar"><i style="width:${pct}%"></i></div></div>
        ${S.cart.map((l) => `<div class="line"><div class="th">${lineArt(l)}</div>
          <div><div class="nm">${esc(lineName(l))}</div>
            ${l.parts.map((pt) => `<div class="sub">${esc(partText(pt))}</div>${pt.custom && pt.custom.text ? `<div class="emb">${embText(pt.custom)}</div>` : ""}`).join("")}
            <div class="act"><div class="qty"><button data-act="q" data-l="${l.lid}" data-d="-1" aria-label="-">−</button><span>${num(l.qty)}</span><button data-act="q" data-l="${l.lid}" data-d="1" aria-label="+">+</button></div>
            <button class="link" data-act="rm" data-l="${l.lid}" style="font-size:.78rem">${esc(t("cart_remove"))}</button></div></div>
          <div class="price">${fmt(l.unit * l.qty)}</div></div>`).join("")}
      </div>
      <footer><div class="tot"><span>${esc(t("cart_sub"))}</span><span>${fmt(sub)}</span></div><p class="note">${esc(t("cart_note"))}</p>
      <a class="btn block" href="#checkout" data-act="close-nav">${esc(t("cart_checkout"))} ${ARROW}</a></footer>`;
  }

  /* ---------- router ---------- */
  function parse() {
    const h = decodeURIComponent((location.hash || "").replace(/^#/, ""));
    if (!h || h === "home") return { name: "home", arg: "" };
    const i = h.indexOf("-");
    const head = i < 0 ? h : h.slice(0, i), arg = i < 0 ? "" : h.slice(i + 1);
    const known = ["shop", "p", "customize", "mix", "bundles", "b", "story", "help", "creators", "checkout", "pay", "order", "admin"];
    return known.includes(head) ? { name: head, arg } : { name: "home", arg: "" };
  }
  function route() {
    const prev = S.route;
    S.route = parse();
    closeAll();
    if (S.route.name === "p" && S.route.arg !== S.pdp.id) resetPdp(S.route.arg);
    if (S.route.name === "customize" && S.route.arg) { S.cz.pid = S.route.arg; S.cz.color = null; }
    renderChrome(); renderMain();
    if (prev.name !== S.route.name || prev.arg !== S.route.arg) window.scrollTo(0, 0);
  }
  function resetPdp(id) {
    const p = P(id);
    S.pdp = { id, color: p && p.colors[0] ? p.colors[0].key : null, size: p && p.sizes.length === 1 ? p.sizes[0] : "", qty: 1, c: blankEmb(p ? Art.placementsFor(p)[0] : "left"), view: "full", err: "" };
  }
  function go(h) { if (location.hash === "#" + h) route(); else location.hash = h; }
  function setMeta(title, desc) {
    document.title = title ? title + " | LuneByNoon" : "LuneByNoon";
    const m = document.querySelector('meta[name="description"]');
    if (m && desc) m.setAttribute("content", desc);
    const ld = $("#ld-product"); if (ld) ld.remove();
  }
  function productLd(p) {
    const s = document.createElement("script");
    s.type = "application/ld+json"; s.id = "ld-product";
    s.textContent = JSON.stringify({ "@context": "https://schema.org", "@type": "Product", name: p.name.en, description: p.desc.en, brand: { "@type": "Brand", name: "LuneByNoon" }, sku: p.id,
      offers: { "@type": "Offer", priceCurrency: "EGP", price: p.price, availability: p.inStock === false ? "https://schema.org/OutOfStock" : "https://schema.org/InStock", url: (CFG.baseUrl || "") + "/#p-" + p.id } });
    document.body.appendChild(s);
  }

  function renderMain(soft) {
    const r = S.route, m = $("#main"), UI = window.LBNUI;
    let html = "", wv = null;
    if (UI) UI.before();
    if (!S.ready) html = `<div class="wrap" style="padding-block:4rem"><div class="grid">${"<div class='skel'></div>".repeat(4)}</div><p class="note" style="text-align:center;margin-top:1rem">${esc(t("loading"))}</p></div>`;
    else if (UI && (wv = UI.view(r)) != null) html = wv;
    else {
      switch (r.name) {
        case "home": html = vHome(); setMeta("", t("custom_sub")); break;
        case "shop": html = r.arg ? vCollection(r.arg) : vCollections(); break;
        case "p": html = vProduct(r.arg); break;
        case "customize": html = vCustomize(); setMeta(t("c_title"), t("c_sub")); break;
        case "mix": html = vMix(); setMeta(t("m_title"), t("m_sub")); break;
        case "bundles": html = vBundles(); setMeta(t("b_eyebrow"), t("b_sub")); break;
        case "b": html = vBundle(r.arg); break;
        case "story": html = vStory(); setMeta(t("st_title"), t("st_open")); break;
        case "help": html = vHelp(r.arg || "faq"); break;
        case "creators": html = vCreators(); setMeta(t("h_creators"), t("cr_sub")); break;
        case "checkout": html = vCheckout(); setMeta(t("co_title")); break;
        case "pay": html = vPay(r.arg); setMeta(t("pay_title")); break;
        case "order": html = vOrder(r.arg); setMeta(t("co_title")); break;
        case "admin": html = window.LBNAdmin ? window.LBNAdmin.view() : ""; setMeta(t("admin")); break;
        default: html = vHome();
      }
    }
    const y = window.scrollY;
    m.innerHTML = html;
    if (soft) window.scrollTo(0, y);
    if (r.name === "home" && wv == null) bindHero();
    if (r.name === "pay") mountPixel(r.arg);
    if (UI && S.ready) UI.after(r, soft);
  }

  /* ---------- product card ---------- */
  function sizeRange(p) { return p.sizes.length > 2 ? p.sizes[0] + "–" + p.sizes[p.sizes.length - 1] : p.sizes.join(", "); }
  function card(p) {
    const tags = [];
    if (p.isNew) tags.push(`<span class="tag">${esc(t("badge_new"))}</span>`);
    if (canEmb(p)) tags.push(`<span class="tag soft">${moon(10, "#6e2135")} ${esc(t("badge_custom"))}</span>`);
    if (p.inStock === false) tags.push(`<span class="tag out">${esc(t("sold_out"))}</span>`);
    return `<article class="card">
      <a class="media" href="#p-${esc(p.id)}" aria-label="${esc(L(p.name))}">${p.image ? `<img src="${esc(p.image)}" alt="${esc(L(p.name))}" loading="lazy">` : Art.draw(p)}<span class="tags">${tags.join("")}</span></a>
      <a class="nm" href="#p-${esc(p.id)}">${esc(L(p.name))}</a>
      <div class="meta"><span class="price">${fmt(p.price)}${p.compareAt ? `<s>${fmt(p.compareAt)}</s>` : ""}</span><span class="mini-sws">${(p.colors || []).slice(0, 4).map((c) => `<i style="background:${esc(c.base)}" title="${esc(L(c.name))}"></i>`).join("")}</span></div>
      <div class="meta small"><span>${esc(t("sizes_word"))}: ${esc(sizeRange(p))}</span>${canEmb(p) ? `<a class="cust-link" href="#customize-${esc(p.id)}">${esc(t("customize_link"))}</a>` : ""}</div>
    </article>`;
  }

  /* ---------- HOME (follows the Website Look & Feel layout) ---------- */
  function heroItems() {
    let list = S.products.filter((p) => p.type === "set" && p.featured && p.inStock !== false);
    if (!list.length) list = S.products.filter((p) => p.type === "set");
    return list;
  }
  function heroHang(p) { return p.image ? `<img src="${esc(p.image)}" alt="${esc(L(p.name))}" class="hang-photo">` : Art.draw(p, { rack: true }); }
  function vHome() {
    const st = S.settings, items = heroItems(), n = items.length;
    const idx = n ? ((S.heroIdx % n) + n) % n : 0;
    const hp = items[idx];
    const beds = [
      ["customize", "custom", { duvet: "#f4cdd8", pillow: "#fbeef2", word: "H" }],
      ["mix", "mix", { duvet: "#e6e3f0", duvetPrint: "gingham", duvetAcc: "#8f8fb8", pillow: "#f3f1f8", accent: "#6e2135" }],
      ["shop", "shop", { duvet: "#6e2135", pillow: "#7e2a40", head: "#f3e3e0", accent: "#f4cdd8", wall: "#ecd2d7" }],
      ["shop-postpartum", "post", { duvet: "#f6d6df", pillow: "#fbf3f5", moonPillow: true }],
      ["shop-bridal", "bridal", { duvet: "#fbf6ee", pillow: "#fffaf3", canopy: true, word: "Bride", accent: "#b88a5a" }],
      ["bundles", "bundles", { duvet: "#f8dde5", pillow: "#fbf3f5", gift: true }]
    ];
    const czP = P("classic-top") || S.products.find((p) => p.shape === "top");
    const tryC = { text: S.homeTry.text, font: "serif", thread: "burgundy", placement: "pocket", icon: S.homeTry.icon };
    const tabs = { top: S.products.filter((p) => p.type === "top"), bottom: S.products.filter((p) => p.type === "bottom"), robe: S.products.filter((p) => p.type === "robe") };
    const story = P("crescent-set"), winter = P("burgundy-winter-set");
    const comfort = [["winter", "cmp_winter", "burgundy-winter-set"], ["summer", "cmp_summer", "crescent-set"], ["postpartum", "cmp_post", "mama-set"]];
    return `
    <section class="salon" aria-label="LuneByNoon"><div class="wrap">
      <div class="salon-copy">
        <h1>${esc(L(st.heroTitle))}</h1>
        <p class="eyebrow">${esc(L(st.heroSub))}</p>
        <div>${hp ? `<a class="btn" id="heroCta" href="#p-${esc(hp.id)}">${esc(t("hero_cta"))} ${ARROW}</a>` : ""}<a class="btn ghost b3-enter" href="#boutique">${moon(14, "#6e2135")} ${esc(t("b3_enter"))}</a></div>
      </div>
      <div class="alcove-wrap">
        <div class="alcove" id="alcove">
          <div class="alcove-inner"><img class="alcove-logo" src="assets/logo-burgundy.svg" alt="" width="640" height="147"></div>
          <div class="door-open l"></div><div class="door-open r"></div><div class="alcove-frame"></div>
          ${Art.rack()}
          ${hp ? `<a class="hang" id="hang" href="#p-${esc(hp.id)}" aria-label="${esc(L(hp.name))}" draggable="false">${heroHang(hp)}</a>` : ""}
          ${n > 1 ? `<button class="carousel-arrow prev" data-act="hero" data-d="-1" aria-label="${esc(t("prev_design"))}">${ICON.left}</button><button class="carousel-arrow next" data-act="hero" data-d="1" aria-label="${esc(t("next_design"))}">${ICON.right}</button>` : ""}
        </div>
        ${hp ? `<div class="hang-caption" aria-live="polite"><span class="ct" id="hangCount">${esc(heroCount(idx, n))}</span><span class="nm" id="hangName">${esc(L(hp.name))}</span><span class="pr" id="hangPrice">${fmt(hp.price)}</span></div>` : ""}
      </div>
      <div class="salon-side"><img src="assets/logo-burgundy.svg" alt="" width="640" height="147"><span class="script">${esc(t("hero_side"))}</span></div>
    </div>
    </section>
    ${n > 1 ? `<section class="set-shelf" aria-label="${esc(t("shelf_label"))}"><div class="wrap"><div class="hero-thumbs">${items.map((p, i) => `<button class="${i === idx ? "on" : ""}" data-act="heroto" data-i="${i}" aria-pressed="${i === idx}"><span class="ph">${p.image ? `<img src="${esc(p.image)}" alt="" loading="lazy">` : Art.draw(p)}</span><span class="nm">${esc(shortName(p))}</span><span class="pr">${fmt(p.price)}</span></button>`).join("")}</div></div></section>` : ""}

    <section class="beds wrap" aria-label="${esc(t("nav_home"))}">
      ${beds.map(([href, k, o]) => `<a class="bed-arch" href="#${href}"><span class="bed-ph">${Art.bed(o)}</span><span class="bed-tx"><b>${esc(t("bed_" + k))}</b><span>${esc(t("bed_" + k + "_s"))}</span><i>${ARROW}</i></span></a>`).join("")}
    </section>

    <section class="bride-banner"><div class="bride-vis">${Art.bed({ duvet: "#fbf6ee", pillow: "#fffaf3", word: "Bride", accent: "#b88a5a", gift: true, wall: "#f8eadf" })}</div>
      <div class="bride-copy">${moon(22, "#b88a5a")}<span class="eyebrow">${esc(t("bride_eyebrow"))}</span><h2>${esc(t("bride_title"))}</h2><p class="lede">${esc(t("bride_sub"))}</p><a class="btn ghost" href="#shop-bridal">${esc(t("bride_cta"))} ${ARROW}</a></div>
    </section>

    <section class="sec wrap" aria-labelledby="cmpH">
      <div class="sec-head"><h2 id="cmpH">${esc(t("comfort_title"))}</h2></div>
      <div class="comfort">${comfort.map(([c, k, pid]) => { const p = P(pid); return `<a class="comfort-card" href="#shop-${c}"><span class="ph">${p ? Art.draw(p) : ""}</span><span class="tx"><b>${esc(t(k))}</b><span>${esc(t(k + "_s"))}</span><span class="btn small ${c === "winter" ? "" : "ghost"}">${esc(t("explore"))} ${ARROW}</span></span></a>`; }).join("")}</div>
    </section>

    <section class="cz-band" aria-labelledby="czH"><div class="wrap">
      <div class="cz-visual">
        <div class="big" id="tryBig">${czP ? Art.draw(czP, { color: "pink", custom: tryC, zoom: true }) : ""}</div>
        <div class="swatch-col">
          ${[{ text: "L.N", icon: "moon", font: "script" }, { text: "Noon", icon: "", font: "script" }, { text: "هيا", icon: "heart", font: "hand" }].map((c) => `<div class="swatch">${czP ? Art.draw(czP, { color: "pink", custom: Object.assign({ thread: "burgundy", placement: "pocket" }, c), zoom: true }) : ""}</div>`).join("")}
        </div>
      </div>
      <div class="cz-copy">
        <span class="eyebrow">${esc(t("truly_eyebrow"))}</span>
        <h2 id="czH">${esc(t("custom_title"))}</h2>
        <p class="lede">${esc(t("custom_sub"))}</p>
        <div class="try">
          <label class="f" for="tryIn">${esc(t("choose_initials"))}<input type="text" id="tryIn" maxlength="12" value="${esc(S.homeTry.text)}" data-in="try"></label>
          <div class="icon-pick" role="group" aria-label="${esc(t("c_icon_h"))}">${["moon", "heart", "star", "bow", "flower"].map((k) => `<button class="${S.homeTry.icon === k ? "on" : ""}" data-act="tryicon" data-v="${k}" aria-pressed="${S.homeTry.icon === k}" aria-label="${esc(t("icon_" + k))}">${Art.icon(k, 20, "#6e2135")}</button>`).join("")}</div>
          <p class="note">${esc(t("preview_note"))}</p>
        </div>
        <a class="btn" href="#customize" style="justify-self:start">${esc(t("custom_cta"))} ${ARROW}</a>
      </div>
    </div></section>

    <section class="sec mix-band" aria-labelledby="mixH"><div class="wrap">
      <div class="mix-copy"><span class="eyebrow">${esc(t("mix_eyebrow"))}</span><h2 id="mixH">${esc(t("mix_title"))}</h2><p class="lede">${esc(t("mix_sub"))}</p><a class="btn" href="#mix">${esc(t("mix_cta"))} ${ARROW}</a></div>
      <div class="mix-tabs">
        <div class="tabbar" role="tablist">${[["top", "tab_tops"], ["bottom", "tab_bottoms"], ["robe", "tab_robes"]].map(([k, l]) => `<button role="tab" class="${S.mixTab === k ? "on" : ""}" aria-selected="${S.mixTab === k}" data-act="mixtab" data-v="${k}">${esc(t(l))}</button>`).join("")}</div>
        <div class="mix-pieces">${(tabs[S.mixTab] || []).slice(0, 4).map((p) => `<a class="pc" href="#mix" aria-label="${esc(L(p.name))}">${Art.draw(p)}<span>${esc(L(p.name))}</span></a>`).join("")}</div>
      </div>
    </div></section>

    <section class="sec wrap" style="padding-top:0"><div class="bundle-band">
      <div class="pad"><h2>${esc(t("bundles_title"))}</h2><p class="lede">${esc(t("bundles_sub"))}</p><a class="btn" href="#bundles">${esc(t("bundles_cta"))} ${ARROW}</a></div>
      <div class="giftbox"><div class="box"><span class="bow">${ICON.gift}</span></div></div>
      <div class="note-card"><span class="script">${esc(t("bundles_card"))}</span>${moon(16, "#6e2135")}</div>
    </div></section>

    <section class="wrap story-band">
      <img src="assets/brand-bedroom.jpg" alt="" loading="lazy">
      <div class="pad"><h2>${esc(t("story_title"))}</h2><p class="lede">${esc(t("story_sub"))}</p><a class="btn" href="#story">${esc(t("story_cta"))} ${ARROW}</a></div>
      <div class="values">${valueIcons()}</div>
    </section>

    <section class="community"><div class="wrap">
      <div class="comm-copy"><h2>${esc(t("community_title"))}</h2><p>${esc(t("community_sub"))}</p><a class="iconbtn round" href="${esc(S.settings.instagram || "#")}" target="_blank" rel="noopener" aria-label="Instagram">${ICON.right}</a></div>
      <div class="ugc">
        <div class="u"><img src="assets/brand-bedroom.jpg" alt="" loading="lazy"></div>
        <div class="u">${story ? Art.draw(story) : ""}</div>
        <div class="u"><img src="assets/brand-crescents.jpg" alt="" loading="lazy"></div>
        <div class="u dark">${winter ? Art.draw(winter) : ""}</div>
        <div class="u">${P("summer-short-set") ? Art.draw(P("summer-short-set")) : ""}</div>
      </div>
    </div></section>`;
  }
  function valueIcons() {
    const v = [["v_comfort", moon(22, "#6e2135")], ["v_details", Art.icon("heart", 22, "#6e2135")], ["v_timeless", Art.icon("flower", 22, "#6e2135")], ["v_women", ICON.hanger]];
    return v.map(([k, ic]) => `<div class="value"><span class="ic">${ic}</span><span>${esc(t(k))}</span></div>`).join("");
  }
  function bindHero() {
    const al = $("#alcove"); if (!al) return;
    let x0 = null, dragged = false;
    const start = (x) => { x0 = x; dragged = false; };
    const end = (x) => {
      if (x0 == null) return; const dx = x - x0; x0 = null;
      if (Math.abs(dx) > 40) { dragged = true; heroStep((dx < 0 ? 1 : -1) * (S.lang === "ar" ? -1 : 1)); }
    };
    al.addEventListener("touchstart", (e) => start(e.touches[0].clientX), { passive: true });
    al.addEventListener("touchend", (e) => end(e.changedTouches[0].clientX));
    al.addEventListener("mousedown", (e) => { if (e.button === 0 && !e.target.closest("button")) { start(e.clientX); e.preventDefault(); } });
    al.addEventListener("mouseup", (e) => end(e.clientX));
    al.addEventListener("click", (e) => { if (dragged) { e.preventDefault(); dragged = false; } }, true);
  }
  function heroCount(i, n) {
    const p2 = (v) => S.lang === "ar" ? Number(v).toLocaleString("ar-EG", { minimumIntegerDigits: 2 }) : String(v).padStart(2, "0");
    return p2(i + 1) + " / " + p2(n);
  }
  function shortName(p) { const s = L(p.name); return S.lang === "ar" ? s : s.replace(/^The\s+/, ""); }
  function heroStep(d, to) {
    const items = heroItems(), n = items.length; if (n < 2) return;
    const next = to != null ? to : (((S.heroIdx + d) % n) + n) % n;
    const dir = to != null ? (to > S.heroIdx ? 1 : -1) : d;
    if (next === S.heroIdx) return;
    S.heroIdx = next;
    const p = items[next], h = $("#hang"); if (!h) return;
    const reduce = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    h.classList.add(dir > 0 ? "out-l" : "out-r");
    setTimeout(() => {
      h.innerHTML = heroHang(p); h.href = "#p-" + p.id; h.setAttribute("aria-label", L(p.name));
      $("#hangName").textContent = L(p.name);
      const ct = $("#hangCount"); if (ct) ct.textContent = heroCount(next, n);
      $("#hangPrice").textContent = fmt(p.price);
      const cta = $("#heroCta"); if (cta) cta.href = "#p-" + p.id;
      $$(".hero-thumbs button").forEach((b) => { const on = Number(b.dataset.i) === next; b.classList.toggle("on", on); b.setAttribute("aria-pressed", String(on)); if (on && b.scrollIntoView && b.parentNode.scrollWidth > b.parentNode.clientWidth) b.parentNode.scrollTo({ left: b.offsetLeft - (b.parentNode.clientWidth - b.offsetWidth) / 2, behavior: "smooth" }); });
      h.style.transition = "none";
      h.classList.remove("out-l", "out-r"); h.classList.add(dir > 0 ? "out-r" : "out-l");
      void h.offsetWidth; h.style.transition = ""; h.classList.remove("out-l", "out-r");
    }, reduce ? 0 : 260);
  }

  /* ---------- SHOP COLLECTIONS ---------- */
  const COLS = ["original", "winter", "summer", "bridal", "postpartum"];
  const inCol = (c) => S.products.filter((p) => (p.collections || []).includes(c));
  function vCollections() {
    setMeta(t("nav_collections"), t("seasons_title"));
    const tiles = (c) => inCol(c).filter((p) => p.type === "set").slice(0, 3).map((p) => `<div class="tile">${p.image ? `<img src="${esc(p.image)}" alt="">` : Art.draw(p)}</div>`).join("");
    return `<div class="wrap"><div class="page-head"><div class="crumbs"><a href="#home">${esc(t("nav_home"))}</a><span>/</span><span>${esc(t("nav_collections"))}</span></div></div></div>
      <section class="seasons-hero"><div class="wrap">${moon(26, "#6e2135")}<h1>${esc(t("seasons_title"))}</h1></div></section>
      <section class="season winter"><div class="wrap">
        <div class="copy"><span class="eyebrow">${esc(t("col_winter"))}</span><h2>${esc(t("winter_title"))}</h2><p class="lede">${esc(t("winter_sub"))}</p><a class="btn light" href="#shop-winter">${esc(t("winter_cta"))} ${ARROW}</a></div>
        <div class="pile">${tiles("winter")}</div></div></section>
      <section class="season summer"><div class="wrap">
        <div class="copy"><span class="eyebrow">${esc(t("col_summer"))}</span><h2>${esc(t("summer_title"))}</h2><p class="lede">${esc(t("summer_sub"))}</p><a class="btn" href="#shop-summer">${esc(t("summer_cta"))} ${ARROW}</a></div>
        <div class="pile">${tiles("summer")}</div></div></section>
      <section class="sec wrap"><div class="sec-head"><h2>${esc(t("more_cols"))}</h2></div>
        <div class="comfort">${["original", "bridal", "postpartum"].map((c) => { const p = inCol(c).find((x) => x.type === "set") || inCol(c)[0]; return `<a class="comfort-card" href="#shop-${c}"><span class="ph">${p ? Art.draw(p) : ""}</span><span class="tx"><b>${esc(t("col_" + c))}</b><span>${esc(t("colh_" + c))}</span><span class="btn small ghost">${esc(t("explore"))} ${ARROW}</span></span></a>`; }).join("")}</div>
        <p style="text-align:center;margin-top:1.5rem"><a class="btn ghost" href="#shop-all">${esc(t("col_all"))} ${ARROW}</a></p>
      </section>`;
  }
  function vCollection(col) {
    const all = col === "all";
    if (!all && !COLS.includes(col)) return vCollections();
    const f = S.shop;
    let list = all ? S.products.slice() : inCol(col);
    if (f.q) {
      const q = f.q.toLowerCase();
      list = list.filter((p) => searchText(p).includes(q));
    }
    const base = list;
    if (f.type.length) list = list.filter((p) => f.type.includes(p.type));
    if (f.size.length) list = list.filter((p) => p.sizes.some((s) => f.size.includes(s)));
    if (f.color.length) list = list.filter((p) => p.colors.some((c) => f.color.includes(c.key)));
    if (f.price === "a") list = list.filter((p) => p.price < 1000);
    if (f.price === "b") list = list.filter((p) => p.price >= 1000 && p.price <= 2000);
    if (f.price === "c") list = list.filter((p) => p.price > 2000);
    if (f.custom) list = list.filter(canEmb);
    if (f.stock) list = list.filter((p) => p.inStock !== false);
    if (f.sort === "new") list = list.slice().sort((a, b) => String(b.created).localeCompare(String(a.created)));
    else if (f.sort === "low") list = list.slice().sort((a, b) => a.price - b.price);
    else if (f.sort === "high") list = list.slice().sort((a, b) => b.price - a.price);
    else list = list.slice().sort((a, b) => (b.featured ? 1 : 0) - (a.featured ? 1 : 0) || (a.order || 99) - (b.order || 99));
    const colors = {}; base.forEach((p) => p.colors.forEach((c) => { if (!colors[c.key]) colors[c.key] = c; }));
    const name = all ? t("col_all") : t("col_" + col);
    const h1 = all ? t("col_all") : t("colh_" + col);
    const desc = all ? t("cold_all") : t("cold_" + col);
    setMeta(name, desc);
    const chip = (g, v, label) => `<button class="chip ${f[g].includes(v) ? "on" : ""}" data-act="f" data-g="${g}" data-v="${esc(v)}" aria-pressed="${f[g].includes(v)}">${esc(label)}</button>`;
    const vis = base.filter((p) => p.type === "set").slice(0, 3);
    return `<div class="wrap">
      <div class="page-head" style="padding-bottom:.6rem"><div class="crumbs"><a href="#home">${esc(t("nav_home"))}</a><span>/</span><a href="#shop">${esc(t("nav_collections"))}</a><span>/</span><span>${esc(name)}</span></div></div>
      <div class="col-banner ${col}"><div class="pad"><span class="eyebrow">${esc(name)}</span><h1>${esc(h1)}</h1><p class="lede">${esc(desc)}</p><a class="btn ${col === "winter" ? "light" : ""}" href="#shop-${col}" data-act="togrid">${esc(t("shop_collection"))} ${ARROW}</a></div>
        <div class="vis">${vis.map((p) => `<div>${p.image ? `<img src="${esc(p.image)}" alt="">` : Art.draw(p)}</div>`).join("")}</div></div>
      <div class="shop" id="grid">
        <aside class="filters ${f.show ? "show" : ""}" aria-label="${esc(t("filters"))}">
          <h2 class="fh">${esc(t("filters"))}</h2>
          <div><h3>${esc(t("f_type"))}</h3><div class="chips">${["set", "top", "bottom", "robe", "accessory"].filter((x) => base.some((p) => p.type === x)).map((x) => chip("type", x, t("t_" + x))).join("")}</div></div>
          <div><h3>${esc(t("f_size"))}</h3><div class="chips">${["XS", "S", "M", "L", "XL"].map((x) => chip("size", x, x)).join("")}</div></div>
          <div><h3>${esc(t("f_colour"))}</h3><div class="sws">${Object.values(colors).map((c) => `<button class="sw ${f.color.includes(c.key) ? "on" : ""}" data-act="f" data-g="color" data-v="${esc(c.key)}" title="${esc(L(c.name))}" aria-label="${esc(L(c.name))}" aria-pressed="${f.color.includes(c.key)}"><i style="background:${esc(c.base)}"></i><i style="background:${esc(c.accent)}"></i></button>`).join("")}</div></div>
          <div><h3>${esc(t("f_price"))}</h3><div class="chips">${[["a", t("under", { p: fmt(1000) })], ["b", t("between", { a: fmt(1000), b: fmt(2000) })], ["c", t("over", { p: fmt(2000) })]].map(([k, v]) => `<button class="chip ${f.price === k ? "on" : ""}" data-act="fp" data-v="${k}">${esc(v)}</button>`).join("")}</div></div>
          <div><h3>${esc(t("f_custom_h"))}</h3><label class="check"><input type="checkbox" data-in="fcustom" ${f.custom ? "checked" : ""}> ${esc(t("f_custom"))}</label></div>
          <div><h3>${esc(t("f_avail"))}</h3><label class="check"><input type="checkbox" data-in="fstock" ${f.stock ? "checked" : ""}> ${esc(t("f_stock"))}</label></div>
          <button class="link" data-act="fclear" style="justify-self:start">${esc(t("f_clear"))}</button>
        </aside>
        <div>
          <div class="shopbar">
            <div style="display:flex;gap:.5rem;align-items:center;flex-wrap:wrap"><button class="btn ghost small filters-btn" data-act="fshow">${esc(t("filters"))}</button>
              <span class="note">${esc(t("results", { n: num(list.length) }))}</span>${f.q ? `<button class="chip on" data-act="fq">“${esc(f.q)}” ✕</button>` : ""}</div>
            <label style="display:flex;gap:.5rem;align-items:center;font-size:.8rem"><span>${esc(t("sort"))}</span>
              <select data-in="sort" id="sortSel">${[["featured", "s_featured"], ["new", "s_new"], ["low", "s_low"], ["high", "s_high"]].map(([k, v]) => `<option value="${k}" ${f.sort === k ? "selected" : ""}>${esc(t(v))}</option>`).join("")}</select></label>
          </div>
          ${list.length ? `<div class="grid">${list.map(card).join("")}</div>` : `<div class="empty">${moon(36, "#6e2135")}<p>${esc(t("no_results"))}</p><button class="btn ghost small" data-act="fclear">${esc(t("f_clear"))}</button></div>`}
        </div>
      </div>
      <div class="col-foot">
        ${col === "winter" ? `<div class="cf dark">${moon(40, "#fad6e1")}</div><div class="cf"><b>${esc(t("warm_t"))}</b><span>${esc(t("warm_s"))}</span></div>` : ""}
        <div class="cf"><b>${moon(20, "#6e2135")} ${esc(t("cust_t"))}</b><span>${esc(t("cust_s"))}</span><a class="link" href="#customize">${esc(t("cust_cta"))}</a></div>
      </div>
    </div>`;
  }
  function searchText(p) {
    return [p.name.en, p.name.ar, p.type, t("t_" + p.type), ...(p.collections || []), ...(p.collections || []).map((c) => I.en["col_" + c] + " " + I.ar["col_" + c]), ...p.colors.flatMap((c) => [c.key, c.name.en, c.name.ar])].join(" ").toLowerCase();
  }

  /* ---------- embroidery controls ---------- */
  const FONT_KEYS = ["script", "serif", "sans", "hand", "mono"];
  const THREAD_KEYS = ["ballet", "baby", "rose", "burgundy", "chocolate", "cream", "white", "black", "sage"];
  const ICON_KEYS = ["", "moon", "heart", "star", "bow", "flower"];
  function embControls(scope, c, placements, idp) {
    return `
      <label class="f" for="${idp}Text">${esc(t("c_step2"))}<input type="text" id="${idp}Text" maxlength="12" value="${esc(c.text)}" placeholder="${esc(t("c_text_ph"))}" data-in="embtext" data-scope="${scope}"><span class="hint">${esc(t("c_text_help"))}</span></label>
      <div class="opt"><div class="opt-h"><span>${esc(t("c_font_h"))}</span><span>${esc(t("font_" + c.font))}</span></div>
        <div class="fontpick">${FONT_KEYS.map((k) => `<button type="button" class="${c.font === k ? "on" : ""}" data-act="emb" data-scope="${scope}" data-k="font" data-v="${k}" aria-pressed="${c.font === k}"><b style="font-family:${Art.FONTS[k]}">${k === "mono" ? "M.a" : "Aa"}</b><span>${esc(t("font_" + k))}</span></button>`).join("")}</div></div>
      <div class="opt"><div class="opt-h"><span>${esc(t("c_thread_h"))}</span><span>${esc(t("th_" + c.thread))}</span></div>
        <div class="threads">${THREAD_KEYS.map((k) => `<button type="button" class="thread ${c.thread === k ? "on" : ""}" data-act="emb" data-scope="${scope}" data-k="thread" data-v="${k}" aria-pressed="${c.thread === k}"><i style="background:${Art.THREADS[k]}"></i>${esc(t("th_" + k))}</button>`).join("")}</div></div>
      <div class="opt"><div class="opt-h"><span>${esc(t("c_place_h"))}</span><span>${esc(t("pl_" + c.placement))}</span></div>
        <div class="placepick">${placements.map((k) => `<button type="button" class="${c.placement === k ? "on" : ""}" data-act="emb" data-scope="${scope}" data-k="placement" data-v="${k}" aria-pressed="${c.placement === k}">${glyph(k)}<span>${esc(t("pl_" + k))}</span></button>`).join("")}</div></div>
      <div class="opt"><div class="opt-h"><span>${esc(t("c_icon_h"))}</span><span>${esc(t("optional"))}</span></div>
        <div class="icon-pick">${ICON_KEYS.map((k) => `<button type="button" class="${(c.icon || "") === k ? "on" : ""}" data-act="emb" data-scope="${scope}" data-k="icon" data-v="${k}" aria-pressed="${(c.icon || "") === k}" aria-label="${esc(t("icon_" + (k || "none")))}">${k ? Art.icon(k, 18, "#6e2135") : `<span style="font-size:.7rem">${esc(t("icon_none"))}</span>`}</button>`).join("")}</div></div>
      <label class="f" for="${idp}Note">${esc(t("c_note_label"))} <span class="hint">${esc(t("optional"))}</span><textarea id="${idp}Note" rows="2" maxlength="200" placeholder="${esc(t("c_note_ph"))}" data-in="embnote" data-scope="${scope}">${esc(c.note || "")}</textarea></label>`;
  }
  function embState(scope) {
    if (scope === "pdp") return S.pdp.c;
    if (scope === "cz") return S.cz;
    if (scope === "mixtop") return S.mix.cTop;
    if (scope === "mixbot") return S.mix.cBot;
    return null;
  }
  const validText = (s) => !!(s && s.trim() && [...s.trim()].length <= 12);

  /* ---------- PRODUCT ---------- */
  function vProduct(id) {
    const p = P(id);
    if (!p) return `<div class="wrap"><div class="empty" style="margin-block:4rem"><p>${esc(t("no_results"))}</p><a class="btn" href="#shop">${esc(t("back_shop"))}</a></div></div>`;
    if (S.pdp.id !== id) resetPdp(id);
    const s = S.pdp, col = colorOf(p, s.color);
    setMeta(L(p.name), L(p.desc)); productLd(p);
    if (S._viewed !== id) { S._viewed = id; track("view_item", { item_id: id, value: p.price, currency: "EGP" }); }
    const emb = canEmb(p);
    const custom = s.c.on && s.c.text ? s.c : null;
    const sampleC = custom || { text: "L.N", font: "script", thread: "burgundy", placement: Art.placementsFor(p)[0], icon: "moon" };
    let main;
    if (s.view === "detail") main = Art.draw(p, { color: s.color, custom: sampleC, zoom: true });
    else if (p.image && !custom) main = `<img src="${esc(p.image)}" alt="${esc(L(p.name))}">`;
    else main = Art.draw(p, { color: s.color, custom });
    const unit = p.price + (custom ? fee() : 0);
    const related = S.products.filter((x) => x.id !== p.id && (x.collections || []).some((c) => (p.collections || []).includes(c))).slice(0, 4);
    const col0 = (p.collections || [])[0];
    return `<div class="wrap">
      <div class="page-head" style="padding-bottom:1rem"><div class="crumbs"><a href="#home">${esc(t("nav_home"))}</a><span>/</span><a href="#shop">${esc(t("nav_collections"))}</a>${col0 ? `<span>/</span><a href="#shop-${col0}">${esc(t("col_" + col0))}</a>` : ""}<span>/</span><span>${esc(L(p.name))}</span></div></div>
      <div class="pdp">
        <div class="gallery">
          <div class="main zoomable" id="pdpMain">${main}</div>
          <div class="thumbs"><button class="${s.view === "full" ? "on" : ""}" data-act="pview" data-v="full" aria-label="${esc(L(p.name))}">${Art.draw(p, { color: s.color })}</button>
            ${emb ? `<button class="${s.view === "detail" ? "on" : ""}" data-act="pview" data-v="detail" aria-label="${esc(t("c_pol1"))}">${Art.draw(p, { color: s.color, custom: sampleC, zoom: true })}</button>` : ""}
            ${p.colors.filter((c) => c.key !== s.color).slice(0, emb ? 1 : 2).map((c) => `<button data-act="pcolor" data-v="${esc(c.key)}" aria-label="${esc(L(c.name))}">${Art.draw(p, { color: c.key })}</button>`).join("")}</div>
        </div>
        <div class="buy">
          <div style="display:flex;gap:.3rem;flex-wrap:wrap">${p.isNew ? `<span class="tag">${esc(t("badge_new"))}</span>` : ""}${emb ? `<span class="tag soft">${moon(10, "#6e2135")} ${esc(t("badge_custom"))}</span>` : ""}${p.inStock === false ? `<span class="tag out">${esc(t("sold_out"))}</span>` : ""}</div>
          <h1>${esc(L(p.name))}</h1>
          <div class="price" id="pdpPrice">${fmt(unit)}${p.compareAt ? `<s>${fmt(p.compareAt)}</s>` : ""}</div>
          <p class="lede">${esc(L(p.desc))}</p>
          <div class="opt"><div class="opt-h"><span>${esc(t("colour"))}</span><span>${esc(col ? L(col.name) : "")}</span></div>
            <div class="sws">${p.colors.map((c) => `<button class="sw ${c.key === s.color ? "on" : ""}" data-act="pcolor" data-v="${esc(c.key)}" aria-label="${esc(L(c.name))}" aria-pressed="${c.key === s.color}"><i style="background:${esc(c.base)}"></i><i style="background:${esc(c.accent)}"></i></button>`).join("")}</div></div>
          <div class="opt"><div class="opt-h"><span>${esc(t("size"))}</span><a class="link" href="#help-size">${esc(t("size_guide"))}</a></div>
            <div class="chips">${p.sizes.map((z) => `<button class="chip ${s.size === z ? "on" : ""}" data-act="psize" data-v="${esc(z)}" aria-pressed="${s.size === z}" ${(p.soldOutSizes || []).includes(z) ? "disabled" : ""}>${esc(z)}</button>`).join("")}</div></div>
          ${emb ? `<div class="perso"><button class="perso-h" data-act="ptoggle" aria-expanded="${s.c.on}"><span>${moon(16, "#6e2135")} ${esc(t("personalize"))}</span><span class="note">${esc(t("personalize_fee", { p: fmt(fee()) }))}</span></button>
            ${s.c.on ? `<div class="in">${embControls("pdp", s.c, Art.placementsFor(p), "pdp")}<p class="note">${esc(t("c_note"))}</p></div>` : ""}</div>` : ""}
          ${s.err ? `<p class="err" role="alert">${esc(s.err)}</p>` : ""}
          <div class="buyrow"><div class="qty"><button data-act="pqty" data-d="-1" aria-label="-">−</button><span>${num(s.qty)}</span><button data-act="pqty" data-d="1" aria-label="+">+</button></div>
            <button class="btn addcart" data-act="padd" ${p.inStock === false ? "disabled" : ""}>${esc(p.inStock === false ? t("sold_out") : t("add_bag"))}</button></div>
          <div class="acc">
            <details open><summary>${esc(t("details"))}</summary><div class="body"><p>${esc(L(p.desc))}</p></div></details>
            <details><summary>${esc(t("fabric_care"))}</summary><div class="body"><p>${esc(L(p.fabric))}</p><a class="link" href="#help-care">${esc(t("h_care"))}</a></div></details>
            <details><summary>${esc(t("size_guide"))}</summary><div class="body"><p>${esc(SIZES.fit[S.lang])}</p><a class="link" href="#help-size">${esc(t("h_size"))}</a></div></details>
            <details><summary>${esc(t("delivery"))}</summary><div class="body"><p>${esc(t("delivery_line"))}</p><a class="link" href="#help-shipping">${esc(t("h_shipping"))}</a></div></details>
          </div>
        </div>
      </div>
      ${related.length ? `<section class="sec" style="padding-top:0"><div class="sec-head"><h2>${esc(t("you_may"))}</h2></div><div class="grid">${related.map(card).join("")}</div></section>` : ""}
    </div>`;
  }

  /* ---------- CUSTOMIZE YOUR PYJAMAS (customization mockup) ---------- */
  function vCustomize() {
    const pieces = S.products.filter((p) => canEmb(p) && p.inStock !== false);
    const z = S.cz;
    if (!z.pid || !pieces.find((p) => p.id === z.pid)) z.pid = (pieces.find((p) => p.id === "classic-set") || pieces[0] || {}).id;
    const p = P(z.pid);
    if (!p) return `<div class="wrap"><div class="empty">${esc(t("no_results"))}</div></div>`;
    if (!z.color || !p.colors.find((c) => c.key === z.color)) z.color = p.colors[0].key;
    const pls = Art.placementsFor(p);
    if (!pls.includes(z.placement)) z.placement = pls[0];
    if (z.size && !p.sizes.includes(z.size)) z.size = "";
    if (p.sizes.length === 1) z.size = p.sizes[0];
    const c = { text: z.text || "Haya", font: z.font, thread: z.thread, placement: z.placement, icon: z.icon };
    const step = (n, k, body, done) => `<div class="step"><span class="n ${done ? "done" : ""}">${num(n)}</span><div><h3>${esc(t("c_step" + k))}</h3><p class="note">${esc(t("c_step" + k + "s"))}</p><div class="step-body">${body}</div></div></div>`;
    return `<div class="wrap"><div class="cz">
      <div class="cz-stage">
        <span class="cz-side">${moon(20, "#6e2135")}<span>${esc(t("c_side"))}</span></span>
        <div class="main" id="czMain">${Art.draw(p, { color: z.color, custom: c })}</div>
        <div class="polaroids">
          <figure class="polaroid"><div class="in" id="czZoom">${Art.draw(p, { color: z.color, custom: c, zoom: true })}</div><figcaption>${esc(t("c_pol1"))} ♡</figcaption></figure>
          <figure class="polaroid"><div class="in"><img src="assets/brand-crescents.jpg" alt=""></div><figcaption>${esc(t("c_pol2"))} ♡</figcaption></figure>
          <div class="cz-card"><span class="script">${esc(t("c_card"))}</span>${moon(18, "#6e2135")}</div>
        </div>
      </div>
      <div>
        <div class="cz-head"><span class="eyebrow">LuneByNoon</span><h1>${esc(t("c_title"))}</h1><p class="tagline-it">${esc(t("c_tag"))}</p><span class="divider">${moon(16, "#6e2135")}</span><p class="lede">${esc(t("c_sub"))}</p></div>
        <div class="steps">
          ${step(1, 1, `<div class="piece-pick">${pieces.map((x) => `<button class="${x.id === p.id ? "on" : ""}" data-act="czp" data-v="${esc(x.id)}" aria-pressed="${x.id === p.id}">${Art.draw(x)}<span>${esc(L(x.name))}</span></button>`).join("")}</div>
            <div class="row-opts"><div class="opt"><div class="opt-h"><span>${esc(t("colour"))}</span></div><div class="sws">${p.colors.map((cc) => `<button class="sw ${cc.key === z.color ? "on" : ""}" data-act="czc" data-v="${esc(cc.key)}" aria-label="${esc(L(cc.name))}"><i style="background:${esc(cc.base)}"></i><i style="background:${esc(cc.accent)}"></i></button>`).join("")}</div></div>
            <div class="opt"><div class="opt-h"><span>${esc(t("size"))}</span><a class="link" href="#help-size">${esc(t("size_guide"))}</a></div><div class="chips">${p.sizes.map((s) => `<button class="chip ${z.size === s ? "on" : ""}" data-act="czs" data-v="${esc(s)}">${esc(s)}</button>`).join("")}</div></div></div>`, !!z.size)}
          ${step(2, 2, `<input type="text" id="czText" maxlength="12" value="${esc(z.text)}" placeholder="${esc(t("c_text_ph"))}" data-in="embtext" data-scope="cz" aria-label="${esc(t("c_step2"))}"><p class="note">${esc(t("c_text_help"))}</p>
            <div class="opt"><div class="opt-h"><span>${esc(t("c_icon_h"))}</span><span>${esc(t("optional"))}</span></div><div class="icon-pick">${ICON_KEYS.map((k) => `<button type="button" class="${(z.icon || "") === k ? "on" : ""}" data-act="emb" data-scope="cz" data-k="icon" data-v="${k}" aria-label="${esc(t("icon_" + (k || "none")))}">${k ? Art.icon(k, 18, "#6e2135") : `<span style="font-size:.7rem">${esc(t("icon_none"))}</span>`}</button>`).join("")}</div></div>
            <label class="f" for="czNote">${esc(t("c_note_label"))} <span class="hint">${esc(t("optional"))}</span><textarea id="czNote" rows="2" maxlength="200" placeholder="${esc(t("c_note_ph"))}" data-in="embnote" data-scope="cz">${esc(z.note)}</textarea></label>`, validText(z.text))}
          ${step(3, 3, `<div class="fontpick">${FONT_KEYS.map((k) => `<button type="button" class="${z.font === k ? "on" : ""}" data-act="emb" data-scope="cz" data-k="font" data-v="${k}" aria-pressed="${z.font === k}"><b style="font-family:${Art.FONTS[k]}">${k === "mono" ? "M.a" : "Aa"}</b><span>${esc(t("font_" + k))}</span></button>`).join("")}</div>`, true)}
          ${step(4, 4, `<div class="threads">${THREAD_KEYS.map((k) => `<button type="button" class="thread ${z.thread === k ? "on" : ""}" data-act="emb" data-scope="cz" data-k="thread" data-v="${k}" aria-pressed="${z.thread === k}"><i style="background:${Art.THREADS[k]}"></i>${esc(t("th_" + k))}</button>`).join("")}</div>`, true)}
          ${step(5, 5, `<div class="placepick">${pls.map((k) => `<button type="button" class="${z.placement === k ? "on" : ""}" data-act="emb" data-scope="cz" data-k="placement" data-v="${k}" aria-pressed="${z.placement === k}">${glyph(k)}<span>${esc(t("pl_" + k))}</span></button>`).join("")}</div>`, true)}
          ${step(6, 6, `<div class="cz-sum">
              <div class="ln"><span>${esc(L(p.name))} · ${esc(L(colorOf(p, z.color).name))}${z.size ? " · " + esc(z.size) : ""}</span><span>${fmt(p.price)}</span></div>
              <div class="ln"><span>${esc(t("c_fee"))}${z.text ? `: “${esc(z.text)}” · ${esc(t("font_" + z.font))} · ${esc(t("th_" + z.thread))} · ${esc(t("pl_" + z.placement))}${z.icon ? " · " + esc(t("icon_" + z.icon)) : ""}` : ""}</span><span>${fmt(fee())}</span></div>
              <div class="ln tot"><span>${esc(t("co_total"))}</span><span>${fmt(p.price + fee())}</span></div>
              ${z.err ? `<p class="err" role="alert">${esc(z.err)}</p>` : ""}
              <p class="note">${esc(t("c_note"))}</p>
              <button class="btn block addcart" data-act="czadd">${esc(t("c_cta"))} ${ARROW}</button></div>`, false)}
        </div>
      </div></div></div>`;
  }
  /* the monogram drawn on the real photograph in the customize stage */
  function syncCzMono(st) {
    const fig = document.querySelector(".w-cz-photo"); if (!fig) return;
    let m = fig.querySelector(".w-cz-mono");
    if (!st.text) { if (m) m.remove(); return; }
    if (!m) { m = document.createElement("span"); m.className = "w-cz-mono"; fig.appendChild(m); }
    const PLACE = { left: [53, 33], right: [43, 33], pocket: [55, 41], sleeve: [31, 48], trousers: [49, 66] };
    const xy = PLACE[st.placement] || PLACE.left;
    m.dataset.place = st.placement;
    m.style.left = xy[0] + "%"; m.style.top = xy[1] + "%";
    m.style.color = (Art.THREADS || {})[st.thread] || "#6e2135";
    m.style.fontFamily = (Art.FONTS || {})[st.font] || "";
    m.textContent = st.text;
  }
  function refreshCzPreview() {
    const z = S.cz, p = P(z.pid); if (!p) return;
    const c = { text: z.text || "Haya", font: z.font, thread: z.thread, placement: z.placement, icon: z.icon };
    const m = $("#czMain"); if (m) m.innerHTML = Art.draw(p, { color: z.color, custom: c });
    const zz = $("#czZoom"); if (zz) zz.innerHTML = Art.draw(p, { color: z.color, custom: c, zoom: true });
    if (window.LBNUI) window.LBNUI.onCz();
  }

  /* ---------- MIX & MATCH (five steps from the guidelines) ---------- */
  function mixQuote() {
    const m = S.mix, top = P(m.top), bot = P(m.bottom);
    const base = (top ? top.price : 0) + (bot ? bot.price : 0);
    const discount = top && bot ? Math.round(base * (Number(S.settings.setDiscountPct) || 0) / 100) : 0;
    let extra = Object.keys(m.addons).reduce((a, id) => a + ((P(id) || {}).price || 0), 0);
    const embs = (top && m.cTop.on && m.cTop.text ? 1 : 0) + (bot && m.cBot.on && m.cBot.text ? 1 : 0);
    extra += embs * fee();
    return { discount, total: base - discount + extra, embs };
  }
  function vMix() {
    const m = S.mix;
    const tops = S.products.filter((p) => p.type === "top" && p.inStock !== false);
    const bottoms = S.products.filter((p) => p.type === "bottom" && p.inStock !== false);
    const extras = S.products.filter((p) => (p.type === "robe" || p.type === "accessory") && p.inStock !== false && !(p.collections || []).includes("bridal") && !(p.collections || []).includes("postpartum"));
    const top = P(m.top), bot = P(m.bottom);
    const q = mixQuote();
    const pick = (p, which) => {
      const sel = which === "top" ? m.top : m.bottom;
      const colKey = which === "top" ? m.topColor : m.bottomColor;
      const sizeVal = which === "top" ? m.topSize : m.bottomSize;
      const on = sel === p.id, ck = on ? colKey : p.colors[0].key;
      return `<div class="pick ${on ? "on" : ""}">
        <button class="ph" data-act="mxpick" data-w="${which}" data-v="${esc(p.id)}" aria-pressed="${on}" aria-label="${esc(L(p.name))}">${p.image ? `<img src="${esc(p.image)}" alt="">` : Art.draw(p, { color: ck })}</button>
        <div class="nm">${esc(L(p.name))}</div><div class="pr">${esc(L(colorOf(p, ck).name))} · ${fmt(p.price)}</div>
        <div class="sws">${p.colors.map((c) => `<button class="sw ${on && c.key === colKey ? "on" : ""}" data-act="mxcol" data-w="${which}" data-p="${esc(p.id)}" data-v="${esc(c.key)}" aria-label="${esc(L(c.name))}"><i style="background:${esc(c.base)}"></i><i style="background:${esc(c.accent)}"></i></button>`).join("")}</div>
        ${on ? `<select data-in="mxsize" data-w="${which}" aria-label="${esc(t("size"))}"><option value="">${esc(t("size"))}</option>${p.sizes.map((s) => `<option ${sizeVal === s ? "selected" : ""}>${esc(s)}</option>`).join("")}</select>` : ""}
      </div>`;
    };
    const stepOn = !top ? 1 : !bot ? 2 : 5;
    const head = (n, k, extra) => `<header><span class="n">${num(n)}</span><div><h2>${esc(t("m_s" + k))}</h2><p>${esc(t("m_s" + k + "s"))}</p></div>${extra || ""}</header>`;
    const sizeLink = `<a class="link sgl" href="#help-size">${esc(t("view_size_guide"))} ${ARROW}</a>`;
    const embBlock = (scope, piece, st, label) => !piece ? "" : !canEmb(piece) ? "" : `<div class="emb-block"><label class="check"><input type="checkbox" data-in="mxon" data-scope="${scope}" ${st.on ? "checked" : ""}> ${esc(label)} <span class="note">${esc(t("personalize_fee", { p: fmt(fee()) }))}</span></label>
      ${st.on ? `<div class="emb-grid"><div class="emb-prev">${Art.draw(piece, { color: scope === "mixtop" ? m.topColor : m.bottomColor, custom: st.text ? st : null })}</div><div style="display:grid;gap:1rem">${embControls(scope, st, Art.placementsFor(piece), scope)}</div></div>` : ""}</div>`;
    const reviewLines = [];
    if (top) reviewLines.push(["mxs1", t("m_top"), top, m.topColor, m.topSize, top.price, m.cTop.on && m.cTop.text ? m.cTop : null]);
    if (bot) reviewLines.push(["mxs2", t("m_bottom"), bot, m.bottomColor, m.bottomSize, bot.price, m.cBot.on && m.cBot.text ? m.cBot : null]);
    Object.keys(m.addons).forEach((id) => { const p = P(id); if (p) reviewLines.push(["mxs3", t("m_addon"), p, m.addons[id].color, m.addons[id].size, p.price, null]); });
    const ysLine = ([anchor, label, p, ck, size, price, c]) => `<div class="ys-line">${Art.draw(p, { color: ck, custom: c })}<div><b>${esc(label)}</b>${esc(L(p.name))} - ${esc(L(colorOf(p, ck).name))}<br><span class="note">${esc(t("size"))}: ${esc(size || "–")}</span><br><span class="price">${fmt(price)}</span></div></div>`;
    const custLines = [m.cTop.on && m.cTop.text && top ? m.cTop : null, m.cBot.on && m.cBot.text && bot ? m.cBot : null].filter(Boolean);
    return `<div class="wrap" style="padding-top:1.5rem">
      <div class="mx-hero"><div class="pad"><span class="eyebrow">${esc(t("m_eyebrow"))}</span><h1>${esc(t("m_title"))}</h1><p class="lede">${esc(t("m_sub"))}</p><a class="btn" href="#mx-steps" data-act="tosteps">${esc(t("m_start"))} ${ARROW}</a></div>
        <div class="vis">${["classic-top", "winter-top", "classic-pants"].map(P).filter(Boolean).map((p) => Art.draw(p, { custom: p.id === "classic-top" ? { text: "L.N", font: "script", thread: "burgundy", placement: "left" } : null })).join("")}</div></div>
      <div class="progress">${["pr_top", "pr_bottom", "pr_addons", "pr_custom", "pr_review"].map((k, i) => `<span class="${i + 1 <= stepOn ? "on" : ""}"><b>${num(i + 1)}</b>${esc(t(k))}</span>`).join('<i class="dash"></i>')}</div>
      <div class="mx" id="mx-steps">
        <div class="mx-steps">
          <section class="mx-step" id="mxs1">${head(1, 1, sizeLink)}<div class="pickrow">${tops.map((p) => pick(p, "top")).join("")}</div></section>
          <section class="mx-step" id="mxs2">${head(2, 2, sizeLink)}<div class="pickrow">${bottoms.map((p) => pick(p, "bottom")).join("")}</div></section>
          <section class="mx-step" id="mxs3">${head(3, 3)}
            <div class="addons">${extras.map((p) => {
              const a = m.addons[p.id];
              return `<div class="addon ${a ? "on" : ""}">${Art.draw(p)}<div><b>${esc(L(p.name))}</b><small>${fmt(p.price)}</small>
                ${a && p.sizes.length > 1 ? `<select data-in="mxasize" data-p="${esc(p.id)}" aria-label="${esc(t("size"))}">${p.sizes.map((s) => `<option ${a.size === s ? "selected" : ""}>${esc(s)}</option>`).join("")}</select>` : ""}</div>
                <button data-act="mxadd" data-p="${esc(p.id)}" aria-pressed="${!!a}" aria-label="${esc(L(p.name))}">${a ? "✓" : "+"}</button></div>`;
            }).join("")}</div></section>
          <section class="mx-step" id="mxs4">${head(4, 4)}
            ${!top && !bot ? `<p class="note">${esc(t("m_need"))}</p>` : ""}
            ${embBlock("mixtop", top, m.cTop, t("m_on_top") + (top ? ": " + L(top.name) : ""))}
            ${embBlock("mixbot", bot, m.cBot, t("personalize") + (bot ? ": " + L(bot.name) : ""))}
          </section>
          <section class="mx-step" id="mxs5">${head(5, 5)}
            ${reviewLines.length ? `<div class="review">${reviewLines.map(([anchor, label, p, ck, size, price, c]) => `<div class="rv">
                <span class="th">${Art.draw(p, { color: ck, custom: c })}</span>
                <span><b>${esc(label)}</b> ${esc(L(p.name))}<br><span class="note">${esc(t("colour"))}: ${esc(L(colorOf(p, ck).name))} · ${esc(t("size"))}: ${esc(size || "–")}</span>${c ? `<br><span class="emb">${embText(c)}</span>` : ""}</span>
                <span class="price">${fmt(price + (c ? fee() : 0))}</span>
                <a class="link" href="#${anchor}" data-act="toanchor" data-v="${anchor}">${esc(t("m_edit"))}</a></div>`).join("")}
              ${q.discount ? `<div class="rv tot ok"><span></span><span>${esc(t("m_save"))}</span><span class="price">−${fmt(q.discount)}</span><span></span></div>` : ""}
              <div class="rv tot"><span></span><span>${esc(t("co_total"))}</span><span class="price">${fmt(q.total)}</span><span></span></div></div>`
              : `<p class="note">${esc(t("m_need"))}</p>`}
            ${m.err ? `<p class="err" role="alert">${esc(m.err)}</p>` : ""}
            <button class="btn addcart" data-act="mxbag" style="justify-self:start">${esc(t("m_add"))} ${ARROW}</button>
          </section>
        </div>
        <aside class="yourset" aria-label="${esc(t("m_your"))}">
          <h3><span>${moon(18, "#6e2135")} ${esc(t("m_your"))}</span><a class="link" href="#mxs1" data-act="toanchor" data-v="mxs1">✎ ${esc(t("m_edit"))}</a></h3>
          ${reviewLines.length ? reviewLines.map(ysLine).join("") : `<p class="note">${esc(t("m_need"))}</p>`}
          ${custLines.map((c) => `<div class="ys-line"><span class="ic">${moon(26, "#6e2135")}</span><div><b>${esc(t("m_custom"))}</b>${esc(t("font_" + c.font))} · ${esc(t("th_" + c.thread))}<br>“${esc(c.text)}” · ${esc(t("pl_" + c.placement))}<br><span class="price">+ ${fmt(fee())}</span></div></div>`).join("")}
          ${q.discount ? `<div class="ys-tot ok"><span>${esc(t("m_save"))}</span><span>−${fmt(q.discount)}</span></div>` : `<p class="note">${esc(t("m_save_note", { pct: num(S.settings.setDiscountPct || 0) }))}</p>`}
          <div class="ys-tot"><span>${esc(t("co_total"))}</span><span>${fmt(q.total)}</span></div>
          <button class="btn block addcart" data-act="mxbag">${esc(t("m_add"))} ${ARROW}</button>
        </aside>
      </div>
      <div class="perks"><div>${ICON.gift}<span><b>${esc(t("m_perks1"))}</b>${esc(t("m_perks1s"))}</span></div><div>${moon(24, "#6e2135")}<span><b>${esc(t("m_perks2"))}</b>${esc(t("m_perks2s"))}</span></div><div>${ICON.truck}<span><b>${esc(t("m_perks3"))}</b>${esc(t("m_perks3s"))}</span></div></div>
    </div>`;
  }

  /* ---------- BUNDLES (each bundle states the six points from the guidelines) ---------- */
  const bWorth = (b) => b.items.reduce((a, id) => a + ((P(id) || {}).price || 0), 0);
  function bDefs(b) {
    const worth = bWorth(b);
    const custom = [...new Set(b.items.map(P).filter(canEmb).map((p) => L(p.name)))];
    const rows = [
      [t("b_includes"), b.items.map((id) => L((P(id) || {}).name)).join(", ")],
      [t("b_choose_h"), t("b_choose_v")],
      [t("b_custom_h"), custom.length ? t("b_custom_v", { list: custom.join(", ") }) : t("b_custom_none")],
      [t("b_price_h"), b.priceType === "calculated" ? t("b_price_calc") : t("b_price_fixed")],
      [t("b_disc_h"), worth > b.price ? t("b_disc_v", { p: fmt(worth - b.price) }) : "–"],
      [t("b_stock_h"), t("b_stock_v")],
      [t("b_sep_h"), b.soldSeparately === false ? t("b_sep_no") : t("b_sep_yes")]
    ];
    return `<dl class="bdefs">${rows.map(([k, v]) => `<div><dt>${esc(k)}</dt><dd>${esc(v)}</dd></div>`).join("")}</dl>`;
  }
  const bundleSoldOut = (b) => b.items.some((id) => (P(id) || {}).inStock === false);
  function vBundles() {
    return `<div class="wrap">
      <div class="page-head" style="text-align:center;justify-items:center"><span class="eyebrow">${esc(t("b_eyebrow"))}</span><h1>${esc(t("b_title"))}</h1><p class="lede" style="text-align:center">${esc(t("b_sub"))}</p><p class="note">${moon(12, "#6e2135")} ${esc(t("b_future"))}</p></div>
      <div class="bundles">${S.bundles.map((b) => {
        const worth = bWorth(b), out = bundleSoldOut(b);
        return `<article class="bundle"><div class="vis">${b.items.slice(0, 3).map((id) => { const p = P(id); return p ? Art.draw(p) : ""; }).join("")}${out ? `<span class="tag out" style="position:absolute;top:12px;inset-inline-start:12px">${esc(t("sold_out"))}</span>` : ""}</div>
          <div class="pad"><h3>${esc(L(b.name))}</h3><p class="note">${esc(L(b.desc))}</p>
            <div class="prices"><span class="price" style="font-size:1.2rem">${fmt(b.price)}</span><s class="note">${esc(t("b_worth", { p: fmt(worth) }))}</s></div>
            ${worth > b.price ? `<span class="save">${esc(t("b_save", { p: fmt(worth - b.price) }))}</span>` : ""}
            ${bDefs(b)}
            <a class="btn" href="#b-${esc(b.id)}" style="justify-self:start;margin-top:.4rem" ${out ? 'aria-disabled="true"' : ""}>${esc(t("b_choose"))} ${ARROW}</a></div></article>`;
      }).join("")}</div></div>`;
  }
  function bState(b) {
    if (!S.bsel[b.id]) S.bsel[b.id] = b.items.map((id) => { const p = P(id) || { colors: [{}], sizes: [] }; return Object.assign({ pid: id, color: (p.colors[0] || {}).key, size: p.sizes.length === 1 ? p.sizes[0] : "" }, blankEmb(p.id ? (Art.placementsFor(p)[0] || "") : "")); });
    return S.bsel[b.id];
  }
  function vBundle(id) {
    const b = B(id);
    if (!b) return vBundles();
    setMeta(L(b.name), L(b.desc));
    const sel = bState(b), worth = bWorth(b), out = bundleSoldOut(b);
    const fees = sel.filter((x) => validText(x.text)).length * fee();
    return `<div class="wrap">
      <div class="page-head"><div class="crumbs"><a href="#home">${esc(t("nav_home"))}</a><span>/</span><a href="#bundles">${esc(t("nav_bundles"))}</a><span>/</span><span>${esc(L(b.name))}</span></div><h1>${esc(L(b.name))}</h1><p class="lede">${esc(L(b.desc))}</p>
        <div class="prices" style="display:flex;gap:.8rem;align-items:baseline;flex-wrap:wrap"><span class="price" style="font-size:1.3rem">${fmt(b.price)}</span><s class="note">${esc(t("b_worth", { p: fmt(worth) }))}</s>${worth > b.price ? `<span class="save">${esc(t("b_save", { p: fmt(worth - b.price) }))}</span>` : ""}</div></div>
      <div class="bundle-detail">
        <div style="display:grid;gap:1rem">
        ${sel.map((x, i) => {
          const p = P(x.pid); if (!p) return "";
          const pls = Art.placementsFor(p);
          const sb = (k, opts, label) => `<label class="f">${esc(label)}<select data-in="bopt" data-k="${k}" data-b="${esc(b.id)}" data-i="${i}">${opts.map(([v, l]) => `<option value="${v}" ${x[k] === v ? "selected" : ""}>${esc(l)}</option>`).join("")}</select></label>`;
          return `<div class="bpiece">${Art.draw(p, { color: x.color, custom: validText(x.text) ? x : null })}<div class="opts">
            <b>${esc(t("b_each", { n: num(i + 1) }))}: ${esc(L(p.name))}</b>
            <div class="sws">${p.colors.map((c) => `<button class="sw ${c.key === x.color ? "on" : ""}" data-act="bcol" data-b="${esc(b.id)}" data-i="${i}" data-v="${esc(c.key)}" aria-label="${esc(L(c.name))}"><i style="background:${esc(c.base)}"></i><i style="background:${esc(c.accent)}"></i></button>`).join("")}</div>
            <div class="chips">${p.sizes.map((s) => `<button class="chip ${x.size === s ? "on" : ""}" data-act="bsize" data-b="${esc(b.id)}" data-i="${i}" data-v="${esc(s)}">${esc(s)}</button>`).join("")}</div>
            ${canEmb(p) ? `<details class="bemb" ${x.text ? "open" : ""}><summary>${moon(14, "#6e2135")} ${esc(t("personalize"))} <span class="note">${esc(t("personalize_fee", { p: fmt(fee()) }))}</span></summary>
              <div class="row3">
                <label class="f">${esc(t("c_step2"))}<input type="text" maxlength="12" value="${esc(x.text)}" placeholder="${esc(t("c_text_ph"))}" data-in="btext" data-b="${esc(b.id)}" data-i="${i}"></label>
                ${sb("font", FONT_KEYS.map((k) => [k, t("font_" + k)]), t("font"))}
                ${sb("thread", THREAD_KEYS.map((k) => [k, t("th_" + k)]), t("thread"))}
                ${sb("placement", pls.map((k) => [k, t("pl_" + k)]), t("placement"))}
                ${sb("icon", ICON_KEYS.map((k) => [k, t("icon_" + (k || "none"))]), t("icon"))}
                <label class="f">${esc(t("c_note_label"))}<input type="text" maxlength="200" value="${esc(x.note)}" data-in="bnote" data-b="${esc(b.id)}" data-i="${i}"></label>
              </div></details>` : ""}
          </div></div>`;
        }).join("")}
        </div>
        <aside class="cz-sum"><div class="ln"><span>${esc(L(b.name))}</span><span>${fmt(b.price)}</span></div>${fees ? `<div class="ln"><span>${esc(t("c_fee"))}</span><span>${fmt(fees)}</span></div>` : ""}<div class="ln tot"><span>${esc(t("co_total"))}</span><span>${fmt(b.price + fees)}</span></div>
          ${S.bErr ? `<p class="err" role="alert">${esc(S.bErr)}</p>` : ""}<button class="btn block addcart" data-act="badd" data-b="${esc(b.id)}" ${out ? "disabled" : ""}>${esc(out ? t("sold_out") : t("b_add"))} ${ARROW}</button>
          ${bDefs(b)}<p class="note">${esc(t("b_future"))}</p></aside>
      </div></div>`;
  }

  /* ---------- CHECKOUT ---------- */
  function quote() {
    const st = S.settings, f = S.co.f;
    const sub = cartSub();
    const discount = Math.round(sub * (S.co.promoPct || 0) / 100);
    const after = sub - discount;
    let ship = null;
    if (f.gov) {
      const g = GOVS.find((x) => x[0] === f.gov);
      const z = g && st.zones && st.zones[g[3]];
      ship = after >= (Number(st.freeDeliveryOver) || Infinity) ? 0 : (z ? Number(z.fee) : 0);
    }
    const wrap = st.giftWrapEnabled && f.isGift && f.wrap ? Number(st.giftWrapFee) || 0 : 0;
    const cod = f.pay === "cod" ? Number(st.codFee) || 0 : 0;
    return { sub, discount, ship, wrap, cod, total: after + (ship || 0) + wrap + cod };
  }
  function field(id, label, opts) {
    opts = opts || {};
    const f = S.co.f, e = S.co.errs[id], type = opts.type || "text";
    const input = opts.textarea
      ? `<textarea id="co_${id}" data-in="co" data-k="${id}" ${opts.ph ? `placeholder="${esc(opts.ph)}"` : ""}>${esc(f[id] || "")}</textarea>`
      : `<input type="${type}" id="co_${id}" data-in="co" data-k="${id}" value="${esc(f[id] || "")}" ${opts.ac ? `autocomplete="${opts.ac}"` : ""} ${opts.ph ? `placeholder="${esc(opts.ph)}"` : ""} ${type === "tel" ? 'inputmode="tel" dir="ltr"' : ""}>`;
    return `<label class="f ${e ? "invalid" : ""}" for="co_${id}">${esc(label)}${opts.opt ? ` <span class="hint">${esc(t("optional"))}</span>` : ""}${input}${opts.hint ? `<span class="hint">${esc(opts.hint)}</span>` : ""}${e ? `<span class="err">${esc(e)}</span>` : ""}</label>`;
  }
  function vCheckout() {
    if (!S.cart.length) return `<div class="wrap"><div class="empty" style="margin-block:4rem">${moon(40, "#6e2135")}<p>${esc(t("co_empty"))}</p><a class="btn" href="#shop">${esc(t("cart_empty_cta"))}</a></div></div>`;
    if (!S._coTracked) { S._coTracked = true; track("begin_checkout", { value: cartSub(), currency: "EGP" }); }
    const f = S.co.f, q = quote(), st = S.settings;
    /* Card and installments only show once Paymob is switched on in the order inbox. */
    if (CFG.orderEndpoint && S.payReady == null) checkPayReady();
    const ready = CFG.orderEndpoint ? (S.payReady || {}) : { card: true, install: true };
    const pays = [["cod", "pay_cod"], ["card", "pay_card"], ["instapay", "pay_instapay"], ["wallet", "pay_wallet"], ["install", "pay_install"]].filter(([k]) => (k !== "card" || ready.card) && (k !== "install" || ready.install));
    if (!pays.some(([k]) => k === f.pay)) f.pay = "cod";
    return `<div class="wrap">
      <div class="page-head"><h1>${esc(t("co_title"))}</h1></div>
      <form class="co" id="coForm" novalidate>
        <div class="co-form">
          ${S.co.top ? `<div class="formerr" role="alert">${esc(S.co.top)}</div>` : ""}
          <section class="co-sec"><h2><span class="n">${num(1)}</span>${esc(t("co_contact"))}</h2>
            ${field("name", t("co_name"), { ac: "name" })}
            <div class="row2">${field("phone", t("co_phone"), { type: "tel", ac: "tel", hint: t("co_phone_help") })}${field("email", t("co_email"), { type: "email", ac: "email", hint: t("co_email_help") })}</div></section>
          <section class="co-sec"><h2><span class="n">${num(2)}</span>${esc(t("co_delivery"))}</h2>
            <label class="f ${S.co.errs.gov ? "invalid" : ""}" for="co_gov">${esc(t("co_gov"))}<select id="co_gov" data-in="co" data-k="gov"><option value="">${esc(t("co_gov_pick"))}</option>
              ${Object.keys(window.LBN_ZONE_NAMES).map((z) => `<optgroup label="${esc(window.LBN_ZONE_NAMES[z][S.lang === "ar" ? 1 : 0])}">${GOVS.filter((g) => g[3] === z).map((g) => `<option value="${g[0]}" ${f.gov === g[0] ? "selected" : ""}>${esc(S.lang === "ar" ? g[2] : g[1])}</option>`).join("")}</optgroup>`).join("")}
            </select>${f.gov ? `<span class="hint">${esc(deliveryHint(f.gov))}</span>` : ""}${S.co.errs.gov ? `<span class="err">${esc(S.co.errs.gov)}</span>` : ""}</label>
            <div class="row2">${field("city", t("co_city"), { ac: "address-level2" })}${field("street", t("co_street"), { ac: "address-line1" })}</div>
            <div class="row3">${field("building", t("co_building"))}${field("floor", t("co_floor"), { opt: true })}${field("apt", t("co_apt"), { opt: true })}</div>
            ${field("landmark", t("co_landmark"), { opt: true })}${field("notes", t("co_notes"), { opt: true, textarea: true })}</section>
          <section class="co-sec"><h2><span class="n">${num(3)}</span>${esc(t("co_gift"))}</h2>
            <label class="check"><input type="checkbox" data-in="cochk" data-k="isGift" ${f.isGift ? "checked" : ""}> ${esc(t("co_is_gift"))}</label>
            ${f.isGift ? `<div class="row2">${field("rname", t("co_rname"))}${field("rphone", t("co_rphone"), { type: "tel" })}</div>${field("gnote", t("co_gnote"), { textarea: true, opt: true, ph: t("co_gnote_ph") })}
              ${st.giftWrapEnabled ? `<label class="check"><input type="checkbox" data-in="cochk" data-k="wrap" ${f.wrap ? "checked" : ""}> ${esc(t("co_wrap"))} <span class="note">+${fmt(st.giftWrapFee)}</span></label>` : ""}
              <label class="check"><input type="checkbox" data-in="cochk" data-k="hidePrice" ${f.hidePrice ? "checked" : ""}> ${esc(t("co_hide_price"))}</label>` : ""}</section>
          <section class="co-sec"><h2><span class="n">${num(4)}</span>${esc(t("co_payment"))}</h2>
            <div class="pays" role="radiogroup">${pays.map(([k, lab]) => `<label class="pay"><input type="radio" name="pay" value="${k}" data-in="copay" ${f.pay === k ? "checked" : ""}><span><b>${esc(t(lab))}</b><small>${esc(t(lab + "_s"))}</small></span></label>`).join("")}</div>
            ${st.staging !== false ? `<p class="note">${esc(t("pay_staging"))}</p>` : ""}</section>
        </div>
        <aside class="co-sum" aria-label="${esc(t("co_summary"))}">
          <h2 style="font-size:1.4rem">${esc(t("co_summary"))}</h2>
          ${S.cart.map((l) => `<div class="line"><div class="th">${lineArt(l)}</div><div><div class="nm" style="font-size:.95rem">${esc(lineName(l))}${l.qty > 1 ? " × " + num(l.qty) : ""}</div>${l.parts.map((pt) => `<div class="sub">${esc(partText(pt))}</div>${pt.custom && pt.custom.text ? `<div class="emb">${embText(pt.custom)}</div>` : ""}`).join("")}</div><div class="price" style="font-size:.88rem">${fmt(l.unit * l.qty)}</div></div>`).join("")}
          <div class="promo"><label class="sr" for="co_promo">${esc(t("co_promo"))}</label><input type="text" id="co_promo" placeholder="${esc(t("co_promo"))}" value="${esc(S.co.promo)}" data-in="promo" style="text-transform:uppercase" dir="ltr"><button type="button" class="btn ghost small" data-act="promo">${esc(t("co_apply"))}</button></div>
          ${S.co.promoMsg ? `<p class="note" style="color:${S.co.promoPct ? "var(--ok)" : "var(--bad)"}">${esc(S.co.promoMsg)}</p>` : ""}
          <div class="ln"><span>${esc(t("cart_sub"))}</span><span>${fmt(q.sub)}</span></div>
          ${q.discount ? `<div class="ln disc"><span>${esc(t("co_discount"))}</span><span>−${fmt(q.discount)}</span></div>` : ""}
          <div class="ln"><span>${esc(t("co_shipping"))}</span><span>${q.ship == null ? esc(t("co_pick_gov")) : q.ship === 0 ? esc(t("co_free")) : fmt(q.ship)}</span></div>
          ${q.wrap ? `<div class="ln"><span>${esc(t("co_wrap_line"))}</span><span>${fmt(q.wrap)}</span></div>` : ""}
          ${q.cod ? `<div class="ln"><span>${esc(t("pay_cod"))}</span><span>${fmt(q.cod)}</span></div>` : ""}
          <div class="tot"><span>${esc(t("co_total"))}</span><span>${fmt(q.total)}</span></div>
          <button type="submit" class="btn block" ${S.co.placing ? "disabled" : ""}>${esc(S.co.placing ? t("co_placing") : t("co_place"))} ${ARROW}</button>
          <p class="note">${esc(t("co_terms"))} <a href="#help-terms">${esc(t("h_terms"))}</a> · <a href="#help-custom">${esc(t("h_custom"))}</a></p>
        </aside>
      </form></div>`;
  }
  function deliveryHint(gov) {
    const g = GOVS.find((x) => x[0] === gov); if (!g) return "";
    const z = (S.settings.zones || {})[g[3]]; if (!z) return "";
    const days = String(z.days || "").replace("-", S.lang === "ar" ? " لـ " : " to ");
    return S.lang === "ar" ? `التوصيل خلال ${days} أيام عمل` : `Delivery in ${days} working days`;
  }
  const egMobile = (v) => /^(\+?20|0)?1[0125]\d{8}$/.test(String(v || "").replace(/[\s-]/g, "").replace(/[٠-٩]/g, (d) => "٠١٢٣٤٥٦٧٨٩".indexOf(d)));
  function validate() {
    const f = S.co.f, e = {};
    const req = ["name", "phone", "email", "gov", "city", "street", "building"];
    if (f.isGift) req.push("rname", "rphone");
    req.forEach((k) => { if (!String(f[k] || "").trim()) e[k] = t("co_required"); });
    if (f.phone && !egMobile(f.phone)) e.phone = t("co_bad_phone");
    if (f.isGift && f.rphone && !egMobile(f.rphone)) e.rphone = t("co_bad_phone");
    if (f.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(f.email)) e.email = t("co_bad_email");
    S.co.errs = e;
    return !Object.keys(e).length;
  }
  function orderNo() {
    const d = new Date();
    return "LBN" + String(d.getFullYear()).slice(2) + String(d.getMonth() + 1).padStart(2, "0") + String(d.getDate()).padStart(2, "0") + "-" + Math.floor(1000 + Math.random() * 9000);
  }
  function snapPart(pt) {
    const p = P(pt.pid) || { name: { en: pt.pid, ar: pt.pid }, colors: [] };
    const c = colorOf(p, pt.color) || { key: pt.color, name: { en: pt.color, ar: pt.color } };
    return { pid: pt.pid, name: p.name, color: { key: c.key, en: c.name.en, ar: c.name.ar }, size: pt.size || "", embroidery: pt.custom && pt.custom.text ? Object.assign({}, pt.custom) : null };
  }
  async function placeOrder() {
    if (!validate()) { S.co.top = t("co_fix"); renderMain(true); const el = $(".invalid"); if (el) el.scrollIntoView({ block: "center" }); return; }
    S.co.top = ""; S.co.placing = true; renderMain(true);
    const f = S.co.f, q = quote(), g = GOVS.find((x) => x[0] === f.gov), no = orderNo();
    const order = {
      orderNo: no, createdAt: new Date().toISOString(), lang: S.lang, status: "new",
      customer: { name: f.name.trim(), phone: f.phone.trim(), email: f.email.trim() },
      address: { governorate: g ? g[1] : f.gov, governorateAr: g ? g[2] : "", zone: g ? g[3] : "", city: f.city || "", street: f.street || "", building: f.building || "", floor: f.floor || "", apartment: f.apt || "", landmark: f.landmark || "", notes: f.notes || "" },
      gift: f.isGift ? { recipientName: f.rname || "", recipientPhone: f.rphone || "", note: f.gnote || "", wrap: !!(S.settings.giftWrapEnabled && f.wrap), hidePrices: !!f.hidePrice } : null,
      payment: { method: f.pay, status: f.pay === "cod" ? "due on delivery" : "pending" },
      items: S.cart.map((l) => ({ kind: l.kind, ref: l.ref, name: l.kind === "set" ? { en: I.en.built_set, ar: I.ar.built_set } : l.kind === "bundle" ? (B(l.ref) || {}).name || { en: l.ref, ar: l.ref } : (P(l.ref) || {}).name || { en: l.ref, ar: l.ref }, qty: l.qty, unit: l.unit, total: l.unit * l.qty, parts: l.parts.map(snapPart) })),
      totals: { subtotal: q.sub, discount: q.discount, promo: S.co.promoPct ? S.co.promo : "", delivery: q.ship || 0, giftWrap: q.wrap, codFee: q.cod, total: q.total },
      utm: lsGet("lbn_utm", null), source: "web"
    };
    let saved = "device", payUrl = "", payHere = false;
    try {
      if (CFG.orderEndpoint && (f.pay === "card" || f.pay === "install")) {
        /* Card and installments: the order inbox saves the order, checks the price
           against the live catalogue and returns Paymob's secure payment page. */
        try {
          const r = await fetch(CFG.orderEndpoint, { method: "POST", headers: { "Content-Type": "text/plain;charset=utf-8" }, body: JSON.stringify({ action: "pay", order }) });
          const j = await r.json();
          if (j && j.total) order.totals.total = j.total;
          if (f.pay === "card" && j && j.publicKey && j.clientSecret) {
            /* Card: Paymob's card form opens inside our own payment page. */
            payStore(no, { pk: j.publicKey, cs: j.clientSecret, at: Date.now() });
            payHere = true; order.payment.status = "awaiting card";
          } else {
            payUrl = (j && j.url) || "";
            order.payment.status = payUrl ? "redirected" : "not paid";
          }
          saved = "endpoint";
        } catch (err) {
          await fetch(CFG.orderEndpoint, { method: "POST", mode: "no-cors", headers: { "Content-Type": "text/plain;charset=utf-8" }, body: JSON.stringify(order) });
          order.payment.status = "not paid";
          saved = "endpoint";
        }
      } else if (CFG.orderEndpoint) {
        await fetch(CFG.orderEndpoint, { method: "POST", mode: "no-cors", headers: { "Content-Type": "text/plain;charset=utf-8" }, body: JSON.stringify(order) });
        saved = "endpoint";
      } else if (S.db && S.uid) {
        const ref = S.db.doc("orders/" + S.uid);
        const snap = await ref.get();
        const body = { list: { [no]: order }, updatedAt: order.createdAt };
        if (snap.exists) await ref.update(body); else await ref.set(body);
        saved = "store";
      }
    } catch (e) { saved = "device"; }
    order.savedTo = saved;
    const mine = lsGet("lbn_orders", []); mine.unshift(order); lsSet("lbn_orders", mine.slice(0, 30));
    track("purchase", { transaction_id: no, value: q.total, currency: "EGP", shipping: q.ship || 0 });
    S.cart = []; saveCart(); renderCart();
    S.co = { promo: "", promoPct: 0, promoMsg: "", f: { pay: "cod" }, errs: {}, placing: false, top: "" };
    S._coTracked = false;
    if (payUrl) { document.body.classList.add("busy"); location.href = payUrl; return; }
    go((payHere ? "pay-" : "order-") + no);
  }
  /* ---------- card payment inside the site (Paymob Pixel) ---------- */
  const PIXEL_SRC = "https://cdn.jsdelivr.net/npm/paymob-pixel@1.2.8/main.js";
  function checkPayReady() {
    if (S._payReq) return; S._payReq = true;
    fetch(CFG.orderEndpoint + "?status=1").then((r) => r.json()).then((j) => { S.payReady = { card: !!(j && j.card), install: !!(j && j.install) }; })
      .catch(() => { S.payReady = { card: false, install: false }; })
      .then(() => { if (S.route.name === "checkout" && !S.co.placing) renderMain(true); });
  }
  function payAll() { const all = lsGet("lbn_pay", {}), now = Date.now(); Object.keys(all).forEach((k) => { if (!all[k] || now - all[k].at > 55 * 60000) delete all[k]; }); return all; }
  function payStore(no, v) { const all = payAll(); if (v) all[no] = v; else delete all[no]; lsSet("lbn_pay", all); }
  function payGet(no) { return payAll()[no] || null; }
  function setPayStatus(no, status) {
    const mine = lsGet("lbn_orders", []), o = mine.find((x) => x.orderNo === no);
    if (o) { o.payment.status = status; lsSet("lbn_orders", mine); }
    return o;
  }
  function vPay(no) {
    const o = lsGet("lbn_orders", []).find((x) => x.orderNo === no), p = payGet(no);
    if (!o || !p || o.payment.status === "paid") return vOrder(no);
    return `<div class="wrap paypage">
      <div class="page-head"><h1>${esc(t("pay_title"))}</h1><p class="lede">${esc(t("pay_sub"))}</p></div>
      <div class="pay-grid">
        <section class="pay-box" aria-label="${esc(t("pay_title"))}">
          <div class="pay-secure">${ICON.lock}<span>${esc(t("pay_secure"))}</span></div>
          <div id="paymobPixel" class="pixel-host"><div class="pixel-wait"><span class="skel"></span><span class="skel"></span><span class="skel short"></span><p class="note">${esc(t("pay_loading"))}</p></div></div>
          <p class="note pay-err" id="payErr" hidden>${esc(t("pay_load_err"))}</p>
          <p class="note">${esc(t("pay_bank_note"))}</p>
        </section>
        <aside class="pay-sum">
          <span class="eyebrow">${esc(t("pay_order"))}</span>
          <b dir="ltr">${esc(no)}</b>
          <div class="tot"><span>${esc(t("co_total"))}</span><span>${fmt(o.totals.total)}</span></div>
          <p class="note">${esc(t("pay_cards"))}</p>
          ${waLink(o) ? `<a class="link" href="${esc(waLink(o))}" target="_blank" rel="noopener">${esc(t("pay_help"))}</a>` : ""}
        </aside>
      </div></div>`;
  }
  function loadPixel() {
    if (window.Pixel) return Promise.resolve();
    if (S._pixelP) return S._pixelP;
    S._pixelP = new Promise((res, rej) => {
      const s = document.createElement("script"); s.type = "module"; s.src = PIXEL_SRC;
      s.onload = () => { let n = 0; const w = () => window.Pixel ? res() : ++n > 60 ? rej(new Error("pixel")) : setTimeout(w, 100); w(); };
      s.onerror = () => { S._pixelP = null; rej(new Error("pixel")); };
      document.head.appendChild(s);
    });
    return S._pixelP;
  }
  function pixelStyle() {
    const ar = S.lang === "ar";
    return {
      Direction: ar ? "rtl" : "ltr",
      Font_Family: ar ? "Alexandria, sans-serif" : "Quicksand, sans-serif",
      Font_Size_Label: "15", Font_Size_Input_Fields: "16", Font_Size_Payment_Button: "15",
      Font_Weight_Label: 500, Font_Weight_Input_Fields: 400, Font_Weight_Payment_Button: 600,
      Color_Container: "#ffffff", Color_Border_Input_Fields: "#e6d3da", Color_Border_Payment_Button: "#6e2135",
      Color_Primary: "#6e2135", Color_Disabled: "#c9b3bb", Color_Error: "#b3261e", Color_Input_Fields: "#ffffff",
      Text_Color_For_Label: "#3a1018", Text_Color_For_Payment_Button: "#ffffff", Text_Color_For_Input_Fields: "#3a1018", Color_For_Text_Placeholder: "#a8939a",
      Radius_Border: "10", Width_of_Container: "100%", Vertical_Padding: "8", Vertical_Spacing_between_components: "12", Container_Padding: "0",
      Label_Text: { cardLabel: t("pix_card") },
      Placeholder_Text: { holderName: t("pix_name"), cardNumber: t("pix_number"), expiryDate: t("pix_expiry"), securityCode: t("pix_cvv") },
      Button_Text: { payBtn: t("pix_pay") }
    };
  }
  function mountPixel(no) {
    const host = $("#paymobPixel"), p = payGet(no); if (!host || !p) return;
    loadPixel().then(() => {
      if (!$("#paymobPixel") || host.dataset.on) return;
      host.dataset.on = "1"; host.innerHTML = "";
      new window.Pixel({
        publicKey: p.pk, clientSecret: p.cs, paymentMethods: ["card"], elementId: "paymobPixel",
        showSaveCard: false, customStyle: pixelStyle(),
        afterPaymentComplete: (res) => finishPay(no, res)
      });
    }).catch(() => { const e = $("#payErr"); if (e) e.hidden = false; const w = $(".pixel-wait"); if (w) w.remove(); });
  }
  function finishPay(no, res) {
    const d = (res && (res.data || res)) || {};
    const ok = String(d.success) === "true" && String(d.pending) !== "true";
    const pending = String(d.pending) === "true";
    const o = setPayStatus(no, ok ? "paid" : pending ? "pending" : "failed");
    if (ok) { payStore(no, null); if (o) track("payment_success", { transaction_id: no, value: o.totals.total, currency: "EGP" }); }
    go("order-" + no);
  }
  function waLink(o) {
    const n = String(S.settings.whatsapp || "").replace(/\D/g, "");
    if (n.length < 10 || /0000000$/.test(n)) return "";
    const lines = [(S.lang === "ar" ? "طلب جديد " : "New order ") + o.orderNo, o.customer.name + " " + o.customer.phone];
    o.items.forEach((it) => it.parts.forEach((pt) => lines.push("- " + (pt.name.en || "") + " " + (pt.color.en || "") + " " + (pt.size || "") + (pt.embroidery ? ' "' + pt.embroidery.text + '"' : ""))));
    lines.push((S.lang === "ar" ? "الإجمالي: " : "Total: ") + fmt(o.totals.total));
    return "https://wa.me/" + n + "?text=" + encodeURIComponent(lines.join("\n"));
  }
  function vOrder(no) {
    const o = lsGet("lbn_orders", []).find((x) => x.orderNo === no);
    if (!o) return `<div class="wrap"><div class="empty" style="margin-block:4rem"><p>${esc(t("ok_missing"))}</p><a class="btn" href="#shop">${esc(t("ok_continue"))}</a></div></div>`;
    return `<div class="wrap"><div class="ok">
      <span class="moonbig">${moon(64, "#6e2135")}</span>
      <h1>${esc(t("ok_title", { name: o.customer.name.split(" ")[0] }))}</h1>
      <p class="lede" style="text-align:center">${esc(t("ok_sub", { no: o.orderNo }))}</p>
      ${o.payment.method === "cod" ? `<p><b>${esc(t("ok_cod", { p: fmt(o.totals.total) }))}</b></p>` : ""}
      ${(o.payment.method === "card" || o.payment.method === "install") ? `<p class="paynote ${o.payment.status === "paid" ? "ok" : o.payment.status === "pending" ? "" : "bad"}"><b>${esc(t(o.payment.status === "paid" ? "ok_paid" : o.payment.status === "pending" ? "ok_pending" : o.payment.status === "failed" ? "ok_failed" : "ok_unpaid", { p: fmt(o.totals.total) }))}</b></p>
        ${o.payment.status !== "paid" && o.payment.status !== "pending" && payGet(no) ? `<a class="btn" href="#pay-${esc(no)}">${esc(t("pay_retry"))} ${ARROW}</a>` : ""}` : ""}
      ${o.savedTo === "device" && S.settings.staging !== false ? `<p class="note">${esc(t("ok_device"))}</p>` : ""}
      ${waLink(o) ? `<a class="btn ghost" href="${esc(waLink(o))}" target="_blank" rel="noopener">${esc(t("ok_wa"))}</a><p class="note">${esc(t("whatsapp"))}: <span dir="ltr">${esc(S.settings.whatsapp)}</span></p>` : ""}
      <div class="card2"><h2 style="font-size:1.3rem">${esc(t("ok_next"))}</h2><ol><li>${esc(t("ok_n1"))}</li><li>${esc(t("ok_n2"))}</li><li>${esc(t("ok_n3"))}</li></ol></div>
      <div class="card2"><h2 style="font-size:1.3rem">${esc(t("co_summary"))}</h2>
        ${o.items.map((it) => `<div style="display:flex;justify-content:space-between;gap:1rem"><span>${esc(L(it.name))}${it.qty > 1 ? " × " + num(it.qty) : ""}<br>${it.parts.map((pt) => `<span class="note">${esc(L(pt.name))} · ${esc(pt.color[S.lang] || pt.color.en)}${pt.size ? " · " + esc(pt.size) : ""}${pt.embroidery ? ` · “${esc(pt.embroidery.text)}”` : ""}</span>`).join("<br>")}</span><span class="price">${fmt(it.total)}</span></div>`).join("")}
        <div style="display:flex;justify-content:space-between;border-top:1px solid var(--line-soft);padding-top:.6rem;font-weight:700"><span>${esc(t("co_total"))}</span><span class="price">${fmt(o.totals.total)}</span></div></div>
      <a class="btn" href="#shop">${esc(t("ok_continue"))} ${ARROW}</a></div></div>`;
  }

  /* ---------- OUR STORY (About Us structure from the guidelines) ---------- */
  function vStory() {
    const st = S.settings;
    return `<div class="wrap">
      <div class="story-hero"><div style="display:grid;gap:1.2rem"><span class="eyebrow">${esc(t("st_eyebrow"))}</span><h1>${esc(t("st_title"))}</h1><p class="open">${esc(t("st_open"))}</p></div>
        <img src="assets/brand-bedroom.jpg" alt=""></div>
      <div class="values wide">${valueIcons()}</div>
      <div class="chapters">${[1, 2, 3, 4, 5, 6].map((n) => `<div class="chapter"><span class="k">${moon(18)}</span><h2>${esc(t("st_h" + n))}</h2><p>${esc(t("st_p" + n))}</p>
        ${n === 4 ? `<div class="palette-row">${["#fad6e1", "#f6e7f1", "#fbf8ef", "#6e2135", "#4f2b1f"].map((c) => `<i style="background:${c}"></i>`).join("")}</div>` : ""}
        ${n === 5 ? `<div class="chips">${COLS.map((c) => `<a class="chip" href="#shop-${c}">${esc(t("col_" + c))}</a>`).join("")}</div>` : ""}
        ${n === 6 ? `<div class="chips"><a class="chip" href="${esc(st.instagram || "#")}" target="_blank" rel="noopener">Instagram</a><a class="chip" href="${esc(st.tiktok || "#")}" target="_blank" rel="noopener">TikTok</a><a class="chip" href="${esc(st.pinterest || "#")}" target="_blank" rel="noopener">Pinterest</a></div>` : ""}
      </div>`).join("")}</div></div>`;
  }

  /* ---------- HELP & POLICIES ---------- */
  function vHelp(k) {
    const keys = ["shipping", "returns", "custom", "payment", "terms", "size", "care", "faq", "contact"];
    if (!keys.includes(k)) k = "faq";
    setMeta(t("h_" + k), t("help_title"));
    let body = "";
    if (k === "faq") body = `<div class="acc">${HELP.faq[S.lang].map(([q, a], i) => `<details ${i === 0 ? "open" : ""}><summary>${esc(q)}</summary><div class="body"><p>${esc(a)}</p></div></details>`).join("")}</div>`;
    else if (HELP[k]) {
      body = HELP[k][S.lang].map(([h, p]) => `<div><h3>${esc(h)}</h3><p>${esc(p)}</p></div>`).join("");
      if (k === "shipping") body += `<div class="tablewrap"><table class="t"><thead><tr><th>${esc(t("co_gov"))}</th><th>${esc(t("co_shipping"))}</th><th>${S.lang === "ar" ? "أيام العمل" : "Working days"}</th></tr></thead><tbody>${Object.keys(window.LBN_ZONE_NAMES).map((z) => { const zz = (S.settings.zones || {})[z] || {}; const d = String(zz.days || "").split("-"); return `<tr><td>${esc(window.LBN_ZONE_NAMES[z][S.lang === "ar" ? 1 : 0])}</td><td>${fmt(zz.fee)}</td><td>${esc(num(d[0] || ""))}–${esc(num(d[1] || ""))}</td></tr>`; }).join("")}</tbody></table></div><p class="note">${esc(L(S.settings.announcement))}</p>`;
    } else if (k === "size") {
      body = `<div class="tablewrap"><table class="t"><thead><tr>${SIZES.head[S.lang].map((h) => `<th>${esc(h)}</th>`).join("")}</tr></thead><tbody>${SIZES.rows.map((r) => `<tr>${r.map((c) => `<td>${esc(S.lang === "ar" ? c.replace(" to ", " – ") : c)}</td>`).join("")}</tr>`).join("")}</tbody></table></div>
        <p>${esc(SIZES.fit[S.lang])}</p>${SIZES.how[S.lang].map(([h, p]) => `<div><h3>${esc(h)}</h3><p>${esc(p)}</p></div>`).join("")}`;
    } else if (k === "contact") {
      body = `<div><h3>${esc(t("whatsapp"))}</h3><div class="contactline"><code>${esc(S.settings.whatsapp)}</code><button class="btn ghost small" data-act="copy" data-v="${esc(S.settings.whatsapp)}">${esc(t("copy"))}</button></div></div>
        <div><h3>${esc(t("email"))}</h3><div class="contactline"><code>${esc(S.settings.email)}</code><button class="btn ghost small" data-act="copy" data-v="${esc(S.settings.email)}">${esc(t("copy"))}</button></div></div>
        <div><h3>${esc(t("h_creators"))}</h3><a class="btn ghost small" href="#creators">${esc(t("cr_title"))} ${ARROW}</a></div>`;
    }
    return `<div class="wrap"><div class="page-head"><span class="eyebrow">${esc(t("help_title"))}</span></div>
      <div class="help"><nav aria-label="${esc(t("help_title"))}">${keys.map((x) => `<a href="#help-${x}" class="${x === k ? "on" : ""}">${esc(t("h_" + x))}</a>`).join("")}<a href="#creators">${esc(t("h_creators"))}</a></nav>
      <article><h2>${esc(t("h_" + k))}</h2>${body}</article></div></div>`;
  }

  /* ---------- UGC & CREATOR COLLABORATIONS ---------- */
  function vCreators() {
    const c = S.cr;
    if (c.done) return `<div class="wrap" style="padding-block:4rem;max-width:760px"><div class="done">${moon(40, "#6e2135")}<p>${esc(t("cr_done"))}</p><a class="btn" href="#home">${esc(t("nav_home"))}</a></div></div>`;
    const fld = (k, lab, type, ac) => `<label class="f ${c.errs[k] ? "invalid" : ""}" for="cr_${k}">${esc(lab)} <span class="hint">${esc(t("required"))}</span><input type="${type}" id="cr_${k}" data-in="cr" data-k="${k}" value="${esc(c[k] || "")}" ${ac ? `autocomplete="${ac}"` : ""} ${type === "tel" ? 'dir="ltr" inputmode="tel"' : ""}>${c.errs[k] ? `<span class="err">${esc(c.errs[k])}</span>` : ""}</label>`;
    const canUpload = !!S.assets;
    return `<div class="wrap" style="padding-top:2rem"><div class="creators">
      <div class="intro-col"><span class="eyebrow">${esc(t("cr_eyebrow"))}</span><h1>${esc(t("cr_title"))}</h1><p class="lede">${esc(t("cr_sub"))}</p>
        <div class="ugc" style="grid-template-columns:repeat(2,minmax(0,1fr))"><div class="u"><img src="assets/brand-bedroom.jpg" alt=""></div><div class="u"><img src="assets/brand-crescents.jpg" alt=""></div></div></div>
      <form id="crForm" novalidate>
        ${fld("name", t("cr_name"), "text", "name")}
        <div class="row2">${fld("phone", t("cr_phone"), "tel", "tel")}${fld("email", t("cr_email"), "email", "email")}</div>
        <div class="f ${c.errs.links ? "invalid" : ""}"><span>${esc(t("cr_links"))} <span class="hint">${esc(t("required"))}</span></span><span class="hint">${esc(t("cr_links_help"))}</span>
          ${c.links.map((l, i) => `<div class="linkrow"><input type="url" id="cr_link${i}" data-in="crlink" data-i="${i}" value="${esc(l)}" placeholder="https://instagram.com/..." dir="ltr" aria-label="${esc(t("cr_links"))} ${i + 1}">${c.links.length > 1 ? `<button type="button" class="iconbtn" data-act="crrm" data-i="${i}" aria-label="${esc(t("cart_remove"))}">${ICON.close}</button>` : "<span></span>"}</div>`).join("")}
          <button type="button" class="link" data-act="cradd" style="justify-self:start">+ ${esc(t("cr_add_link"))}</button>${c.errs.links ? `<span class="err">${esc(c.errs.links)}</span>` : ""}</div>
        <div class="f"><span>${esc(t("cr_type"))} <span class="hint">${esc(t("optional"))}</span></span><div class="chips">${["ugc", "inf", "photo", "other"].map((k) => `<button type="button" class="chip ${c.type === k ? "on" : ""}" data-act="crtype" data-v="${k}">${esc(t("cr_" + k))}</button>`).join("")}</div></div>
        <label class="f" for="cr_about">${esc(t("cr_about"))} <span class="hint">${esc(t("optional"))}</span><textarea id="cr_about" data-in="cr" data-k="about">${esc(c.about || "")}</textarea><span class="hint">${esc(t("cr_about_help"))}</span></label>
        ${canUpload ? `<label class="f" for="cr_file">${esc(t("cr_upload"))} <span class="hint">${esc(t("optional"))}</span><input type="file" id="cr_file" accept="image/*,video/*,application/pdf"><span class="hint">${c.uploading ? "…" : c.upload ? esc(t("cr_uploaded")) + ": " + esc(c.upload.name) : esc(t("cr_upload_help"))}</span></label>`
          : `<label class="f" for="cr_portfolio">${esc(t("cr_upload_link"))} <span class="hint">${esc(t("optional"))}</span><input type="url" id="cr_portfolio" data-in="cr" data-k="portfolio" value="${esc(c.portfolio || "")}" dir="ltr"><span class="hint">${esc(t("cr_upload_link_help"))}</span></label>`}
        <button class="btn" type="submit" ${c.uploading ? "disabled" : ""}>${esc(t("cr_send"))} ${ARROW}</button>
      </form></div></div>`;
  }
  async function sendCreator() {
    const c = S.cr, e = {};
    ["name", "phone", "email"].forEach((k) => { if (!String(c[k] || "").trim()) e[k] = t("co_required"); });
    if (c.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(c.email)) e.email = t("co_bad_email");
    const links = c.links.map((x) => x.trim()).filter(Boolean);
    if (!links.length) e.links = t("co_required");
    c.errs = e;
    if (Object.keys(e).length) { renderMain(true); return; }
    const app = { id: "a" + Date.now().toString(36), name: c.name.trim(), phone: c.phone.trim(), email: c.email.trim(), links, type: c.type || "", about: c.about || "", portfolio: c.portfolio || "", upload: c.upload || null, lang: S.lang, at: new Date().toISOString() };
    try {
      if (CFG.creatorEndpoint) await fetch(CFG.creatorEndpoint, { method: "POST", mode: "no-cors", headers: { "Content-Type": "text/plain;charset=utf-8" }, body: JSON.stringify(app) });
      else if (S.db && S.uid) {
        const ref = S.db.doc("creators/" + S.uid); const snap = await ref.get();
        const body = { apps: { [app.id]: app } };
        if (snap.exists) await ref.update(body); else await ref.set(body);
      } else { const l = lsGet("lbn_creators", []); l.push(app); lsSet("lbn_creators", l); }
    } catch (err) { const l = lsGet("lbn_creators", []); l.push(app); lsSet("lbn_creators", l); }
    track("generate_lead", { form: "creator" });
    S.cr = Object.assign(freshCr(), { done: true });
    renderMain(); window.scrollTo(0, 0);
  }
  async function subscribe(email) {
    const msg = $("#newsMsg");
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { msg.textContent = t("news_bad"); return; }
    try {
      if (CFG.newsletterEndpoint) await fetch(CFG.newsletterEndpoint, { method: "POST", mode: "no-cors", headers: { "Content-Type": "text/plain;charset=utf-8" }, body: JSON.stringify({ email, lang: S.lang }) });
      else if (S.db && S.uid) await S.db.doc("subscribers/" + S.uid).set({ email, lang: S.lang, at: new Date().toISOString() });
      else { const l = lsGet("lbn_subs", []); l.push({ email, lang: S.lang, at: new Date().toISOString() }); lsSet("lbn_subs", l); }
    } catch (e) {}
    track("sign_up", { method: "newsletter" });
    msg.textContent = t("news_done"); $("#newsEmail").value = "";
  }

  /* ---------- search (collection, colour, product type) ---------- */
  function openSearch() {
    openModal(t("search"), `<div class="searchbox"><input type="search" id="sq" placeholder="${esc(t("search_ph"))}" data-in="search" autocomplete="off"><div class="sresults" id="sres"></div></div>`);
    searchResults("");
  }
  function searchResults(q) {
    const box = $("#sres"); if (!box) return;
    q = q.trim().toLowerCase();
    const list = !q ? S.products.filter((p) => p.featured).slice(0, 6) : S.products.filter((p) => searchText(p).includes(q)).slice(0, 8);
    box.innerHTML = list.length ? list.map((p) => `<a class="sres" href="#p-${esc(p.id)}" data-act="close-nav">${p.image ? `<img src="${esc(p.image.replace(/\.jpg$/, "-thumb.jpg"))}" alt="">` : Art.draw(p)}<span><b style="font-weight:600">${esc(L(p.name))}</b><br><span class="note">${esc((p.collections || []).map((c) => t("col_" + c)).join(", "))}</span></span><span class="price">${fmt(p.price)}</span></a>`).join("") + (q ? `<button class="btn ghost small" data-act="searchall" style="justify-self:start">${esc(t("see_all"))} ${ARROW}</button>` : "")
      : `<p class="note">${esc(t("search_none"))}</p>`;
  }

  /* ---------- intro door ---------- */
  function playDoor() {
    if (!S.soundOn) return;
    try {
      const ac = new (window.AudioContext || window.webkitAudioContext)(), t0 = ac.currentTime;
      const o = ac.createOscillator(), g = ac.createGain(), f = ac.createBiquadFilter();
      o.type = "sawtooth"; o.frequency.setValueAtTime(80, t0); o.frequency.linearRampToValueAtTime(130, t0 + .8); o.frequency.linearRampToValueAtTime(70, t0 + 1.3);
      f.type = "bandpass"; f.frequency.value = 700; f.Q.value = 5;
      g.gain.setValueAtTime(.0001, t0); g.gain.exponentialRampToValueAtTime(.05, t0 + .2); g.gain.exponentialRampToValueAtTime(.0001, t0 + 1.4);
      o.connect(f); f.connect(g); g.connect(ac.destination); o.start(t0); o.stop(t0 + 1.5);
      [1318.5, 1760].forEach((fr, i) => { const c = ac.createOscillator(), cg = ac.createGain(); c.type = "sine"; c.frequency.value = fr; cg.gain.setValueAtTime(.0001, t0 + 1 + i * .12); cg.gain.exponentialRampToValueAtTime(.04, t0 + 1.05 + i * .12); cg.gain.exponentialRampToValueAtTime(.0001, t0 + 2.4); c.connect(cg); cg.connect(ac.destination); c.start(t0 + 1 + i * .12); c.stop(t0 + 2.5); });
    } catch (e) {}
  }
  function bindIntro() {
    const el = $("#intro"); if (!el) return;
    if (el.hidden) { el.remove(); return; }
    const glimpse = $("#introGlimpse"); const hp = heroItems()[0];
    if (glimpse && hp) glimpse.innerHTML = hp.image ? `<img class="glimpse-photo" src="${hp.image}" alt="">` : Art.draw(hp, { rack: true });
    let done = false;
    const finish = (fast) => {
      if (done) return; done = true;
      try { sessionStorage.setItem("lbn_intro", "1"); } catch (e) {}
      if (fast) { el.classList.add("gone"); setTimeout(() => el.remove(), 900); return; }
      el.classList.add("open"); playDoor();
      const reduce = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
      setTimeout(() => { el.classList.add("gone"); setTimeout(() => el.remove(), 1200); $("#main").focus({ preventScroll: true }); }, reduce ? 100 : 2100);
    };
    $("#introOpen").addEventListener("click", (e) => { e.stopPropagation(); finish(false); });
    $(".door-frame").addEventListener("click", () => finish(false));
    $("#introSkip").addEventListener("click", () => finish(true));
    $("#introSound").addEventListener("click", (e) => { S.soundOn = !S.soundOn; e.currentTarget.textContent = S.soundOn ? t("sound_on") : t("sound_off"); e.currentTarget.setAttribute("aria-pressed", String(S.soundOn)); });
    $("#introOpen").focus();
  }

  /* ---------- actions ---------- */
  const resetMixEmbPlacement = () => {
    const top = P(S.mix.top), bot = P(S.mix.bottom);
    if (top && !Art.placementsFor(top).includes(S.mix.cTop.placement)) S.mix.cTop.placement = Art.placementsFor(top)[0];
    if (bot && !Art.placementsFor(bot).includes(S.mix.cBot.placement)) S.mix.cBot.placement = Art.placementsFor(bot)[0];
  };
  const scrollToId = (id) => { const el = document.getElementById(id); if (el) el.scrollIntoView({ behavior: "smooth", block: "start" }); };
  const ACT = {
    menu: () => openDrawer("menu"),
    cart: () => { renderCart(); openDrawer("cart"); },
    close: () => closeAll(),
    "close-nav": () => closeAll(),
    search: () => openSearch(),
    searchall: () => { S.shop.q = ($("#sq") || {}).value || ""; closeAll(); go("shop-all"); },
    lang: () => { S.lang = S.lang === "en" ? "ar" : "en"; lsSet("lbn_lang", S.lang); applyLang(); renderChrome(); renderMain(true); },
    hero: (el) => heroStep(Number(el.dataset.d)),
    heroto: (el) => heroStep(0, Number(el.dataset.i)),
    tryicon: (el) => { S.homeTry.icon = S.homeTry.icon === el.dataset.v ? "" : el.dataset.v; renderMain(true); },
    mixtab: (el) => { S.mixTab = el.dataset.v; renderMain(true); },
    tosteps: (el, e) => { e.preventDefault(); scrollToId("mx-steps"); },
    toanchor: (el, e) => { e.preventDefault(); scrollToId(el.dataset.v); },
    togrid: (el, e) => { e.preventDefault(); scrollToId("grid"); },
    q: (el) => { const l = S.cart.find((x) => x.lid === el.dataset.l); if (!l) return; l.qty += Number(el.dataset.d); if (l.qty < 1) S.cart = S.cart.filter((x) => x !== l); saveCart(); renderCart(); if (S.route.name === "checkout") renderMain(true); },
    rm: (el) => { S.cart = S.cart.filter((x) => x.lid !== el.dataset.l); saveCart(); renderCart(); if (S.route.name === "checkout") renderMain(true); },
    f: (el) => { const a = S.shop[el.dataset.g], v = el.dataset.v, i = a.indexOf(v); if (i >= 0) a.splice(i, 1); else a.push(v); renderMain(true); },
    fp: (el) => { S.shop.price = S.shop.price === el.dataset.v ? "" : el.dataset.v; renderMain(true); },
    fclear: () => { Object.assign(S.shop, { type: [], size: [], color: [], price: "", custom: false, stock: false, q: "" }); renderMain(true); },
    fshow: () => { S.shop.show = !S.shop.show; renderMain(true); },
    fq: () => { S.shop.q = ""; renderMain(true); },
    pcolor: (el) => { S.pdp.color = el.dataset.v; renderMain(true); },
    psize: (el) => { S.pdp.size = el.dataset.v; S.pdp.err = ""; renderMain(true); },
    pview: (el) => { S.pdp.view = el.dataset.v; renderMain(true); },
    pqty: (el) => { S.pdp.qty = Math.max(1, S.pdp.qty + Number(el.dataset.d)); renderMain(true); },
    ptoggle: () => { S.pdp.c.on = !S.pdp.c.on; renderMain(true); },
    padd: () => {
      const p = P(S.pdp.id), s = S.pdp; if (!p) return;
      if (!s.size) { s.err = t("choose_size"); renderMain(true); return; }
      if (s.c.on && !validText(s.c.text)) { s.err = t("c_text_need"); renderMain(true); return; }
      s.err = "";
      const custom = s.c.on ? embOf(s.c) : null;
      addLine({ kind: "product", ref: p.id, qty: s.qty, unit: p.price + (custom ? fee() : 0), parts: [{ pid: p.id, color: s.color, size: s.size, custom }] });
      toast(t("added")); renderMain(true);
    },
    emb: (el) => {
      const st = embState(el.dataset.scope); if (!st) return;
      st[el.dataset.k] = el.dataset.v;
      if (el.dataset.scope === "pdp") S.pdp.c.on = true;
      renderMain(true);
    },
    czp: (el) => { S.cz.pid = el.dataset.v; S.cz.color = null; S.cz.err = ""; renderMain(true); },
    czc: (el) => { S.cz.color = el.dataset.v; renderMain(true); },
    czs: (el) => { S.cz.size = el.dataset.v; S.cz.err = ""; renderMain(true); },
    czadd: () => {
      const z = S.cz, p = P(z.pid); if (!p) return;
      if (!z.size) { z.err = t("choose_size"); renderMain(true); return; }
      if (!validText(z.text)) { z.err = t("c_text_need"); renderMain(true); const ti = $("#czText"); if (ti) ti.focus(); return; }
      z.err = "";
      addLine({ kind: "product", ref: p.id, qty: 1, unit: p.price + fee(), parts: [{ pid: p.id, color: z.color, size: z.size, custom: embOf(Object.assign({ on: true }, z)) }] });
      toast(t("added"));
    },
    mxpick: (el) => {
      const p = P(el.dataset.v); if (!p) return;
      if (el.dataset.w === "top") { S.mix.top = p.id; S.mix.topColor = p.colors[0].key; S.mix.topSize = ""; }
      else { S.mix.bottom = p.id; S.mix.bottomColor = p.colors[0].key; S.mix.bottomSize = ""; }
      resetMixEmbPlacement(); S.mix.err = ""; renderMain(true);
    },
    mxcol: (el) => {
      const p = P(el.dataset.p); if (!p) return;
      if (el.dataset.w === "top") { if (S.mix.top !== p.id) { S.mix.top = p.id; S.mix.topSize = ""; } S.mix.topColor = el.dataset.v; }
      else { if (S.mix.bottom !== p.id) { S.mix.bottom = p.id; S.mix.bottomSize = ""; } S.mix.bottomColor = el.dataset.v; }
      resetMixEmbPlacement(); renderMain(true);
    },
    mxadd: (el) => { const id = el.dataset.p, p = P(id); if (S.mix.addons[id]) delete S.mix.addons[id]; else S.mix.addons[id] = { color: p.colors[0].key, size: p.sizes[0] }; renderMain(true); },
    mxbag: () => {
      const m = S.mix, top = P(m.top), bot = P(m.bottom);
      if (!top || !bot) { m.err = t("m_need"); renderMain(true); return; }
      if (!m.topSize || !m.bottomSize) { m.err = t("m_need_size"); renderMain(true); return; }
      if ((m.cTop.on && !validText(m.cTop.text)) || (m.cBot.on && !validText(m.cBot.text))) { m.err = t("c_text_need"); renderMain(true); return; }
      const q = mixQuote();
      const parts = [{ pid: top.id, color: m.topColor, size: m.topSize, custom: m.cTop.on ? embOf(m.cTop) : null }, { pid: bot.id, color: m.bottomColor, size: m.bottomSize, custom: m.cBot.on ? embOf(m.cBot) : null }];
      Object.keys(m.addons).forEach((id) => parts.push({ pid: id, color: m.addons[id].color, size: m.addons[id].size, custom: null }));
      addLine({ kind: "set", ref: "mix", qty: 1, unit: q.total, parts });
      S.mix = freshMix();
      toast(t("added")); renderMain(true);
    },
    bcol: (el) => { bState(B(el.dataset.b))[el.dataset.i].color = el.dataset.v; renderMain(true); },
    bsize: (el) => { bState(B(el.dataset.b))[el.dataset.i].size = el.dataset.v; S.bErr = ""; renderMain(true); },
    badd: (el) => {
      const b = B(el.dataset.b), sel = bState(b);
      if (sel.some((x) => !x.size)) { S.bErr = t("m_need_size"); renderMain(true); return; }
      S.bErr = "";
      const parts = sel.map((x) => ({ pid: x.pid, color: x.color, size: x.size, custom: validText(x.text) ? embOf(Object.assign({}, x, { on: true })) : null }));
      addLine({ kind: "bundle", ref: b.id, qty: 1, unit: b.price + parts.filter((x) => x.custom).length * fee(), parts });
      delete S.bsel[b.id];
      toast(t("added")); renderMain(true);
    },
    promo: () => {
      const code = String(S.co.promo || "").trim().toUpperCase(), pr = (S.settings.promos || {})[code];
      if (pr) { S.co.promoPct = Number(pr.pct) || 0; S.co.promo = code; S.co.promoMsg = t("co_promo_ok", { code, pct: num(S.co.promoPct) }); }
      else { S.co.promoPct = 0; S.co.promoMsg = t("co_promo_bad"); }
      renderMain(true);
    },
    copy: (el) => copyText(el.dataset.v, el),
    cradd: () => { S.cr.links.push(""); renderMain(true); const last = $("#cr_link" + (S.cr.links.length - 1)); if (last) last.focus(); },
    crrm: (el) => { S.cr.links.splice(Number(el.dataset.i), 1); renderMain(true); },
    crtype: (el) => { S.cr.type = S.cr.type === el.dataset.v ? "" : el.dataset.v; renderMain(true); }
  };
  document.addEventListener("click", (e) => {
    const el = e.target.closest("[data-act]"); if (!el) return;
    const fn = ACT[el.dataset.act]; if (!fn) return;
    if (el.tagName === "BUTTON") e.preventDefault();
    fn(el, e);
  });
  $("#scrim").addEventListener("click", () => closeAll());
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") closeAll();
    if (S.route.name === "home" && (e.key === "ArrowLeft" || e.key === "ArrowRight") && document.activeElement && document.activeElement.closest && document.activeElement.closest("#alcove")) {
      heroStep((e.key === "ArrowRight" ? 1 : -1) * (S.lang === "ar" ? -1 : 1));
    }
  });

  const INPUT = {
    try: (el) => {
      S.homeTry.text = el.value;
      if (window.LBNUI) window.LBNUI.onTry();
      const p = P("classic-top"), tb = $("#tryBig"); if (!p || !tb) return;
      tb.innerHTML = Art.draw(p, { color: "pink", custom: { text: el.value, font: "serif", thread: "burgundy", placement: "pocket", icon: S.homeTry.icon }, zoom: true });
    },
    embtext: (el) => {
      const sc = el.dataset.scope, st = embState(sc); if (!st) return;
      st.text = el.value;
      if (sc === "cz") { refreshCzPreview(); syncCzMono(st); return; }
      if (sc === "pdp") {
        const p = P(S.pdp.id), m = $("#pdpMain");
        if (m && p) m.innerHTML = Art.draw(p, { color: S.pdp.color, custom: st.text ? st : null, zoom: S.pdp.view === "detail" && !!st.text });
        const pr = $("#pdpPrice"); if (pr && p) pr.textContent = fmt(p.price + (st.text ? fee() : 0));
        if (window.LBNUI) window.LBNUI.onEmb("pdp");
      }
      if (sc === "mixtop" || sc === "mixbot") S.pendingRender = true;
    },
    embnote: (el) => { const st = embState(el.dataset.scope); if (st) st.note = el.value; },
    fcustom: (el) => { S.shop.custom = el.checked; renderMain(true); },
    fstock: (el) => { S.shop.stock = el.checked; renderMain(true); },
    sort: (el) => { S.shop.sort = el.value; renderMain(true); },
    mxsize: (el) => { if (el.dataset.w === "top") S.mix.topSize = el.value; else S.mix.bottomSize = el.value; S.mix.err = ""; renderMain(true); },
    mxasize: (el) => { const a = S.mix.addons[el.dataset.p]; if (a) a.size = el.value; renderMain(true); },
    mxon: (el) => { const st = embState(el.dataset.scope); if (st) st.on = el.checked; resetMixEmbPlacement(); renderMain(true); },
    btext: (el) => { bState(B(el.dataset.b))[el.dataset.i].text = el.value; S.pendingRender = true; },
    bnote: (el) => { bState(B(el.dataset.b))[el.dataset.i].note = el.value; },
    bopt: (el) => { bState(B(el.dataset.b))[el.dataset.i][el.dataset.k] = el.value; renderMain(true); },
    co: (el) => { S.co.f[el.dataset.k] = el.value; if (S.co.errs[el.dataset.k]) delete S.co.errs[el.dataset.k]; if (el.dataset.k === "gov") renderMain(true); },
    cochk: (el) => { S.co.f[el.dataset.k] = el.checked; renderMain(true); },
    copay: (el) => { S.co.f.pay = el.value; renderMain(true); },
    promo: (el) => { S.co.promo = el.value; },
    search: (el) => searchResults(el.value),
    cr: (el) => { S.cr[el.dataset.k] = el.value; },
    crlink: (el) => { S.cr.links[Number(el.dataset.i)] = el.value; }
  };
  const onInput = (e) => {
    const el = e.target.closest && e.target.closest("[data-in]"); if (!el) return;
    const k = el.dataset.in;
    const textLike = el.tagName === "TEXTAREA" || (el.tagName === "INPUT" && !["checkbox", "radio"].includes(el.type));
    if (e.type === "change" && textLike) return;
    if (e.type === "input" && !textLike) return;
    const fn = INPUT[k]; if (fn) fn(el, e);
  };
  document.addEventListener("input", onInput);
  document.addEventListener("change", onInput);
  document.addEventListener("change", async (e) => {
    if (e.target && e.target.id === "cr_file" && e.target.files && e.target.files[0] && S.assets) {
      const file = e.target.files[0];
      S.cr.uploading = true; renderMain(true);
      try { const r = await S.assets.upload(file); S.cr.upload = { id: r.id, url: r.url, name: file.name }; }
      catch (err) { S.cr.upload = null; toast((err && err.message) || "Upload failed"); }
      S.cr.uploading = false; renderMain(true);
    }
  });
  document.addEventListener("submit", (e) => {
    if (e.target.id === "coForm") { e.preventDefault(); placeOrder(); }
    if (e.target.id === "crForm") { e.preventDefault(); sendCreator(); }
    if (e.target.id === "newsform") { e.preventDefault(); subscribe(($("#newsEmail") || {}).value || ""); }
  });
  window.addEventListener("hashchange", route);

  /* ---------- boot ---------- */
  function captureUtm() {
    try {
      const p = new URLSearchParams(location.search), u = {};
      ["utm_source", "utm_medium", "utm_campaign", "utm_content", "utm_term", "fbclid", "ttclid", "gclid"].forEach((k) => { if (p.get(k)) u[k] = p.get(k); });
      if (Object.keys(u).length) lsSet("lbn_utm", Object.assign({ landed: new Date().toISOString() }, u));
    } catch (e) {}
  }
  /* Back from Paymob: show the result on the order page. The Sheet is updated
     separately by Paymob's signed notification, which is the record to trust. */
  function handlePaymentReturn() {
    try {
      const q = new URLSearchParams(location.search);
      const no = q.get("paid");
      if (!no) return;
      const ok = q.get("success") === "true" && q.get("pending") !== "true";
      const mine = lsGet("lbn_orders", []);
      const o = mine.find((x) => x.orderNo === no);
      if (o) { o.payment.status = ok ? "paid" : q.get("pending") === "true" ? "pending" : "failed"; lsSet("lbn_orders", mine); }
      if (ok) { const all = lsGet("lbn_pay", {}); delete all[no]; lsSet("lbn_pay", all); }
      if (ok && o) track("payment_success", { transaction_id: no, value: o.totals.total, currency: "EGP" });
      try { sessionStorage.setItem("lbn_intro", "1"); } catch (e) {}
      const intro = document.getElementById("intro"); if (intro) intro.hidden = true;
      history.replaceState(null, "", location.pathname + "#order-" + no);
    } catch (e) {}
  }
  function boot() {
    S.lang = lsGet("lbn_lang", null) || (/^ar/i.test(navigator.language || "") ? "ar" : "en");
    S.cart = lsGet("lbn_cart", []);
    handlePaymentReturn();
    S.route = parse();
    if (S.route.name === "customize" && S.route.arg) S.cz.pid = S.route.arg;
    applyLang(); captureUtm(); renderChrome(); renderMain(); bindIntro();
    loadFile().then(() => { if (S.route.name === "p") resetPdp(S.route.arg); renderMain(); const g = $("#introGlimpse"); const hp = heroItems()[0]; if (g && hp && !g.innerHTML) g.innerHTML = hp.image ? `<img class="glimpse-photo" src="${hp.image}" alt="">` : Art.draw(hp, { rack: true }); });
    initClaude();
  }

  window.LBN = { S, t, L, fmt, num, esc, Art, P, B, ACT, INPUT, renderMain, renderChrome, openModal, closeModal, toast, copyText, colorOf, lsGet, lsSet, GOVS, I, ICON, moon, card,
    /* shared with studio.js so it uses the same bag, sound and analytics */
    addLine, fee, track, playDoor, openDrawer, closeAll, renderCart,
    /* used by the page views in studio.js, which render every page with the same controls */
    setMeta, productLd, resetPdp, canEmb, embControls, embText, FONT_KEYS, THREAD_KEYS, ICON_KEYS, glyph, mixQuote,
    bWorth, bState, bDefs, bundleSoldOut, validText, vCollection, SIZES, go };
  boot();
})();
