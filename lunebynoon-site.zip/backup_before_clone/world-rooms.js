/* LuneByNoon — the 3D world, rooms.
   hall     the panelled facade with the signature double door, the vestibule and the
            round boutique whose alcoves hold the collection (Shop Collections, products)
   atelier  the embroidery atelier (Customize Your Pyjamas)
   mix      the mix studio with two clothes lines (Mix & Match)
   gifts    the gift salon with ribboned boxes on pedestals (Bundles)
   gallery  the story corridor (Our Story)
   lounge   the folded-pyjama lounge (collections, help, checkout)
   Every room is built on first visit and only the current room is drawn. */
(function () {
  "use strict";
  const W3 = window.LBNW;
  if (!W3) return;

  /* ---------------------------------------------------------- shared kit */
  function kit(c) {
    const { V, M4, G, PROF, D2R, lin } = c;
    const SILL = 0.95;
    /* a wall from local x=0..len, y=0..h, facing local +z, placed by matrix m */
    function wall(room, m, len, h, o) {
      o = o || {};
      const add = (g, mat, extra) => c.add(room, g, mat, extra ? M4.mul(m, extra) : m);
      const sill = o.sill == null ? SILL : o.sill;
      add(G.rect(0, 0, len, sill, 0, 1), o.lower || c.M.plasterIn);
      add(G.rect(0, sill, len, h, 0, 1), o.upper || c.M.wallpaper);
      add(G.box(len, 0.14, 0.022), c.M.moulding, M4.trans(len / 2, 0.07, 0.011));
      add(G.sweep([[0, sill], [len, sill]], false, PROF.rail, -1), c.M.moulding);
      if (o.cornice !== false) add(G.sweep([[-0.06, h - 0.26], [len + 0.06, h - 0.26]], false, PROF.cornice, -1), c.M.moulding);
      if (o.panels !== false) {
        const n = Math.max(1, Math.round(len / 1.9)), pw = len / n;
        for (let k = 0; k < n; k++) {
          const pts = c.roundRect(pw - 0.34, sill - 0.42, 0.01, 2).map(([x, y]) => [x + pw * (k + 0.5), y + sill / 2 + 0.03]);
          add(G.sweep(pts, true, PROF.panel, 1), c.M.moulding);
        }
      }
      add(aoStrip(len, 0.5), c.M.ao(0.32), M4.chain(M4.trans(len / 2, 0.004, 0), M4.rotX(Math.PI / 2)));
    }
    function aoStrip(w, d) { const g = new c.Geo(); g.add(G.card(w, d), M4.trans(0, d / 2, 0)); return g; }
    /* a flat floor or ceiling rectangle over world x0..x1, z0..z1 at height y */
    function flat(room, x0, z0, x1, z1, y, mat, down) {
      const g = G.rect(x0, -z1, x1, -z0, 0, 1);
      return c.add(room, g, mat, M4.chain(M4.trans(0, y, 0), M4.rotX(-Math.PI / 2)), down ? { ceiling: true } : null);
    }
    /* a closed box room: back wall at z=z0, side walls, optional front wall */
    function shell(room, o) {
      const { x0, x1, z0, z1, h } = o;
      wall(room, M4.basis([x0, 0, z0], [1, 0, 0], [0, 1, 0], [0, 0, 1]), x1 - x0, h, o.back || {});
      wall(room, M4.basis([x0, 0, z1], [0, 0, -1], [0, 1, 0], [1, 0, 0]), z1 - z0, h, o.left || {});
      wall(room, M4.basis([x1, 0, z0], [0, 0, 1], [0, 1, 0], [-1, 0, 0]), z1 - z0, h, o.right || {});
      if (o.front) wall(room, M4.basis([x1, 0, z1], [-1, 0, 0], [0, 1, 0], [0, 0, -1]), x1 - x0, h, o.front);
      flat(room, x0, z0, x1, z1, 0, o.floor || c.M.marble);
      flat(room, x0, z0, x1, z1, h, c.M.ceiling, true);
      /* corner pilasters */
      [[x0, z0], [x1, z0]].forEach(([x, z], i) => {
        const pm = M4.trans(x + (i ? -0.13 : 0.13), 0, z + 0.06);
        c.add(room, G.box(0.26, h - 0.2, 0.12), c.M.moulding, M4.mul(pm, M4.trans(0, (h - 0.2) / 2, 0)));
      });
    }
    function frame(room, m, w, h, mat) { return c.add(room, G.sweep(c.roundRect(w, h, 0.006, 2), true, PROF.frame, 1), mat || c.M.gold, m); }
    function pictureLight(room, m, w) {
      c.add(room, G.box(w || 0.36, 0.035, 0.035), c.M.gold, M4.mul(m, M4.trans(0, 0, 0.12)));
      c.add(room, G.cyl(0.006, 0.12, 8, true), c.M.gold, M4.mul(m, M4.chain(M4.trans(0, -0.02, 0.06), M4.rotX(Math.PI / 2))));
    }
    /* a canvas texture plate: mount, frame, soft shadow */
    function plate(room, m, w, h, o) {
      o = o || {};
      const mat = c.MAT({ map: c.T.mat, rough: 0.75, env: 0.08, emis: o.emis || [0.06, 0.055, 0.05], emisMap: 1, color: o.color || [0.8, 0.78, 0.78] });
      const it = c.add(room, G.card(w - 0.004, h - 0.004, 0.004), mat, m);
      if (o.frame !== false) frame(room, m, w, h);
      if (o.shadow !== false) c.add(room, G.card(w + 0.34, h + 0.32), c.M.shadow(o.shadowO || 0.26), M4.mul(m, M4.trans(0.02, -0.05, -0.006)));
      return it;
    }
    function window_(room, m, w, h) { // tall arched window panel on a wall
      const spr = h - w / 2;
      const ap = c.archPath(w, spr, 36, 0);
      c.add(room, G.fan(ap, 0.006, (x, y) => [(x + w / 2) / w, y / h]), c.M.window, m);
      c.add(room, G.sweep(ap, false, PROF.casing.map(([o, z]) => [o * 0.7, z * 0.8]), -1), c.M.moulding, m);
      c.add(room, G.box(0.03, h - 0.1, 0.03), c.M.moulding, M4.mul(m, M4.trans(0, (h - 0.1) / 2, 0.02)));
      [0.35, 0.62].forEach((f) => c.add(room, G.box(w, 0.03, 0.03), c.M.moulding, M4.mul(m, M4.trans(0, spr * f + 0.2, 0.02))));
      c.add(room, G.box(w + 0.16, 0.05, 0.14), c.M.moulding, M4.mul(m, M4.trans(0, -0.02, 0.07)));
    }
    function compose(pos, tgt, fov, amt) {
      amt = amt == null ? 1 : amt;
      const st = c.st, f = V.norm(V.sub(tgt, pos)), r = V.norm(V.cross(f, [0, 1, 0])), u = V.cross(r, f);
      // portrait screens: open up close shots so the subject keeps its width on screen
      if (c.cam.aspect < 0.9 && fov < 48) fov = Math.min(62, 2 * Math.atan(Math.tan(fov * D2R / 2) * Math.pow(0.9 / c.cam.aspect, 0.5)) / D2R);
      const dist = V.len(V.sub(tgt, pos)), th = Math.tan(fov * D2R / 2);
      let off = [0, 0, 0];
      if (st.layout === "side") off = V.mul(r, dist * th * c.cam.aspect * 0.3 * amt * (document.documentElement.dir === "rtl" ? -1 : 1));
      else if (st.layout === "bottom") off = V.mul(u, -dist * th * 0.45 * amt);
      const par = c.st.reduce ? [0, 0] : c.st.pointerS;
      const pp = V.add(V.mul(r, par[0] * 0.06 * Math.min(dist, 3)), V.mul(u, par[1] * 0.03 * Math.min(dist, 3)));
      return { pos: V.add(V.add(pos, off), pp), tgt: V.add(tgt, off), fov };
    }
    function env(o) {
      return Object.assign({ sky: [0.34, 0.26, 0.25], gnd: [0.13, 0.09, 0.09], keyDir: V.norm([0.5, -0.7, -0.62]), keyCol: [0.12, 0.1, 0.08], expo: 1.0 }, o || {});
    }
    /* product art plate canvas (cream mount with the piece, cropped to fill) */
    const plateCache = new Map();
    async function plateCanvas(item, W, H) {
      W = W || (c.lite ? 768 : 1024); H = H || Math.round(W * 4 / 3);
      const cv = c.cnv(W, H), x = cv.getContext("2d"), s = W / 768;
      const tint = item.tint || "#f4cdd8";
      x.drawImage(c.TX.mat("#fbf6ee", W, H), 0, 0);
      const pad = 48 * s;
      const g = x.createRadialGradient(W / 2, H * 0.41, 40 * s, W / 2, H * 0.5, 620 * s);
      g.addColorStop(0, c.mixHex("#fffaf6", tint, 0.18)); g.addColorStop(1, c.mixHex("#f3e6e0", tint, 0.42));
      x.fillStyle = g; x.fillRect(pad, pad, W - pad * 2, H - pad * 2);
      x.strokeStyle = "rgba(184,149,90,.6)"; x.lineWidth = 2.5 * s; x.strokeRect(pad, pad, W - pad * 2, H - pad * 2);
      try {
        if (item.photo) { const img = await c.loadImg(item.photo); c.drawCover(x, img, pad, pad, W - pad * 2, H - pad * 2); }
        else if (item.svg) { const a = await c.artCanvas(item.svg, Math.round(1100 * s)); c.drawContain(x, a.c, a.x0, a.y0, a.w, a.h, 104 * s, 120 * s, W - 208 * s, H - 290 * s); }
        else if (item.draw) await item.draw(x, W, H, s);
      } catch (e) { /* keep the empty mount */ }
      if (item.mark) { x.fillStyle = "rgba(110,33,53,.6)"; x.beginPath(); x.arc(W / 2, H - 80 * s, 8 * s, 0, Math.PI * 2); x.arc(W / 2 + 4 * s, H - 83 * s, 6.8 * s, 0, Math.PI * 2, true); x.fill("evenodd"); }
      return cv;
    }
    async function plateTexture(item) {
      if (plateCache.has(item.key)) return plateCache.get(item.key);
      const pr = plateCanvas(item).then((cv) => c.tex(cv, { clamp: true }));
      plateCache.set(item.key, pr);
      return pr;
    }
    /* cut-out garment sprite (transparent background, premultiplied) */
    const spriteCache = new Map();
    async function spriteTexture(key, svg, maxW) {
      if (spriteCache.has(key)) return spriteCache.get(key);
      const pr = (async () => {
        const a = await c.artCanvas(svg, maxW || (c.lite ? 700 : 1000));
        const pad = 6, cv = c.cnv(a.w + pad * 2, a.h + pad * 2), x = cv.getContext("2d");
        x.drawImage(a.c, a.x0, a.y0, a.w, a.h, pad, pad, a.w, a.h);
        return { t: c.tex(cv, { clamp: true, premul: true }), aspect: cv.height / cv.width };
      })();
      spriteCache.set(key, pr);
      return pr;
    }
    return { SILL, wall, flat, shell, frame, plate, pictureLight, window_, compose, env, aoStrip, plateCanvas, plateTexture, spriteTexture };
  }

  /* ================================================================ HALL */
  W3.rooms.hall = function (c) {
    const { V, M4, G, PROF, D2R, clamp, lerp, smooth, lin, mod } = c;
    const K = kit(c), R = "hall", M = c.M, T = c.T;
    const add = (g, m, model, ex) => c.add(R, g, m, model, ex);
    const SLOT_DEG = 30, NSLOT = 12, ENTRY = 6;
    const DISPLAY = [0, 1, 2, 3, 4, 5, 7, 8, 9, 10, 11], ND = DISPLAY.length;
    const APO = 5, HALFW = APO * Math.tan(15 * D2R), CEN = [0, 0, -7.6];
    const WALL_H = 3.7, SILL = 0.95, AW = 1.5, ASPR = 1.55, ADEPTH = 0.45;
    const DOOR_W = 1.6, DOOR_SPR = 2.1, DOOR_TOP = DOOR_SPR + DOOR_W / 2, LEAF_T = 0.05, HINGE_Z = -0.3;
    const PASS_W = 1.72, PASS_H = 3.1, PASS_END = -2.6;
    const slotFrame = (s) => { const a = s * SLOT_DEG * D2R, d = [Math.sin(a), 0, -Math.cos(a)], o = V.add(CEN, V.mul(d, APO)); return { a, d, o, m: M4.basis(o, [Math.cos(a), 0, Math.sin(a)], [0, 1, 0], V.mul(d, -1)) }; };
    const groups = {}; const group = (n) => (groups[n] = groups[n] || { m: M4.ident() });

    /* ---------------- facade & door ---------------- */
    add(G.wallWithArch(-9, 9, 0, 7, DOOR_W, 0, DOOR_SPR, 1, 48), M.plaster);
    add(G.sweep(c.archPath(DOOR_W, DOOR_SPR, 48), false, [[0, 0], [0, HINGE_Z - 0.02]], -1), M.jamb);
    add(G.sweep(c.archPath(DOOR_W, DOOR_SPR, 48), false, PROF.casing, -1), M.moulding);
    add(G.sweep(c.archPath(DOOR_W, DOOR_SPR, 48), false, PROF.bead, -1), M.gold);
    add(c.crescentSolid(0.13, 0.04), M.gold, M4.trans(0, DOOR_TOP + 0.33, 0.06));
    add(G.box(0.24, 0.3, 0.05), M.moulding, M4.trans(0, DOOR_TOP + 0.15, 0.03));
    add(G.box(18, 0.16, 0.03), M.moulding, M4.trans(0, 0.08, 0.015));
    add(G.sweep([[-9, 4.3], [9, 4.3]], false, [[0, 0], [0.04, 0.03], [0.1, 0.04], [0.14, 0.09], [0.2, 0.1], [0.2, 0]], 1), M.moulding);
    [-1, 1].forEach((s) => {
      add(G.sweep(c.roundRect(1.7, 3.3, 0.02, 2).map(([x, y]) => [x + s * 2.55, y + 2.05]), true, PROF.panel, 1), M.moulding);
      add(G.sweep(c.roundRect(1.5, 3.1, 0.02, 2).map(([x, y]) => [x + s * 2.55, y + 2.05]), true, PROF.panel.map(([o, z]) => [o * 0.5, z * 0.6]), 1), M.goldSoft);
    });
    const sconceLights = [];
    [-1, 1].forEach((s) => {
      const x = s * 1.42, y = 2.12;
      add(G.box(0.1, 0.24, 0.02), M.gold, M4.trans(x, y - 0.08, 0.01));
      add(G.cyl(0.012, 0.18, 10, true), M.gold, M4.chain(M4.trans(x, y - 0.12, 0.1), M4.rotX(Math.PI / 2)));
      add(G.cyl(0.07, 0.17, 24, true), c.MAT({ color: lin("#fff3e2"), rough: 0.6, emis: [0.95, 0.68, 0.42] }), M4.trans(x, y, 0.19));
      add(G.cyl(0.074, 0.012, 24, true), M.gold, M4.trans(x, y + 0.088, 0.19));
      add(G.cyl(0.074, 0.012, 24, true), M.gold, M4.trans(x, y - 0.088, 0.19));
      add(G.card(0.62, 0.62), M.glow(lin("#ffcf98"), 0.3), M4.trans(x, y, 0.27));
      sconceLights.push({ p: [x, y + 0.05, 0.32], c: lin("#ffc888", 2.6), r: 3.2 });
    });
    add(G.box(2.1, 0.06, 0.55), M.marble, M4.trans(0, 0.03, 0.27));
    add(G.rect(-9, 0, 9, 12, 0, 1), M.stone, M4.rotX(Math.PI / 2));
    add(K.aoStrip(18, 0.6), M.ao(0.34), M4.chain(M4.trans(0, 0.003, 0), M4.rotX(Math.PI / 2)));
    add(G.card(2.9, 1.0), M.shadow(0.35), M4.chain(M4.trans(0, 0.004, 0.5), M4.rotX(-Math.PI / 2)));
    const spill = add(G.card(3.4, 4.2), M.glow(lin("#ffdccf"), 0), M4.chain(M4.trans(0, 0.07, 2.1), M4.rotX(-Math.PI / 2)));

    function leafGeo() {
      const w = DOOR_W / 2, g = new c.Geo(), parts = [], outline = [[0, 0], [w, 0], [w, DOOR_TOP]];
      for (let k = 1; k <= 24; k++) { const a = Math.PI / 2 + (k / 24) * (Math.PI / 2); outline.push([w + Math.cos(a) * w, DOOR_SPR + Math.sin(a) * w]); }
      g.add(G.fan(outline.slice(), LEAF_T, (x, y) => [x / 1.6, y / 1.6])); g.add(G.fan(outline.slice(), 0, (x, y) => [x / 1.6, y / 1.6], -1));
      g.add(G.sweep(outline, true, [[0, 0], [0, LEAF_T]], 1));
      parts.push({ geo: g, mat: M.lacquer });
      const ins = 0.12, gy0 = 1.25, pane = [[ins, gy0], [w - 0.03, gy0], [w - 0.03, DOOR_SPR + 0.02]], pr = w - ins - 0.03;
      for (let k = 1; k <= 20; k++) { const a = Math.PI / 2 + (k / 20) * (Math.PI / 2); pane.push([w - 0.03 + Math.cos(a) * pr, DOOR_SPR + 0.02 + Math.sin(a) * pr * 0.92]); }
      const minx = ins, maxx = w - 0.03, miny = gy0, maxy = DOOR_SPR + 0.02 + pr * 0.92;
      parts.push({ geo: G.fan(pane, LEAF_T + 0.004, (x, y) => [(x - minx) / (maxx - minx), (y - miny) / (maxy - miny)]), mat: "glass", bounds: [maxx - minx, maxy - miny] });
      const mould = [[-0.026, 0], [-0.02, 0.012], [-0.006, 0.02], [0.004, 0.014], [0.012, 0.004], [0.012, 0]];
      parts.push({ geo: G.sweep(pane, true, mould.map(([o, z]) => [o, z + LEAF_T]), 1), mat: M.moulding });
      const lp = c.roundRect(w - 0.2, 0.86, 0.015, 2).map(([x, y]) => [x + w / 2 + 0.035, y + 0.62]);
      parts.push({ geo: G.sweep(lp, true, mould.map(([o, z]) => [o, z + LEAF_T]), 1), mat: M.moulding });
      parts.push({ geo: G.fan(lp, LEAF_T + 0.01, (x, y) => [x / 1.6, y / 1.6]), mat: M.lacquer });
      parts.push({ geo: G.box(w - 0.16, 0.012, 0.012), mat: M.goldSoft, m: M4.trans(w / 2 + 0.03, 1.16, LEAF_T + 0.006) });
      const hx = w - 0.075;
      parts.push({ geo: G.cyl(0.011, 0.34, 16, true), mat: M.gold, m: M4.trans(hx, 1.08, LEAF_T + 0.055) });
      [0.95, 1.21].forEach((y) => parts.push({ geo: G.cyl(0.007, 0.05, 10, true), mat: M.gold, m: M4.chain(M4.trans(hx, y, LEAF_T + 0.03), M4.rotX(Math.PI / 2)) }));
      [0.95, 1.21].forEach((y) => parts.push({ geo: G.box(0.03, 0.1, 0.006), mat: M.gold, m: M4.trans(hx, y, LEAF_T + 0.003) }));
      return parts;
    }
    function glassCanvas(side, w, h) {
      const Wc = c.lite ? 512 : 1024, Hc = Math.round(Wc * h / w), cv = c.cnv(Wc, Hc), x = cv.getContext("2d");
      const g = x.createLinearGradient(0, 0, 0, Hc);
      g.addColorStop(0, "#fff6f2"); g.addColorStop(0.5, "#fbdde5"); g.addColorStop(1, "#f2bccb");
      x.fillStyle = g; x.fillRect(0, 0, Wc, Hc);
      // the vector logo spans both panes, like the sign on the original door
      c.drawLogo(x, side === "l" ? Wc : 0, Hc * 0.44, Wc * 2 * 0.9);
      return cv;
    }
    const leaves = {};
    leafGeo().forEach((part) => {
      [-1, 1].forEach((side) => {
        const name = side < 0 ? "leafL" : "leafR", grp = group(name);
        let mat = part.mat;
        if (mat === "glass") {
          const gt = c.tex(glassCanvas(side < 0 ? "l" : "r", part.bounds[0], part.bounds[1]), { clamp: true });
          mat = c.MAT({ map: gt, color: [0.7, 0.66, 0.66], rough: 0.14, env: 0.22, emis: [0.6, 0.5, 0.5], emisMap: 1 });
          leaves[name + "Glass"] = mat;
        }
        const g = new c.Geo(); g.add(part.geo, part.m || null);
        if (side > 0 && part.mat === "glass") for (let k = 0; k < g.u.length; k += 2) g.u[k] = 1 - g.u[k];
        const gm = new c.Geo(); gm.add(g, side > 0 ? new Float32Array([-1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1]) : null);
        if (side > 0) for (let k = 0; k < gm.i.length; k += 3) { const t = gm.i[k]; gm.i[k] = gm.i[k + 1]; gm.i[k + 1] = t; }
        add(gm, mat, null, { group: grp });
      });
    });
    const seam = add(G.card(0.05, DOOR_TOP - 0.1), M.glow(lin("#ffd8d0"), 0), M4.trans(0, (DOOR_TOP - 0.1) / 2 + 0.03, HINGE_Z + LEAF_T + 0.012));

    /* ---------------- vestibule ---------------- */
    const pz0 = HINGE_Z - 0.02, pz1 = PASS_END, hw = PASS_W / 2;
    [-1, 1].forEach((s) => {
      const len = pz0 - pz1;
      const m = s < 0 ? M4.basis([-hw, 0, pz0], [0, 0, -1], [0, 1, 0], [1, 0, 0]) : M4.basis([hw, 0, pz1], [0, 0, 1], [0, 1, 0], [-1, 0, 0]);
      add(G.rect(0, 0, len, SILL, 0, 1), M.plasterIn, m); add(G.rect(0, SILL, len, PASS_H, 0, 1), M.wallpaper, m);
      add(G.sweep([[0, SILL], [len, SILL]], false, PROF.rail, -1), M.moulding, m);
      add(G.box(len, 0.14, 0.02), M.moulding, M4.mul(m, M4.trans(len / 2, 0.07, 0.01)));
    });
    add(G.rect(-hw, pz1, hw, pz0, 0, 1), M.ceiling, M4.chain(M4.trans(0, PASS_H, 0), M4.rotX(Math.PI / 2)));
    const photoSlots = [];
    [-1, 1].forEach((s) => {
      const z = -1.78, m = s < 0 ? M4.basis([-hw + 0.012, 1.72, z], [0, 0, -1], [0, 1, 0], [1, 0, 0]) : M4.basis([hw - 0.012, 1.72, z], [0, 0, 1], [0, 1, 0], [-1, 0, 0]);
      add(G.sweep(c.roundRect(0.62, 0.98, 0.01, 2), true, [[-0.035, 0], [-0.03, 0.02], [0, 0.03], [0.01, 0.012], [0.012, 0]], 1), M.gold, m);
      photoSlots.push(add(G.card(0.6, 0.96, 0.006), c.MAT({ map: T.mat, rough: 0.7, env: 0.15, emis: [0.12, 0.1, 0.09], emisMap: 1 }), m));
      add(G.card(0.86, 1.2), M.shadow(0.25), M4.mul(m, M4.trans(0.03, -0.05, -0.004)));
    });

    /* ---------------- rotunda ---------------- */
    const floorPts = [];
    for (let k = 0; k < NSLOT; k++) { const a = (k * SLOT_DEG + 15) * D2R, rc = APO / Math.cos(15 * D2R); floorPts.push([CEN[0] + Math.sin(a) * rc, CEN[2] - Math.cos(a) * rc]); }
    add(G.fan(floorPts.map(([x, z]) => [x, -z]).reverse(), 0, (x, y) => [x, y]), M.marble, M4.rotX(-Math.PI / 2));
    add(G.rect(-hw, -pz0, hw, -pz1, 0, 1), M.marble, M4.rotX(-Math.PI / 2));
    const rugPts = []; for (let k = 0; k < 96; k++) { const a = (k / 96) * Math.PI * 2; rugPts.push([Math.cos(a) * 3.0, Math.sin(a) * 3.0]); }
    add(G.fan(rugPts, 0, (x, y) => [x / 6 + 0.5, y / 6 + 0.5]), M.rug, M4.chain(M4.trans(CEN[0], 0.006, CEN[2]), M4.rotX(-Math.PI / 2)));
    add(G.sweep(rugPts.slice().reverse(), true, [[0, 0], [0, 0.012], [0.02, 0.012]], 1), c.MAT({ color: lin("#5a1b2c"), rough: 0.9 }), M4.chain(M4.trans(CEN[0], -0.006, CEN[2]), M4.rotX(-Math.PI / 2)));
    add(G.fan(floorPts.map(([x, z]) => [x, -z]), 0, (x, y) => [x, y]), M.ceiling, M4.chain(M4.trans(0, WALL_H + 0.25, 0), M4.rotX(-Math.PI / 2)));
    add(G.disc(2.5, 96), M.skylight, M4.chain(M4.trans(CEN[0], WALL_H + 0.24, CEN[2]), M4.rotX(-Math.PI / 2)));
    add(G.lathe([[2.5, 0], [2.58, -0.04], [2.66, -0.04], [2.72, 0]], 96), M.gold, M4.trans(CEN[0], WALL_H + 0.24, CEN[2]));
    const pendant = add(c.crescentSolid(0.42, 0.05), M.gold, M4.trans(CEN[0], 3.15, CEN[2]));
    add(G.cyl(0.004, 0.9, 6), M.gold, M4.trans(CEN[0] + 0.08, 3.85, CEN[2]));
    add(G.card(2.2, 2.2), M.glow(lin("#ffe2c8"), 0.35), M4.trans(CEN[0], 3.15, CEN[2] + 0.04));

    const slots = [];
    for (let s = 0; s < NSLOT; s++) {
      const f = slotFrame(s), m = f.m, entry = s === ENTRY;
      const tile = (geo, mat, extra) => add(geo, mat, extra ? M4.mul(m, extra) : m);
      if (entry) {
        const aw = PASS_W, spr = PASS_H - aw / 2;
        tile(G.rect(-HALFW, 0, -aw / 2, SILL, 0, 1), M.plasterIn); tile(G.rect(aw / 2, 0, HALFW, SILL, 0, 1), M.plasterIn);
        tile(G.rect(-HALFW, SILL, -aw / 2, WALL_H + 0.25, 0, 1), M.wallpaper); tile(G.rect(aw / 2, SILL, HALFW, WALL_H + 0.25, 0, 1), M.wallpaper);
        const lo = [], hi = []; for (let k = 0; k <= 32; k++) { const x = -aw / 2 + (k / 32) * aw; lo.push([x, spr + Math.sqrt(Math.max(0, aw * aw / 4 - x * x))]); hi.push([x, WALL_H + 0.25]); }
        tile(G.strip(lo, hi, 0), M.wallpaper);
        tile(G.sweep(c.archPath(aw, spr, 48), false, PROF.casing, -1), M.moulding);
        tile(G.sweep(c.archPath(aw, spr, 48), false, PROF.bead, -1), M.gold);
        slots.push({ s, f, entry: true });
      } else {
        tile(G.rect(-HALFW, 0, HALFW, SILL, 0, 1), M.plasterIn);
        tile(G.wallWithArch(-HALFW, HALFW, SILL, WALL_H + 0.25, AW, SILL, ASPR, 1, 36), M.wallpaper);
        tile(G.sweep(c.roundRect(1.9, 0.5, 0.01, 2).map(([x, y]) => [x, y + 0.5]), true, PROF.panel, 1), M.moulding);
        const ap = c.archPath(AW, ASPR, 40, SILL), top = SILL + ASPR + AW / 2;
        tile(G.sweep(ap, false, [[0, 0], [0, -ADEPTH]], -1), M.reveal);
        tile(G.fan(ap, -ADEPTH, (x, y) => [(x + AW / 2) / AW, (y - SILL) / (top - SILL)]), M.alcove);
        tile(G.box(AW + 0.08, 0.05, ADEPTH + 0.1), M.marble, M4.trans(0, SILL + 0.005, -ADEPTH / 2 + 0.05));
        tile(G.sweep(ap, false, PROF.casing.map(([o, z]) => [o * 0.75, z * 0.8]), -1), M.moulding);
        tile(G.sweep(ap, false, PROF.bead.map(([o, z]) => [o - 0.008, z - 0.009]), -1), M.gold);
        tile(G.box(0.62, 0.012, 0.3), M.velvet, M4.trans(0, SILL + 0.036, -ADEPTH / 2));
        tile(G.box(0.18, 0.05, 0.012), M.gold, M4.trans(0, SILL + 0.06, 0.05));
        const glow = tile(G.card(1.5, 1.3), M.glow(lin("#ffe2d2"), 0.16), M4.trans(0, top - 0.6, -ADEPTH + 0.05));
        const PW = 1.0, PH = 1.33, py = SILL + 1.0, pz = -ADEPTH + 0.07;
        K.frame(R, M4.mul(m, M4.trans(0, py, pz)), PW, PH);
        const plateMat = c.MAT({ map: T.mat, rough: 0.75, env: 0.08, emis: [0.1, 0.09, 0.085], emisMap: 1 });
        const plate = tile(G.card(PW - 0.004, PH - 0.004, 0.004), plateMat, M4.trans(0, py, pz));
        tile(G.card(PW + 0.32, PH + 0.3), M.shadow(0.28), M4.trans(0.02, py - 0.05, pz - 0.006));
        slots.push({ s, f, entry: false, plate, plateMat, glow, key: null, py, top });
      }
      tile(G.box(HALFW * 2, 0.14, 0.022), M.moulding, M4.trans(0, 0.07, 0.011));
      tile(G.sweep(entry ? [[-HALFW, SILL], [-PASS_W / 2 - 0.2, SILL]] : [[-HALFW, SILL], [HALFW, SILL]], false, PROF.rail, -1), M.moulding);
      if (entry) tile(G.sweep([[PASS_W / 2 + 0.2, SILL], [HALFW, SILL]], false, PROF.rail, -1), M.moulding);
      tile(G.sweep([[-HALFW - 0.06, WALL_H], [HALFW + 0.06, WALL_H]], false, PROF.cornice, -1), M.moulding);
      tile(K.aoStrip(HALFW * 2, 0.5), M.ao(0.34), M4.chain(M4.trans(0, 0.004, 0), M4.rotX(Math.PI / 2)));
      const ca = (s * SLOT_DEG - 15) * D2R, rc = APO / Math.cos(15 * D2R) - 0.03;
      const pm = M4.basis([CEN[0] + Math.sin(ca) * rc, 0, CEN[2] - Math.cos(ca) * rc], [Math.cos(ca), 0, Math.sin(ca)], [0, 1, 0], [-Math.sin(ca), 0, Math.cos(ca)]);
      add(G.box(0.26, WALL_H, 0.12), M.moulding, M4.mul(pm, M4.trans(0, WALL_H / 2, 0)));
      add(G.box(0.012, WALL_H - 0.7, 0.004), M.goldSoft, M4.mul(pm, M4.trans(0, WALL_H / 2 + 0.1, 0.062)));
      add(G.box(0.34, 0.1, 0.16), M.moulding, M4.mul(pm, M4.trans(0, WALL_H - 0.05, 0)));
      add(G.box(0.32, 0.2, 0.15), M.moulding, M4.mul(pm, M4.trans(0, 0.1, 0)));
    }

    const L = {
      sconces: sconceLights,
      doorway: { p: [0, 1.8, -1.0], c: [0, 0, 0], r: 6.5, prio: 3 },
      passage: { p: [0, 2.8, -1.9], c: lin("#ffe6d8", 1.6), r: 4.5 },
      chandelier: { p: [CEN[0], 3.0, CEN[2]], c: lin("#ffd6ae", 2.0), r: 8.5, prio: 6 },
      alcoves: slots.filter((x) => !x.entry).map((x) => ({ p: M4.pt(x.f.m, [0, x.top - 0.3, 0.3]), c: lin("#ffdcc4", 1.5), r: 2.6 }))
    };

    /* ---------------- photographs in the vestibule ---------------- */
    ["assets/brand-bedroom.jpg", "assets/brand-crescents.jpg"].forEach((src, i) => {
      c.loadImg(c.base + src).then((img) => {
        const cv = c.cnv(600, 960), x = cv.getContext("2d");
        x.drawImage(c.TX.mat("#fbf6ee", 600, 960), 0, 0); c.drawCover(x, img, 40, 40, 520, 880);
        photoSlots[i].mat = Object.assign({}, photoSlots[i].mat, { map: c.tex(cv, { clamp: true }) }); c.wake();
      }).catch(() => {});
    });
    const decor = [
      { key: "decor-photo-0", photo: c.base + "assets/brand-bedroom.jpg" },
      { key: "decor-photo-1", photo: c.base + "assets/brand-crescents.jpg" },
      { key: "decor-logo", draw: async (x, w, h, s) => { c.drawLogo(x, w / 2, h * 0.48, w * 0.7); x.fillStyle = "rgba(184,149,90,.85)"; x.beginPath(); x.arc(w / 2, h * 0.33, 34 * s, 0, Math.PI * 2); x.arc(w / 2 + 15 * s, h * 0.33 - 9 * s, 28 * s, 0, Math.PI * 2, true); x.fill("evenodd"); } }
    ];

    /* ---------------- state ---------------- */
    const st = {
      phase: "rotunda", openT: -1, hoverDoor: 0, hoverDoorT: 0, onArrive: null,
      yaw: 0, yawT: 0, yawV: 0, dragging: false, cur: 0, focus: 0, focusT: 0,
      items: [], hoverK: null, collectionFade: 1, collectionTarget: 1, pendingItems: null, pendingCur: 0
    };
    const n = () => st.items.length;
    const yawOf = (k) => (DISPLAY[mod(k, ND)] * SLOT_DEG + Math.floor(k / ND) * 360) * D2R;
    function contentOf(k) { const N = n(); if (!N) return { decor: mod(k, ND) }; if (N >= ND) return st.items[mod(k, N)]; return mod(k, ND) < N ? st.items[mod(k, ND)] : { decor: mod(k, ND) - N }; }
    const valid = (k) => { const N = n(); return N >= ND || mod(k, ND) < N; };
    const productIndexOf = (k) => { const N = n(); return N >= ND ? mod(k, N) : mod(k, ND); };
    function assignSlots(force) {
      for (const sl of slots) {
        if (sl.entry) continue;
        const j = DISPLAY.indexOf(sl.s), base = st.cur - mod(st.cur, ND) + j;
        let best = base; [base - ND, base + ND].forEach((k) => { if (Math.abs(k - st.cur) < Math.abs(best - st.cur)) best = k; });
        const it = contentOf(best), key = it.decor != null ? "decor" + (it.decor % decor.length) : it.key;
        sl.k = best;
        if (sl.key === key && !force) continue;
        sl.key = key;
        const want = it.decor != null ? decor[it.decor % decor.length] : it;
        const token = (sl.token = (sl.token || 0) + 1);
        K.plateTexture(want).then((t) => { if (sl.token !== token) return; sl.plateMat.map = t; c.wake(); });
      }
    }
    function setLeaves(a) {
      group("leafL").m = M4.chain(M4.trans(-DOOR_W / 2, 0, HINGE_Z), M4.rotY(a));
      group("leafR").m = M4.chain(M4.trans(DOOR_W / 2, 0, HINGE_Z), M4.rotY(-a));
    }
    const OPEN = { unlatch: 0.42, swing: 1.75, flyStart: 0.85, fly: 2.9 };
    function leafAngle(t) {
      if (t < 0) return st.hoverDoor * 1.6 * D2R;
      if (t < OPEN.unlatch) return lerp(st.hoverDoor * 1.6, 4, c.easeOutCubic(t / OPEN.unlatch)) * D2R;
      const u = (t - OPEN.unlatch) / OPEN.swing;
      if (u < 1) return lerp(4, 89, c.easeInOutCubic(u)) * D2R;
      const s = t - OPEN.unlatch - OPEN.swing;
      return (89 - 1.4 * Math.sin(s * 9) * Math.exp(-s * 5)) * D2R;
    }
    function doorView() {
      const cam = c.cam, vf = cam.fov * D2R, hf = 2 * Math.atan(Math.tan(vf / 2) * cam.aspect);
      const z = Math.max(2.25 / Math.tan(vf / 2), (cam.aspect < 0.8 ? 1.22 : 1.75) / Math.tan(hf / 2), 4.6);
      return { pos: [0, 1.62, z], tgt: [0, 1.62 - 0.06 * z / 5, 0] };
    }
    function catmull(pts, t) {
      const ns = pts.length - 1, s = clamp(t, 0, 1) * ns, i = Math.min(ns - 1, Math.floor(s)), u = s - i;
      const p0 = pts[Math.max(0, i - 1)], p1 = pts[i], p2 = pts[i + 1], p3 = pts[Math.min(ns, i + 2)];
      return [0, 1, 2].map((q) => 0.5 * ((2 * p1[q]) + (-p0[q] + p2[q]) * u + (2 * p0[q] - 5 * p1[q] + 4 * p2[q] - p3[q]) * u * u + (-p0[q] + 3 * p1[q] - 3 * p2[q] + p3[q]) * u * u * u));
    }
    let openAmt = 0;
    function nearestK(yaw) {
      let best = st.cur, bd = 1e9;
      for (let k = st.cur - ND - 2; k <= st.cur + ND + 2; k++) { if (!valid(k)) continue; const d = Math.abs(yawOf(k) - yaw); if (d < bd) { bd = d; best = k; } }
      return best;
    }

    const room = {
      visible: ["hall"],
      env(cam) {
        const k = clamp((-cam.pos[2] - 0.2) / 2.2, 0, 1);
        return K.env({ sky: V.lerp([0.36, 0.3, 0.27], [0.34, 0.26, 0.25], k), gnd: [0.13, 0.095, 0.09], keyCol: V.mul([1.0, 0.84, 0.68], lerp(0.85, 0.1, k)), expo: lerp(1.06, 1.0, k) });
      },
      lights() { return [...L.sconces, L.doorway, L.passage, L.chandelier, ...L.alcoves]; },
      camera(shot, p, dt) {
        const cs = c.st;
        if (st.phase === "door") {
          const dv = doorView(), par = cs.reduce ? [0, 0] : cs.pointerS;
          return { direct: true, pos: V.add(dv.pos, [par[0] * 0.32, par[1] * 0.14 + Math.sin(cs.t * 0.6) * 0.01, 0]), tgt: V.add(dv.tgt, [par[0] * 0.06, par[1] * 0.03, 0]), fov: 40 };
        }
        if (st.phase === "opening") {
          const t = st.openT, ft = clamp((t - OPEN.flyStart) / OPEN.fly, 0, 1), e = c.easeInOutSine(ft);
          const dv = doorView(), keys = [dv.pos, [0, 1.6, 2.4], [0, 1.62, 0.55], [0, 1.62, -1.2], [0, 1.6, -4.4], [CEN[0], 1.6, CEN[2]]];
          keys[0] = V.add(keys[0], [cs.pointerS[0] * 0.32 * (1 - e), cs.pointerS[1] * 0.14 * (1 - e), 0]);
          const pos = catmull(keys, e), ahead = catmull(keys, Math.min(1, e + 0.08));
          const look = e < 0.999 && V.len(V.sub(ahead, pos)) > 1e-3 ? V.norm(V.sub(ahead, pos)) : [0, 0, -1];
          const tgt = V.lerp(dv.tgt, V.add(pos, V.mul([look[0] * 0.2, -0.006, -1], 5)), smooth(clamp(ft * 1.6, 0, 1)));
          return { direct: true, pos, tgt, fov: lerp(40, 55, smooth(ft)) };
        }
        // rotunda: yaw spring and focus
        if (!st.dragging) {
          const kk = 38, dmp = 2 * Math.sqrt(kk);
          st.yawV += ((st.yawT - st.yaw) * kk - st.yawV * dmp) * dt; st.yaw += st.yawV * dt;
          if (Math.abs(st.yawT - st.yaw) < 1e-4 && Math.abs(st.yawV) < 1e-4) { st.yaw = st.yawT; st.yawV = 0; }
        }
        let yaw = st.yaw;
        if (shot === "hero") yaw = st.yaw + (cs.progress - 0.5) * 0.9 + Math.sin(cs.t * 0.12) * 0.04;
        st.focus = c.damp(st.focus, st.focusT, cs.reduce ? 30 : 4.2, dt);
        const fwd = [Math.sin(yaw), 0, -Math.cos(yaw)], centre = [CEN[0], 1.6, CEN[2]], f = smooth(clamp(st.focus, 0, 1));
        const roomPos = V.add(centre, [0, Math.sin(cs.t * 0.35) * (cs.reduce ? 0 : 0.012), 0]);
        const roomTgt = V.add(V.add(centre, V.mul(fwd, 5)), [0, -0.03, 0]);
        const wide = K.compose(roomPos, roomTgt, 55, shot === "hero" ? 0 : 0.35);
        if (f < 0.001) return { pos: wide.pos, tgt: wide.tgt, fov: 55, k: 9 };
        const alc = V.add(centre, V.mul(fwd, APO - 0.3)); alc[1] = SILL + 1.0;
        const fpos = V.add(centre, V.mul(fwd, c.st.layout === "bottom" ? 2.05 : 2.45)); fpos[1] = 1.68;
        const close = K.compose(fpos, alc, c.st.layout === "bottom" ? 50 : 44, 1);
        return { pos: V.lerp(wide.pos, close.pos, f), tgt: V.lerp(wide.tgt, close.tgt, f), fov: lerp(55, close.fov, f), k: 9 };
      },
      update(dt) {
        const cs = c.st;
        st.hoverDoor = c.damp(st.hoverDoor, st.hoverDoorT, 6, dt);
        let open = 0, anim = false;
        if (st.phase === "door") { setLeaves(leafAngle(-1)); anim = Math.abs(st.hoverDoor - st.hoverDoorT) > 0.002; }
        else if (st.phase === "opening") {
          st.openT += dt; setLeaves(leafAngle(st.openT)); open = clamp((st.openT - 0.25) / 1.4, 0, 1); anim = true;
          if (st.openT >= OPEN.flyStart + OPEN.fly) { st.phase = "rotunda"; st.yaw = st.yawT = yawOf(st.cur); const f = st.onArrive; st.onArrive = null; if (f) f(); }
        }
        if (st.phase === "rotunda") { setLeaves(89 * D2R); open = 1; }
        openAmt = open;
        L.doorway.c = lin("#ffd9cf", 3.2 * open);
        spill.mat.opacity = 0.55 * open * (st.phase === "rotunda" ? 0.6 : 1);
        seam.mat.opacity = (0.18 + st.hoverDoor * 0.55) * (1 - smooth(clamp(open * 3, 0, 1))) * (st.phase !== "rotunda" ? 1 : 0);
        const g = 0.5 + Math.sin(cs.t * 1.1) * 0.035 + st.hoverDoor * 0.2;
        ["leafLGlass", "leafRGlass"].forEach((k) => { if (leaves[k]) leaves[k].emis = [g * 0.95, g * 0.8, g * 0.8]; });
        const cf0 = st.collectionFade;
        st.collectionFade = c.damp(st.collectionFade, st.collectionTarget, 9, dt);
        if (Math.abs(cf0 - st.collectionFade) > 0.001) anim = true;
        if (st.collectionTarget === 0 && st.collectionFade < 0.03 && st.pendingItems) {
          st.items = st.pendingItems; st.pendingItems = null; st.cur = st.pendingCur || 0; st.yawT = yawOf(st.cur);
          if (cs.reduce) st.yaw = st.yawT;
          assignSlots(true); st.collectionTarget = 1;
        }
        for (const sl of slots) {
          if (sl.entry) continue;
          const h0 = sl.hov || 0;
          sl.hov = c.damp(h0, sl.k === st.hoverK && st.phase === "rotunda" ? 1 : 0, 10, dt);
          if (Math.abs(h0 - sl.hov) > 0.002) anim = true;
          const cf = st.collectionFade;
          sl.plateMat.emis = [0.05 + sl.hov * 0.08, 0.045 + sl.hov * 0.07, 0.043 + sl.hov * 0.065].map((v) => v * cf + 0.01 * (1 - cf));
          sl.plateMat.color = [lerp(0.45, 0.78, cf), lerp(0.4, 0.76, cf), lerp(0.42, 0.76, cf)];
          sl.glow.mat.opacity = 0.14 + sl.hov * 0.2;
        }
        pendant.model = M4.chain(M4.trans(CEN[0], 3.15 + Math.sin(cs.t * 0.7) * 0.01, CEN[2]), M4.rotY(Math.sin(cs.t * 0.25) * 0.25));
        if (st.phase === "rotunda" && st.dragging) {
          const want = nearestK(st.yaw);
          if (want !== st.cur) { st.cur = want; assignSlots(); if (room.onIndex) room.onIndex(st.cur, productIndexOf(st.cur)); }
        }
        if (Math.abs(st.yawT - st.yaw) > 1e-4 || Math.abs(st.yawV) > 1e-4 || Math.abs(st.focus - st.focusT) > 0.002) anim = true;
        return anim;
      },
      pick(r) {
        if (st.phase === "door") {
          if (Math.abs(r.d[2]) < 1e-5) return null;
          const t = (0 - r.o[2]) / r.d[2]; if (t <= 0) return null;
          const p = V.add(r.o, V.mul(r.d, t)), x = p[0], y = p[1], w = DOOR_W + 0.2;
          const inside = Math.abs(x) <= w / 2 && y >= 0 && (y < DOOR_SPR || Math.hypot(x, y - DOOR_SPR) <= w / 2);
          return inside ? { type: "door" } : null;
        }
        if (st.phase !== "rotunda") return null;
        let best = null;
        for (const sl of slots) {
          if (sl.entry) continue;
          const zN = V.mul(sl.f.d, -1), ax = [Math.cos(sl.f.a), 0, Math.sin(sl.f.a)];
          const den = V.dot(r.d, zN); if (den >= -1e-4) continue;
          const t = V.dot(V.sub(sl.f.o, r.o), zN) / den; if (t <= 0) continue;
          const p = V.sub(V.add(r.o, V.mul(r.d, t)), sl.f.o), lx = V.dot(p, ax), ly = p[1];
          const inside = Math.abs(lx) <= AW / 2 && ly >= SILL && (ly < SILL + ASPR || Math.hypot(lx, ly - SILL - ASPR) <= AW / 2);
          if (inside && (!best || t < best.t)) best = { t, sl };
        }
        if (!best || !valid(best.sl.k) || !n()) return null;
        return { type: "slot", k: best.sl.k, index: productIndexOf(best.sl.k) };
      },
      hover(h) {
        if (st.phase === "door") st.hoverDoorT = h && h.type === "door" ? 1 : 0;
        else st.hoverK = h && h.type === "slot" ? h.k : null;
        c.wake(500);
      },
      onEnter() { c.st.veilColor = lin("#fbf8ef"); },
      /* API used by the interface */
      phase: () => st.phase,
      showDoor() { st.phase = "door"; st.openT = -1; st.focusT = st.focus = 0; setLeaves(0); c.wake(); },
      open(cb) {
        st.onArrive = cb || null;
        if (c.st.reduce) { room.toRotunda(); const f = st.onArrive; st.onArrive = null; if (f) f(); return; }
        st.phase = "opening"; st.openT = 0; c.wake(8000);
      },
      skip() { if (st.phase === "opening") st.openT = Math.max(st.openT, OPEN.flyStart + OPEN.fly); },
      toRotunda() { st.phase = "rotunda"; st.openT = 99; st.yaw = st.yawT = yawOf(st.cur); st.focus = st.focusT = 0; setLeaves(89 * D2R); c.wake(); },
      setItems(list, startIndex) {
        const ks = startIndex || 0;
        if (!st.items.length || st.phase !== "rotunda" || c.api.room() !== "hall") { st.items = list; st.cur = ks; st.yaw = st.yawT = yawOf(ks); assignSlots(true); c.wake(); return; }
        st.pendingItems = list; st.pendingCur = ks; st.collectionTarget = 0; c.wake(1500);
      },
      refreshItem(i, item) { st.items[i] = item; slots.forEach((sl) => { if (!sl.entry && sl.k != null && valid(sl.k) && productIndexOf(sl.k) === i && n()) sl.key = null; }); assignSlots(); },
      preload(list) { list.forEach((it) => K.plateTexture(it)); },
      go(delta) {
        if (!n()) return st.cur;
        let k = st.cur; do { k += delta; } while (!valid(k));
        const N = n();
        [k - ND, k + ND].filter(valid).forEach((a) => { if (productIndexOf(a) === productIndexOf(k) && N < ND && Math.abs(yawOf(a) - st.yaw) < Math.abs(yawOf(k) - st.yaw)) k = a; });
        room.goTo(k); return k;
      },
      goTo(k) { st.cur = k; st.yawT = yawOf(k); if (c.st.reduce) { st.yaw = st.yawT; st.yawV = 0; } assignSlots(); c.wake(1500); if (room.onIndex) room.onIndex(k, productIndexOf(k)); },
      goToIndex(i) {
        let best = null;
        for (let k = st.cur - 2 * ND; k <= st.cur + 2 * ND; k++) if (valid(k) && productIndexOf(k) === i && (best === null || Math.abs(yawOf(k) - st.yaw) < Math.abs(yawOf(best) - st.yaw))) best = k;
        if (best !== null) room.goTo(best);
        return best;
      },
      current: () => ({ k: st.cur, index: productIndexOf(st.cur) }),
      focus(on) { st.focusT = on ? 1 : 0; c.wake(1500); },
      dragStart() { st.dragging = true; st.yawV = 0; c.wake(); },
      dragBy(dx) { st.yaw -= dx / c.size().W * 1.6; st.yawT = st.yaw; c.wake(); },
      dragEnd(vx) {
        st.dragging = false;
        const proj = st.yaw - (vx || 0) / c.size().W * 0.45;
        let best = st.cur, bd = 1e9;
        for (let k = st.cur - ND - 2; k <= st.cur + ND + 2; k++) { if (!valid(k)) continue; const d = Math.abs(yawOf(k) - proj); if (d < bd) { bd = d; best = k; } }
        room.goTo(best);
      },
      doorAnchor() { return { sign: c.project([0, 1.42, HINGE_Z + LEAF_T]), w: Math.abs(c.project([0.62, 1.5, -0.25])[0] - c.project([-0.62, 1.5, -0.25])[0]) }; },
      debug: { st, seek(t) { st.phase = "opening"; st.openT = t; } }
    };
    room.showDoor(); st.phase = "rotunda"; setLeaves(89 * D2R);
    return room;
  };

  /* ============================================================= ATELIER */
  W3.rooms.atelier = function (c) {
    const { V, M4, G, PROF, D2R, clamp, lerp, lin } = c;
    const K = kit(c), R = "atelier", M = c.M, T = c.T, O = [40, 0, 0];
    const at = (x, y, z) => [O[0] + x, O[1] + y, O[2] + z];
    const add = (g, m, model, ex) => c.add(R, g, m, model, ex);
    const TR = (x, y, z) => M4.trans(O[0] + x, y, O[2] + z);
    const H = 3.9;
    K.shell(R, { x0: O[0] - 4.6, x1: O[0] + 4.6, z0: -3.6, z1: 4.4, h: H, floor: M.wood, back: { panels: true }, left: {}, right: {} });
    /* windows on the back wall */
    [-1, 1].forEach((s) => K.window_(R, M4.basis(at(s * 3.0, 1.05, -3.59), [1, 0, 0], [0, 1, 0], [0, 0, 1]), 1.15, 2.45));
    [-1, 1].forEach((s) => add(G.card(2.4, 3.6), M.beam(lin("#fff1e4"), 0.08), M4.chain(TR(s * 2.6, 2.1, -2.6), M4.rotY(-s * 0.35), M4.rotZ(s * 0.32))));
    /* the board */
    const BW = 1.55, BH = 2.05, BY = 2.0, BZ = -3.52;
    const boardM = M4.mul(TR(0, BY, BZ), M4.ident());
    const board = K.plate(R, boardM, BW, BH, { emis: [0.07, 0.065, 0.06], color: [0.82, 0.8, 0.8], shadowO: 0.3 });
    K.frame(R, M4.mul(boardM, M4.trans(0, 0, 0.005)), BW + 0.09, BH + 0.09, M.goldSoft);
    K.pictureLight(R, M4.mul(boardM, M4.trans(0, BH / 2 + 0.12, 0)), 0.6);
    add(G.card(1.9, 1.5), M.glow(lin("#ffe7d6"), 0.12), M4.mul(boardM, M4.trans(0, BH / 2 - 0.35, 0.02)));
    /* the worktable */
    const TY = 0.82, TZ = -1.25;
    add(G.softBox(3.1, 0.05, 1.0, 0.03, 3), M.marble, TR(0, TY - 0.025, TZ));
    add(G.box(3.0, 0.09, 0.9), M.lacquer, TR(0, TY - 0.095, TZ));
    add(G.box(3.02, 0.012, 0.012), M.gold, TR(0, TY - 0.055, TZ + 0.452));
    [[-1.42, -0.4], [1.42, -0.4], [-1.42, 0.4], [1.42, 0.4]].forEach(([x, z]) => {
      add(G.cyl(0.024, TY - 0.14, 14, true, 0.036), M.lacquer, TR(x, (TY - 0.14) / 2, TZ + z));
      add(G.cyl(0.026, 0.04, 14, true), M.gold, TR(x, 0.02, TZ + z));
    });
    add(G.card(3.6, 1.6), M.shadowSoft(0.45), M4.chain(TR(0, 0.004, TZ), M4.rotX(-Math.PI / 2)));
    add(G.disc(1.9, 72), M.rug, M4.chain(TR(0, 0.006, TZ + 0.3), M4.rotX(-Math.PI / 2), M4.scale(1.25, 0.8, 1)));
    /* hoop on its little stand */
    const HX = -0.95, HY = TY + 0.36, HZ = TZ + 0.05, HR = 0.25;
    const hoopM = M4.chain(TR(HX, HY, HZ), M4.rotX(-0.22));
    add(G.torus(HR, 0.016, 56, 10), M.woodFurn, M4.mul(hoopM, M4.rotX(Math.PI / 2)));
    add(G.torus(HR - 0.012, 0.01, 56, 8), M.woodFurn, M4.chain(hoopM, M4.trans(0, 0, -0.008), M4.rotX(Math.PI / 2)));
    add(G.box(0.05, 0.04, 0.03), M.gold, M4.mul(hoopM, M4.trans(0, HR + 0.02, 0)));
    const hoopMat = c.MAT({ map: T.weave, rough: 0.9, env: 0.04, emis: [0.05, 0.045, 0.045], emisMap: 1 });
    const hoop = add(G.disc(HR - 0.008, 64), hoopMat, M4.mul(hoopM, M4.trans(0, 0, -0.002)));
    [-1, 1].forEach((s) => add(G.cyl(0.008, 0.42, 8, true), M.woodFurn, M4.chain(TR(HX + s * 0.11, TY + 0.2, HZ + 0.06), M4.rotZ(s * 0.28))));
    add(G.box(0.34, 0.02, 0.12), M.woodFurn, TR(HX, TY + 0.01, HZ + 0.04));
    /* font cards fanned in a holder */
    const FONTS = ["script", "serif", "sans", "hand", "mono"];
    const FX = 0.08, FY = TY + 0.03, FZ = TZ + 0.12;
    add(G.box(0.78, 0.04, 0.12), M.woodFurn, TR(FX, TY + 0.02, FZ - 0.02));
    const fontCards = FONTS.map((k, i) => {
      const grp = { m: M4.ident() };
      const mat = c.MAT({ map: T.mat, rough: 0.7, env: 0.1, emis: [0.06, 0.055, 0.055], emisMap: 1, color: [0.86, 0.84, 0.84] });
      const it = add(G.hangCard(0.17, 0.23), mat, M4.chain(M4.trans(0, 0.23, 0), M4.ident()), { group: grp });
      add(G.card(0.2, 0.26), M.shadowSoft(0.2), M4.chain(M4.trans(0.01, 0.11, -0.006)), { group: grp });
      return { key: k, i, grp, it, mat, lift: 0, liftT: 0, ang: (i - 2) * 0.1 };
    });
    /* thread spools on a tiered stand */
    const THREADS = { ballet: "#efb3c3", baby: "#f7d3dc", rose: "#e58fa3", burgundy: "#6e2135", chocolate: "#4f2b1f", cream: "#f3e9d2", white: "#ffffff", black: "#1d1517", sage: "#9fb39a" };
    const SX = 1.0, SZ = TZ + 0.08;
    [0, 1, 2].forEach((r) => add(G.box(0.62, 0.03 + r * 0.06, 0.13), M.woodFurn, TR(SX, TY + (0.03 + r * 0.06) / 2, SZ - r * 0.13)));
    const spools = Object.keys(THREADS).map((k, i) => {
      const row = Math.floor(i / 3), col = i % 3;
      const base = at(SX + (col - 1) * 0.19, TY + 0.03 + row * 0.06, SZ - row * 0.13);
      const grp = { m: M4.trans(base[0], base[1], base[2]) };
      const tmat = c.MAT({ map: c.tex(c.TX.thread(THREADS[k])), rough: 0.55, env: 0.25 });
      add(G.cyl(0.036, 0.075, 24, false), tmat, M4.trans(0, 0.05, 0), { group: grp });
      [0.011, 0.089].forEach((y) => add(G.cyl(0.046, 0.012, 24, true), M.woodFurn, M4.trans(0, y, 0), { group: grp }));
      add(G.cyl(0.008, 0.11, 8, true), M.woodFurn, M4.trans(0, 0.06, 0), { group: grp });
      const glow = add(G.card(0.26, 0.26), M.glow(lin(THREADS[k]), 0), M4.trans(0, 0.06, 0.05), { group: grp });
      return { key: k, base, grp, glow, lift: 0, liftT: 0 };
    });
    /* a pincushion and a little vase of flowers make it lived-in */
    add(G.lathe([[0, 0], [0.06, 0.0], [0.07, 0.03], [0.05, 0.06], [0, 0.07]], 24), M.velvetBlush, TR(-0.56, TY, TZ + 0.28));
    add(G.lathe([[0, 0], [0.05, 0], [0.06, 0.06], [0.035, 0.16], [0.04, 0.2], [0, 0.2]], 24), M.lacquer, TR(-1.42, TY, TZ - 0.32));
    [[0, 0.33, 0], [0.05, 0.3, 0.02], [-0.04, 0.31, -0.02]].forEach(([x, y, z], i) => add(G.lathe([[0, -0.04], [0.035, -0.02], [0.04, 0.01], [0, 0.035]], 12), c.MAT({ color: lin(i % 2 ? "#f3b9c8" : "#fbe2e8"), rough: 0.8 }), TR(-1.42 + x, TY + y, TZ - 0.32 + z)));

    const L = [
      { p: at(0, 3.2, -2.6), c: lin("#ffe1c8", 2.2), r: 5.5, prio: 4 },
      { p: at(-2.9, 2.6, -2.6), c: lin("#fff4ea", 2.0), r: 5 },
      { p: at(2.9, 2.6, -2.6), c: lin("#fff4ea", 2.0), r: 5 },
      { p: at(0, 1.9, 0.4), c: lin("#ffe6d6", 1.7), r: 4.2, prio: 3 },
      { p: at(0, 3.3, 2.5), c: lin("#ffe3d0", 1.6), r: 6 },
      { p: at(-1.0, 1.7, -0.6), c: lin("#ffead8", 0.9), r: 2.2 },
      { p: at(1.0, 1.7, -0.6), c: lin("#ffead8", 0.9), r: 2.2 }
    ];

    /* dynamic textures */
    const st = { thread: "burgundy", font: "script", hoverFont: null, hoverSpool: null, boardKey: "", hoopKey: "", fontDrawn: false };
    async function drawBoard(spec, tint) {
      const isPhoto = spec && typeof spec === "object" && spec.photo;
      const key = (isPhoto ? "photo:" + spec.photo : String(spec).length + ":" + String(spec).slice(-120)) + tint;
      if (key === st.boardKey) return;
      st.boardKey = key;
      const W = c.lite ? 900 : 1300, H = Math.round(W * BH / BW);
      if (isPhoto) {
        /* the real garment photograph, mounted on the board */
        try {
          const cv = c.cnv(W, H), x = cv.getContext("2d"), s = W / 768, pad = 44 * s;
          x.fillStyle = "#fbf6ee"; x.fillRect(0, 0, W, H);
          const img = await c.loadImg(spec.photo);
          c.drawCover(x, img, pad, pad, W - pad * 2, H - pad * 2);
          x.strokeStyle = "rgba(184,149,90,.55)"; x.lineWidth = 2.5 * s; x.strokeRect(pad, pad, W - pad * 2, H - pad * 2);
          if (st.boardKey === key) { c.retex(board, cv); c.wake(); }
          return;
        } catch (e) {
          console.warn("[LBN] board photo failed, drawing instead:", e && e.message);
        }
      }
      const cv = await K.plateCanvas({ svg: isPhoto ? null : spec, tint, mark: true }, W, H);
      if (st.boardKey === key) c.retex(board, cv);
    }
    async function drawHoop(svg, base) {
      const key = svg.length + ":" + svg.slice(-120) + base; if (key === st.hoopKey) return; st.hoopKey = key;
      const S = c.lite ? 640 : 1024, cv = c.cnv(S, S), x = cv.getContext("2d");
      x.drawImage(c.TX.weave(base || "#fbf3ef"), 0, 0, S, S);
      try { const a = await c.artCanvas(svg, Math.round(S * 1.25)); c.drawCover(x, a.c, 0, 0, S, S); } catch (e) {}
      const g = x.createRadialGradient(S / 2, S / 2, S * 0.3, S / 2, S / 2, S * 0.52); g.addColorStop(0, "rgba(0,0,0,0)"); g.addColorStop(1, "rgba(80,40,40,.22)");
      x.fillStyle = g; x.fillRect(0, 0, S, S);
      if (st.hoopKey === key) c.retex(hoop, cv);
    }
    const FONT_CSS = { script: "'Pinyon Script','Aref Ruqaa',cursive", serif: "'Gilda Display','El Messiri',serif", sans: "'Quicksand','Alexandria',sans-serif", hand: "'Caveat','Aref Ruqaa',cursive", mono: "'Gilda Display','El Messiri',serif" };
    function drawFontCards(labels, sample) {
      fontCards.forEach((fc) => {
        const Wc = 340, Hc = 460, cv = c.cnv(Wc, Hc), x = cv.getContext("2d");
        x.drawImage(c.TX.mat("#fbf6ee", Wc, Hc), 0, 0);
        x.strokeStyle = "rgba(184,149,90,.7)"; x.lineWidth = 3; x.strokeRect(14, 14, Wc - 28, Hc - 28);
        x.fillStyle = "#6e2135"; x.textAlign = "center"; x.textBaseline = "middle";
        const txt = fc.key === "mono" ? "M.a" : (sample || "Aa");
        let size = 150; x.font = `${size}px ${FONT_CSS[fc.key]}`;
        while (x.measureText(txt).width > Wc - 60 && size > 40) { size -= 8; x.font = `${size}px ${FONT_CSS[fc.key]}`; }
        x.fillText(txt, Wc / 2, Hc * 0.44);
        x.font = `600 26px 'Quicksand','Alexandria',sans-serif`; x.fillStyle = "#7a5d64";
        x.fillText((labels && labels[fc.key]) || fc.key, Wc / 2, Hc - 70);
        c.retex(fc.it, cv);
      });
    }

    function shotOf(name) {
      switch (name) {
        case "piece": return { pos: at(0, 2.0, 0.85), tgt: at(0, 1.98, -3.5), fov: 42 };
        case "place": return { pos: at(0, 2.0, -0.05), tgt: at(0, 1.98, -3.5), fov: 38 };
        case "text": return { pos: at(HX, HY + 0.12, HZ + 0.9), tgt: at(HX, HY - 0.02, HZ - 0.05), fov: 40 };
        case "font": return { pos: at(FX, TY + 0.5, FZ + 1.3), tgt: at(FX, TY + 0.2, FZ - 0.05), fov: 40 };
        case "thread": return { pos: at(SX, TY + 0.42, SZ + 0.75), tgt: at(SX, TY + 0.1, SZ - 0.12), fov: 40 };
        case "hero": { const p = c.st.progress; return { pos: at(lerp(-0.6, 0.6, p), 1.75, 3.2 - p * 0.6), tgt: at(lerp(-0.4, 0.3, p), 1.4, -2.2), fov: 50 }; }
        default: return { pos: at(0, 1.8, 3.3), tgt: at(0, 1.42, -2.2), fov: 50 };
      }
    }
    const room = {
      env: () => K.env({ sky: [0.4, 0.33, 0.31], gnd: [0.14, 0.1, 0.09], keyCol: [0.22, 0.2, 0.18], expo: 1.02 }),
      lights: () => L,
      camera(shot) { const s = shotOf(shot); return K.compose(s.pos, s.tgt, s.fov, shot === "hero" ? 0 : 1); },
      update(dt) {
        let anim = false;
        fontCards.forEach((fc) => {
          fc.liftT = fc.key === st.font ? 1 : fc.key === st.hoverFont ? 0.5 : 0;
          const l0 = fc.lift; fc.lift = c.damp(fc.lift, fc.liftT, 8, dt); if (Math.abs(l0 - fc.lift) > 0.001) anim = true;
          // a fanned row: each card sits side by side so every font can be seen and picked
          const ox = (fc.i - 2) * 0.135, oz = -Math.abs(fc.i - 2) * 0.03;
          fc.grp.m = M4.chain(TR(FX + ox, FY + fc.lift * 0.045 - Math.abs(fc.i - 2) * 0.012, FZ + oz), M4.rotZ(-fc.ang), M4.rotX(-0.18), M4.trans(0, 0, fc.i * 0.002));
          fc.mat.emis = [0.06 + fc.lift * 0.08, 0.055 + fc.lift * 0.07, 0.055 + fc.lift * 0.07];
        });
        spools.forEach((sp) => {
          sp.liftT = sp.key === st.thread ? 1 : sp.key === st.hoverSpool ? 0.5 : 0;
          const l0 = sp.lift; sp.lift = c.damp(sp.lift, sp.liftT, 8, dt); if (Math.abs(l0 - sp.lift) > 0.001) anim = true;
          sp.grp.m = M4.chain(M4.trans(sp.base[0], sp.base[1] + sp.lift * 0.035, sp.base[2]), M4.rotY(sp.lift * 0.6));
          sp.glow.mat.opacity = sp.lift * 0.5;
        });
        return anim;
      },
      pick(r) {
        let best = null; const keep = (h) => { if (h && (!best || h.t < best.t)) best = h; };
        spools.forEach((sp) => { const h = c.hitSphere(r, V.add(sp.base, [0, 0.06 + sp.lift * 0.035, 0]), 0.07); if (h) keep({ t: h.t, type: "thread", key: sp.key }); });
        fontCards.forEach((fc) => { const h = c.hitRect(r, c.worldOf(fc.it), 0.09, 0.12, 0, -0.115); if (h) keep({ t: h.t, type: "font", key: fc.key }); });
        const hb = c.hitRect(r, boardM, BW / 2, BH / 2); if (hb) keep({ t: hb.t, type: "board" });
        const hh = c.hitSphere(r, at(HX, HY, HZ), HR); if (hh) keep({ t: hh.t, type: "hoop" });
        return best;
      },
      hover(h) { st.hoverFont = h && h.type === "font" ? h.key : null; st.hoverSpool = h && h.type === "thread" ? h.key : null; c.wake(600); },
      onEnter() { c.st.veilColor = lin("#fbf8ef"); },
      /* API */
      set(o) {
        if (o.thread) st.thread = o.thread;
        if (o.font) st.font = o.font;
        if (o.board) drawBoard(o.board, o.tint || "#f4cdd8");
        if (o.hoop) drawHoop(o.hoop, o.base);
        if (o.labels && (!st.fontDrawn || o.sample !== st.sample)) { st.fontDrawn = true; st.sample = o.sample; drawFontCards(o.labels, o.sample); }
        c.wake(1200);
      },
      redrawFonts(labels, sample) { drawFontCards(labels, sample); }
    };
    return room;
  };

  /* ================================================================= MIX */
  W3.rooms.mix = function (c) {
    const { V, M4, G, D2R, clamp, lerp, lin } = c;
    const K = kit(c), R = "mix", M = c.M, O = [80, 0, 0];
    const at = (x, y, z) => [O[0] + x, O[1] + y, O[2] + z];
    const add = (g, m, model, ex) => c.add(R, g, m, model, ex);
    const TR = (x, y, z) => M4.trans(O[0] + x, y, O[2] + z);
    const H = 4.0, LZ = -1.55, WALLZ = -3.2;
    K.shell(R, { x0: O[0] - 6, x1: O[0] + 6, z0: WALLZ, z1: 4.6, h: H, floor: M.wood, back: { upper: c.MAT({ map: c.tex(c.TX.wallpaper("#fbeaf0", "#f8dfe7", "rgba(184,149,90,.3)")), uv: [1 / 0.62, 1 / 0.62], rough: 0.8, env: 0.12 }) } });
    /* the posts and the two lines */
    const PX = 4.7;
    [-1, 1].forEach((s) => {
      add(G.cyl(0.05, 3.25, 20, true, 0.04), M.woodFurn, TR(s * PX, 3.25 / 2, LZ));
      add(G.cyl(0.13, 0.05, 24, true), M.woodFurn, TR(s * PX, 0.025, LZ));
      add(G.lathe([[0, 0], [0.05, 0], [0.065, 0.05], [0.03, 0.12], [0, 0.16]], 20), M.gold, TR(s * PX, 3.25, LZ));
      add(G.card(0.7, 0.7), M.shadowDisc(0.35), M4.chain(TR(s * PX, 0.005, LZ), M4.rotX(-Math.PI / 2)));
    });
    const LINES = { top: { y: 2.92, sag: 0.13, space: 1.2 }, bottom: { y: 1.86, sag: 0.1, space: 1.05 } };
    const ropeY = (ln, x) => ln.y - ln.sag * (1 - Math.pow(x / PX, 2));
    const cord = c.MAT({ color: lin("#efe2cf"), rough: 0.85, env: 0.1 });
    Object.values(LINES).forEach((ln) => {
      const pts = []; for (let k = 0; k <= 48; k++) { const x = -PX + (k / 48) * PX * 2; pts.push(at(x, ropeY(ln, x), LZ)); }
      add(G.tube(pts, 0.007, 6), cord);
    });
    add(G.card(9.6, 3.0), M.glow(lin("#ffe6dc"), 0.1), TR(0, 2.2, WALLZ + 0.02));
    /* a velvet ottoman and a slipper chair for the room */
    add(G.softBox(1.1, 0.42, 0.6, 0.12, 3), M.velvetBlush, TR(-3.2, 0.21, 1.2));
    add(G.card(1.6, 1.1), M.shadowSoft(0.4), M4.chain(TR(-3.2, 0.004, 1.2), M4.rotX(-Math.PI / 2)));
    add(G.disc(2.6, 72), M.rug, M4.chain(TR(0, 0.006, 0.2), M4.rotX(-Math.PI / 2), M4.scale(1.6, 1, 1)));

    const L = [
      { p: at(0, 3.5, 0.6), c: lin("#ffe6d6", 2.6), r: 7, prio: 4 },
      { p: at(-3, 3.2, 0), c: lin("#ffe9da", 1.4), r: 5.5 },
      { p: at(3, 3.2, 0), c: lin("#ffe9da", 1.4), r: 5.5 },
      { p: at(0, 2.6, 0.2), c: lin("#fff0e4", 1.8), r: 3.2, prio: 3 },
      { p: at(0, 1.6, 0.4), c: lin("#fff0e4", 1.4), r: 3.0, prio: 2 }
    ];
    /* hanging pieces */
    const st = { top: { list: [], idx: 0, off: 0, vel: 0, sel: false, hover: -1 }, bottom: { list: [], idx: 0, off: 0, vel: 0, sel: false, hover: -1 } };
    const pegMat = c.MAT({ color: lin("#d8b48a"), rough: 0.5, env: 0.3 });
    function build(which, list) {
      const s = st[which];
      s.list.forEach((p) => p.parts.forEach((it) => c.removeItem(it)));
      s.list = list.map((d, i) => {
        const grp = { m: M4.ident() }, parts = [];
        const mat = c.MAT({ map: null, alphaMap: true, rough: 0.8, env: 0.05, emis: [0.07, 0.065, 0.065], emisMap: 1, color: [0.85, 0.83, 0.83], opacity: 0 });
        const piece = { d, i, grp, mat, theta: 0, omega: 0, w: which === "top" ? 0.74 : 0.56, h: 0.7, ready: false, parts, x: 0, a: 1, lift: 0 };
        const card = add(G.hangCard(1, 1), mat, M4.ident(), { group: grp, sortBias: 0.2 }); parts.push(card); piece.card = card;
        /* slim brass clips, not bulky black pegs */
        [-1, 1].forEach((sg) => {
          parts.push(add(G.box(0.009, 0.036, 0.008), pegMat, M4.trans(sg * 0.17, 0.004, 0.011), { group: grp }));
          parts.push(add(G.torus(0.016, 0.0035, 20, 8), pegMat, M4.chain(M4.trans(sg * 0.17, 0.03, 0.011), M4.rotX(Math.PI / 2)), { group: grp }));
        });
        const sh = add(G.card(1, 1), c.M.shadowSoft(0), M4.ident(), { sortBias: -1 }); parts.push(sh); piece.shadow = sh;
        if (d.photo) {
          /* a real photograph of the piece, printed onto the hanging card */
          mat.alphaMap = false; mat.opacity = 1;
          piece.h = piece.w * 1.25;
          K.plateTexture({ key: d.key, photo: d.photo, tint: d.tint }).then((t) => {
            mat.map = t; piece.ready = true; c.wake(1200);
          });
          card.model = M4.scale(piece.w, piece.h, 1);
        } else {
          K.spriteTexture(d.key, d.svg).then(({ t, aspect }) => {
            mat.map = t; piece.h = piece.w * aspect; piece.ready = true;
            card.model = M4.scale(piece.w, piece.h, 1); c.wake(1200);
          });
        }
        return piece;
      });
      s.idx = clamp(s.idx, 0, Math.max(0, list.length - 1)); s.off = s.idx; s.vel = 0;
    }
    function layoutLine(which, dt) {
      const s = st[which], ln = LINES[which];
      let anim = false;
      const off0 = s.off;
      const target = s.idx;
      // critically damped slide
      const acc = 0;
      s.off = target; s.vel = 0;   /* no sliding: the line snaps to the chosen piece */
      const lineAcc = dt > 0 ? acc * ln.space : 0;
      s.list.forEach((p) => {
        const x = (p.i - s.off) * ln.space;
        p.x = x;
        const vis = clamp((PX - 0.35 - Math.abs(x)) / 0.6, 0, 1);
        // pendulum: the line's acceleration swings each piece
        const w2 = 22, c2 = 3.2;
        p.omega += (-w2 * p.theta - c2 * p.omega - lineAcc * 0.11) * dt; p.theta += p.omega * dt;
        if (Math.abs(p.theta) > 0.0005 || Math.abs(p.omega) > 0.0005) anim = true;
        const selected = p.i === s.idx, hl = selected ? 1 : p.i === s.hover ? 0.5 : 0;
        const l0 = p.lift; p.lift = c.damp(p.lift, hl, 7, dt); if (Math.abs(l0 - p.lift) > 0.001) anim = true;
        const y = ropeY(ln, clamp(x, -PX, PX)) + 0.01;
        p.grp.m = M4.chain(TR(x, y, LZ), M4.rotZ(p.theta), M4.trans(0, -0.02, 0));
        p.mat.opacity = p.ready ? vis : 0;
        const dim = s.sel ? lerp(0.62, 1, p.lift) : lerp(0.82, 1, p.lift);
        p.mat.color = [0.85 * dim, 0.83 * dim, 0.83 * dim];
        p.mat.emis = [0.05 + p.lift * 0.06, 0.047 + p.lift * 0.055, 0.047 + p.lift * 0.055];
        p.parts.forEach((it) => { if (it !== p.shadow && it !== p.card) it.visible = vis > 0.05; });
        // soft shadow cast on the wall behind
        p.shadow.model = M4.chain(TR(x + 0.08 + p.theta * 0.3, y - 0.06 - p.h * 0.55, WALLZ + 0.015), M4.scale(p.w * 1.35, p.h * 1.25, 1));
        p.shadow.mat.opacity = p.ready ? 0.26 * vis : 0;
      });
      if (Math.abs(off0 - s.off) > 1e-5) anim = true;
      return anim;
    }
    function shotOf(name) {
      const p = c.st.progress;
      switch (name) {
        case "top": return { pos: at(0, 2.55, 1.85), tgt: at(0, 2.42, LZ - 0.2), fov: 44 };
        case "bottom": return { pos: at(0, 1.45, 1.85), tgt: at(0, 1.3, LZ - 0.2), fov: 46 };
        case "hero": return { pos: at(lerp(-0.8, 0.8, p), 2.1, 4.4), tgt: at(lerp(-0.3, 0.3, p), 1.95, -2), fov: 50 };
        default: return { pos: at(0, 2.05, 4.5), tgt: at(0, 1.95, -2), fov: 50 };
      }
    }
    const room = {
      env: () => K.env({ sky: [0.4, 0.33, 0.31], gnd: [0.15, 0.1, 0.1], keyCol: [0.2, 0.17, 0.15], expo: 1.02 }),
      lights: () => L,
      camera(shot) { const s = shotOf(shot); return K.compose(s.pos, s.tgt, s.fov, shot === "hero" ? 0 : 1); },
      update(dt) { const a = layoutLine("top", dt), b = layoutLine("bottom", dt); return a || b; },
      pick(r) {
        let best = null;
        ["top", "bottom"].forEach((w) => st[w].list.forEach((p) => {
          if (!p.ready || p.mat.opacity < 0.3) return;
          const h = c.hitRect(r, M4.mul(p.grp.m, M4.trans(0, -p.h / 2, 0)), p.w / 2, p.h / 2);
          if (h && (!best || h.t < best.t)) best = { t: h.t, type: w, index: p.i, key: p.d.id };
        }));
        return best;
      },
      hover(h) { st.top.hover = h && h.type === "top" ? h.index : -1; st.bottom.hover = h && h.type === "bottom" ? h.index : -1; c.wake(600); },
      onEnter() { c.st.veilColor = lin("#fbf8ef"); },
      /* API: lines of {key, id, svg} */
      setLine(which, list, idx, selected) {
        const s = st[which];
        const sig = list.map((d) => d.key).join("|");
        if (s.sig !== sig) { s.sig = sig; s.idx = idx || 0; build(which, list); }
        if (idx != null && idx !== s.idx) s.idx = clamp(idx, 0, Math.max(0, list.length - 1));
        s.sel = !!selected; c.wake(1500);
      },
      slide(which, idx) { const s = st[which]; s.idx = clamp(idx, 0, Math.max(0, s.list.length - 1)); c.wake(1500); },
      index: (which) => st[which].idx
    };
    return room;
  };

  /* =============================================================== GIFTS */
  W3.rooms.gifts = function (c) {
    const { V, M4, G, D2R, clamp, lerp, lin } = c;
    const K = kit(c), R = "gifts", M = c.M, O = [120, 0, 0];
    const at = (x, y, z) => [O[0] + x, O[1] + y, O[2] + z];
    const add = (g, m, model, ex) => c.add(R, g, m, model, ex);
    const TR = (x, y, z) => M4.trans(O[0] + x, y, O[2] + z);
    const H = 4.0, WALLZ = -3.6;
    K.shell(R, { x0: O[0] - 5.6, x1: O[0] + 5.6, z0: WALLZ, z1: 4.6, h: H, floor: M.marble, back: { panels: false } });
    /* three shallow arched niches behind the pedestals */
    [-2.6, 0, 2.6].forEach((x) => {
      const m = M4.basis(at(x, 0.95, WALLZ + 0.01), [1, 0, 0], [0, 1, 0], [0, 0, 1]);
      const ap = c.archPath(1.6, 1.4, 36, 0);
      add(G.fan(ap, 0.004, (u, v) => [(u + 0.8) / 1.6, v / 2.2]), M.alcove, m);
      add(G.sweep(ap, false, c.PROF.casing.map(([o, z]) => [o * 0.7, z * 0.7]), -1), M.moulding, m);
      add(G.sweep(ap, false, c.PROF.bead.map(([o, z]) => [o - 0.01, z - 0.01]), -1), M.gold, m);
    });
    add(G.disc(3.4, 96), M.rug, M4.chain(TR(0, 0.006, -0.6), M4.rotX(-Math.PI / 2)));
    const BOXES = [];
    const ARC = [-42, -14, 14, 42], C0 = [0, 0, 1.0], RAD = 3.1;
    const ribbon = c.MAT({ color: lin("#6e2135"), rough: 0.45, env: 0.45 });
    const ribbonGold = c.MAT({ color: [0.78, 0.5, 0.22], rough: 0.3, metal: 1, env: 1.0 });
    ARC.forEach((deg, i) => {
      const a = deg * D2R, px = C0[0] + Math.sin(a) * RAD, pz = C0[2] - Math.cos(a) * RAD;
      const base = at(px, 0, pz), yaw = -a * 0.85;
      const P = M4.chain(M4.trans(base[0], 0, base[2]), M4.rotY(yaw));
      add(G.cyl(0.36, 0.92, 32, false), M.lacquer, M4.mul(P, M4.trans(0, 0.46, 0)));
      add(G.cyl(0.42, 0.06, 32, true), M.marble, M4.mul(P, M4.trans(0, 0.95, 0)));
      add(G.cyl(0.4, 0.06, 32, true), M.marble, M4.mul(P, M4.trans(0, 0.03, 0)));
      add(G.cyl(0.365, 0.02, 32, false), M.goldSoft, M4.mul(P, M4.trans(0, 0.85, 0)));
      add(G.card(1.3, 1.3), M.shadowDisc(0.4), M4.chain(TR(px, 0.005, pz), M4.rotX(-Math.PI / 2)));
      const boxGrp = { m: M4.ident() }, lidGrp = { m: M4.ident() }, fanGrp = { m: M4.ident() };
      const paper = c.MAT({ map: c.T.mat, rough: 0.55, env: 0.25 });
      const BW = 0.5, BH = 0.32;
      add(G.box(BW, BH, BW), paper, M4.trans(0, BH / 2, 0), { group: boxGrp });
      add(G.box(BW + 0.004, BH + 0.002, 0.05), ribbon, M4.trans(0, BH / 2, 0), { group: boxGrp });
      add(G.box(0.05, BH + 0.002, BW + 0.004), ribbon, M4.trans(0, BH / 2, 0), { group: boxGrp });
      const lidPaper = c.MAT({ map: c.T.mat, rough: 0.55, env: 0.25 });
      add(G.box(BW + 0.04, 0.08, BW + 0.04), lidPaper, M4.trans(0, 0.04, 0), { group: lidGrp });
      add(G.box(BW + 0.044, 0.082, 0.05), ribbon, M4.trans(0, 0.04, 0), { group: lidGrp });
      add(G.box(0.05, 0.082, BW + 0.044), ribbon, M4.trans(0, 0.04, 0), { group: lidGrp });
      [-1, 1].forEach((s) => add(G.torus(0.07, 0.016, 24, 8), ribbon, M4.chain(M4.trans(s * 0.07, 0.11, 0), M4.rotZ(s * 0.5), M4.scale(1, 0.55, 1), M4.rotX(Math.PI / 2)), { group: lidGrp }));
      add(G.box(0.05, 0.05, 0.05), ribbon, M4.trans(0, 0.105, 0), { group: lidGrp });
      [-1, 1].forEach((s) => add(G.box(0.035, 0.012, 0.16), ribbon, M4.chain(M4.trans(s * 0.04, 0.085, 0.08), M4.rotY(s * 0.4)), { group: lidGrp }));
      const glow = add(G.card(1.4, 1.4), M.glow(lin("#ffe4d4"), 0.0), M4.ident(), { group: fanGrp });
      BOXES.push({ i, base, P, yaw, px, pz, boxGrp, lidGrp, fanGrp, paper, lidPaper, cards: [], open: 0, openT: 0, hov: 0, glow, top: 0.98 });
    });
    const L = [
      { p: at(0, 3.4, 0.5), c: lin("#ffe2cc", 2.4), r: 7.5, prio: 4 },
      ...BOXES.map((b) => ({ p: [b.base[0], 2.5, b.base[2] + 0.6], c: lin("#ffe8d8", 1.5), r: 3.0 })),
      { p: at(0, 2.2, 3), c: lin("#ffe3d0", 1.4), r: 6 }
    ];
    const st = { sel: -1, hover: -1, data: [] };
    async function dress(b, d) {
      const pc = c.cnv(512, 512); pc.getContext("2d").drawImage(c.TX.giftPaper(d.color, d.accent), 0, 0);
      c.retex({ mat: b.paper }, pc);
      const lc = c.cnv(512, 512); lc.getContext("2d").drawImage(c.TX.giftPaper(d.color, d.accent), 0, 0);
      c.retex({ mat: b.lidPaper }, lc);
      b.cards.forEach((it) => c.removeItem(it)); b.cards = [];
      const n = d.items.length;
      d.items.forEach((item, j) => {
        const grp = { m: M4.ident() };
        const mat = c.MAT({ map: c.T.mat, rough: 0.7, env: 0.1, emis: [0.08, 0.075, 0.075], emisMap: 1, color: [0.85, 0.83, 0.83], opacity: 0 });
        const it = add(G.card(0.3, 0.4), mat, M4.trans(0, 0.2, 0), { group: grp, sortBias: j * 0.01 });
        it._fan = { j, n, grp }; b.cards.push(it);
        K.plateTexture(item).then((t) => { mat.map = t; c.wake(); });
      });
    }
    function shotOf(name, p) {
      const i = p && p.index != null ? p.index : st.sel;
      if ((name === "box" || name === "open") && BOXES[i]) {
        const b = BOXES[i];
        const toCam = V.norm([b.px * 0.25, 0, 1.0]);
        const up = name === "open" ? 1.55 : 1.35;
        const pos = V.add(at(b.px, up, b.pz), V.mul(toCam, name === "open" ? 2.0 : 1.75));
        return { pos, tgt: at(b.px, name === "open" ? 1.32 : 1.1, b.pz), fov: 44 };
      }
      if (name === "hero") { const q = c.st.progress; return { pos: at(lerp(-1, 1, q), 1.85, 4.4), tgt: at(lerp(-0.4, 0.4, q), 1.05, -1.0), fov: 50 }; }
      return { pos: at(0, 1.85, 4.5), tgt: at(0, 1.05, -1.0), fov: 50 };
    }
    const room = {
      env: () => K.env({ sky: [0.38, 0.3, 0.29], gnd: [0.14, 0.1, 0.1], keyCol: [0.16, 0.13, 0.11], expo: 1.02 }),
      lights: () => L,
      camera(shot, p) { const s = shotOf(shot, p); return K.compose(s.pos, s.tgt, s.fov, shot === "hero" ? 0 : 1); },
      update(dt) {
        let anim = false;
        const t = c.st.t;
        BOXES.forEach((b) => {
          b.openT = b.i === st.sel && st.open ? 1 : 0;
          b.open = b.openT;   /* the lid is up or down, never in between */
          const h0 = b.hov; b.hov = c.damp(b.hov, b.i === st.hover || b.i === st.sel ? 1 : 0, 8, dt); if (Math.abs(h0 - b.hov) > 0.001) anim = true;
          const bob = Math.sin(t * 1.3 + b.i) * 0.006 * (c.st.reduce ? 0 : 1);
          const spin = b.yaw + Math.sin(t * 0.4 + b.i * 2) * 0.05 + b.hov * 0.25;
          const B = M4.chain(M4.trans(b.base[0], b.top + bob + b.hov * 0.02, b.base[2]), M4.rotY(spin));
          b.boxGrp.m = B;
          const o = c.easeInOutCubic(clamp(b.open, 0, 1));
          b.lidGrp.m = M4.chain(B, M4.trans(-0.27 * o, 0.32 + o * 0.42, -0.1 * o), M4.rotZ(o * 0.55), M4.rotX(-o * 0.25));
          b.fanGrp.m = M4.chain(M4.trans(b.base[0], b.top + 0.3, b.base[2]), M4.rotY(b.yaw * 0.5));
          b.glow.mat.opacity = 0.25 * o;
          b.cards.forEach((it) => {
            const { j, n } = it._fan, spread = (j - (n - 1) / 2) * 0.42;
            const rise = c.easeOutBack(clamp(o * 1.2 - j * 0.08, 0, 1));
            it.group = b.fanGrp;
            it.model = M4.chain(M4.trans(0, 0.05 + rise * 0.12, 0.02 + j * 0.01), M4.rotZ(-spread * rise), M4.trans(0, rise * 0.06, 0), M4.scale(0.2 + 0.8 * rise));
            it.mat.opacity = clamp(rise * 1.4, 0, 1);
          });
        });
        if (!c.st.reduce) anim = true; // the boxes breathe gently
        return anim;
      },
      pick(r) {
        let best = null;
        BOXES.forEach((b) => { if (b.i >= st.data.length) return; const h = c.hitSphere(r, [b.base[0], b.top + 0.2, b.base[2]], 0.42); if (h && (!best || h.t < best.t)) best = { t: h.t, type: "gift", index: b.i }; });
        return best;
      },
      hover(h) { st.hover = h && h.type === "gift" ? h.index : -1; c.wake(600); },
      onEnter() { c.st.veilColor = lin("#fbf8ef"); },
      /* API: [{key,color,accent,items:[{key,svg,tint}]}] */
      setGifts(list) {
        const sig = list.map((d) => d.key).join("|"); if (st.sig === sig) return; st.sig = sig; st.data = list;
        BOXES.forEach((b, i) => { const d = list[i]; b.boxGrp.hidden = !d; if (d) dress(b, d); });
        items_visible(); c.wake(1500);
      },
      select(i, open) { st.sel = i; st.open = !!open; c.wake(2500); },
      count: () => st.data.length
    };
    function items_visible() { c.items.forEach((it) => { if (it.room !== R) return; const b = BOXES.find((x) => it.group === x.boxGrp || it.group === x.lidGrp); if (b) it.visible = b.i < st.data.length; }); }
    return room;
  };

  /* ============================================================= GALLERY */
  W3.rooms.gallery = function (c) {
    const { V, M4, G, D2R, clamp, lerp, lin } = c;
    const K = kit(c), R = "gallery", M = c.M, O = [160, 0, 0];
    const at = (x, y, z) => [O[0] + x, O[1] + y, O[2] + z];
    const add = (g, m, model, ex) => c.add(R, g, m, model, ex);
    const TR = (x, y, z) => M4.trans(O[0] + x, y, O[2] + z);
    const HW = 2.3, H = 4.2, Z0 = 3, Z1 = -31;
    K.wall(R, M4.basis(at(-HW, 0, Z0), [0, 0, -1], [0, 1, 0], [1, 0, 0]), Z0 - Z1, H, {});
    K.wall(R, M4.basis(at(HW, 0, Z1), [0, 0, 1], [0, 1, 0], [-1, 0, 0]), Z0 - Z1, H, {});
    K.wall(R, M4.basis(at(-HW, 0, Z1), [1, 0, 0], [0, 1, 0], [0, 0, 1]), HW * 2, H, { panels: false });
    K.wall(R, M4.basis(at(HW, 0, Z0), [-1, 0, 0], [0, 1, 0], [0, 0, -1]), HW * 2, H, { panels: false });
    K.flat(R, O[0] - HW, Z1, O[0] + HW, Z0, 0, M.marble);
    K.flat(R, O[0] - HW, Z1, O[0] + HW, Z0, H, M.ceiling, true);
    const runner = c.MAT({ map: c.tex(c.TX.runner(), { clamp: true }), rough: 0.95, env: 0.04 });
    add(G.card(1.6, (Z0 - Z1) - 2), runner, M4.chain(TR(0, 0.006, (Z0 + Z1) / 2), M4.rotX(-Math.PI / 2)));
    /* arches across the corridor every 5 m, with skylights between */
    for (let z = 0; z >= -27; z -= 5) {
      const m = M4.basis(at(0, 0, z), [1, 0, 0], [0, 1, 0], [0, 0, 1]);
      const aw = HW * 2 - 0.5, spr = 3.0;
      add(G.wallWithArch(-HW, HW, 0, H, aw, 0, spr, 1, 40), M.plasterIn, m);
      add(G.wallWithArch(-HW, HW, 0, H, aw, 0, spr, 1, 40), M.plasterIn, M4.mul(m, M4.trans(0, 0, -0.3)));
      add(G.sweep(c.archPath(aw, spr, 40), false, [[0, 0], [0, -0.3]], -1), M.moulding, m);
      add(G.sweep(c.archPath(aw, spr, 40), false, c.PROF.bead.map(([o, zz]) => [o - 0.03, zz - 0.04]), -1), M.gold, m);
      add(G.disc(1.0, 48), M.skylight, M4.chain(TR(0, H - 0.01, z - 2.5), M4.rotX(Math.PI / 2)));
    }
    /* chapter panels alternate left and right; the last one ends the corridor */
    const SLOTS = [
      { side: -1, z: -3.6 }, { side: 1, z: -8.6 }, { side: -1, z: -13.6 }, { side: 1, z: -18.6 }, { side: -1, z: -23.6 }, { side: 0, z: Z1 + 0.02 }
    ];
    const PW = 1.5, PH = 2.0;
    const panels = SLOTS.map((s) => {
      const m = s.side === 0 ? M4.basis(at(0, 2.0, s.z), [1, 0, 0], [0, 1, 0], [0, 0, 1])
        : s.side < 0 ? M4.basis(at(-HW + 0.02, 1.95, s.z), [0, 0, -1], [0, 1, 0], [1, 0, 0]) : M4.basis(at(HW - 0.02, 1.95, s.z), [0, 0, 1], [0, 1, 0], [-1, 0, 0]);
      const it = K.plate(R, m, PW, PH, { emis: [0.07, 0.065, 0.062], color: [0.82, 0.8, 0.8] });
      K.pictureLight(R, M4.mul(m, M4.trans(0, PH / 2 + 0.12, 0)), 0.5);
      return { s, m, it };
    });
    add(c.crescentSolid(0.38, 0.05), M.gold, TR(0, 3.55, Z1 + 0.06));
    const L = [
      ...panels.map((p) => ({ p: M4.pt(p.m, [0, 0.6, 0.7]), c: lin("#ffe2cc", 1.7), r: 3.2 })),
      ...[0, -5, -10, -15, -20, -25].map((z) => ({ p: at(0, 3.6, z - 2.5), c: lin("#fff0e2", 1.6), r: 5.5 }))
    ];
    const st = { sig: "" };
    function walkZ(p) { return lerp(1.8, -26.5, p); }
    function shotOf(name) {
      const p = clamp(c.st.progress, 0, 1), z = walkZ(p);
      // look a little toward the panel we are passing
      let look = 0, best = 1e9;
      panels.forEach((pn) => { if (pn.s.side === 0) return; const d = Math.abs(pn.s.z - (z - 2.2)); if (d < best) { best = d; look = pn.s.side * clamp(1 - d / 3.2, 0, 1); } });
      const pos = at(-look * 0.35, 1.68, z), tgt = at(look * 1.8, 1.72, z - 4.2);
      if (name === "end") return { pos: at(0, 1.75, Z1 + 4.2), tgt: at(0, 2.0, Z1), fov: 50 };
      return { pos, tgt, fov: 54, k: 7.5 };
    }
    const room = {
      env: () => K.env({ sky: [0.38, 0.31, 0.3], gnd: [0.14, 0.1, 0.1], keyCol: [0.14, 0.12, 0.1], expo: 1.02, fog: [6, 30, 0, 0.38], fogCol: [0.72, 0.55, 0.55] }),
      lights: () => L,
      camera(shot) { const s = shotOf(shot); const r = K.compose(s.pos, s.tgt, s.fov, 0); r.k = s.k || 6.5; return r; },
      update: () => false,
      onEnter() { c.st.veilColor = lin("#fbf8ef"); },
      /* API: panel specs {key, photo|svg|draw} */
      setPanels(list) {
        const sig = list.map((d) => d.key).join("|"); if (sig === st.sig) return; st.sig = sig;
        list.forEach((d, i) => { const pn = panels[i]; if (!pn) return; K.plateCanvas(d, c.lite ? 768 : 1100, Math.round((c.lite ? 768 : 1100) * PH / PW)).then((cv) => c.retex(pn.it, cv)); });
      },
      chapterAt(p) { const z = walkZ(p) - 2.2; let best = 0, bd = 1e9; panels.forEach((pn, i) => { const d = Math.abs(pn.s.z - z); if (d < bd) { bd = d; best = i; } }); return best; }
    };
    return room;
  };

  /* ============================================================== LOUNGE */
  W3.rooms.lounge = function (c) {
    const { V, M4, G, D2R, clamp, lerp, lin } = c;
    const K = kit(c), R = "lounge", M = c.M, O = [200, 0, 0];
    const at = (x, y, z) => [O[0] + x, O[1] + y, O[2] + z];
    const add = (g, m, model, ex) => c.add(R, g, m, model, ex);
    const TR = (x, y, z) => M4.trans(O[0] + x, y, O[2] + z);
    const H = 4.0, WALLZ = -3.4;
    K.shell(R, { x0: O[0] - 6.2, x1: O[0] + 6.2, z0: WALLZ, z1: 4.8, h: H, floor: M.wood, back: { panels: false } });
    /* four arched bays of shelving */
    const BAYS = [-3.3, -1.1, 1.1, 3.3].map((x, i) => {
      const bw = 1.75, bh = 2.95, depth = 0.5, spr = bh - bw / 2;
      const m = M4.basis(at(x, 0.15, WALLZ + 0.02 + depth), [1, 0, 0], [0, 1, 0], [0, 0, 1]);
      /* the cabinet body around the arch */
      add(G.wallWithArch(-bw / 2 - 0.16, bw / 2 + 0.16, 0, bh + 0.25, bw, 0, spr, 1, 36), M.lacquer, m);
      [-1, 1].forEach((sd) => add(G.box(0.02, bh + 0.25, depth), M.lacquer, M4.mul(m, M4.trans(sd * (bw / 2 + 0.16), (bh + 0.25) / 2, -depth / 2))));
      add(G.box(bw + 0.4, 0.08, depth + 0.06), M.moulding, M4.mul(m, M4.trans(0, bh + 0.29, -depth / 2 + 0.03)));
      add(G.box(bw + 0.36, 0.15, depth + 0.02), M.moulding, M4.mul(m, M4.trans(0, -0.075, -depth / 2)));
      const ap = c.archPath(bw, spr, 36, 0);
      add(G.fan(ap, -depth + 0.02, (u, v) => [(u + bw / 2) / bw, v / bh]), M.alcove, m);
      add(G.sweep(ap, false, [[0, 0], [0, -depth]], -1), M.reveal, m);
      add(G.sweep(ap, false, c.PROF.casing.map(([o, z]) => [o * 0.8, z * 0.85]), -1), M.moulding, m);
      add(G.sweep(ap, false, c.PROF.bead.map(([o, z]) => [o - 0.008, z - 0.009]), -1), M.gold, m);
      const shelves = [0.32, 0.92, 1.52, 2.12];
      shelves.forEach((y) => add(G.box(bw - 0.04, 0.035, depth - 0.04), M.lacquer, M4.mul(m, M4.trans(0, y, -depth / 2))));
      add(G.box(0.22, 0.05, 0.012), M.gold, M4.mul(m, M4.trans(0, 0.24, 0.02)));
      add(G.card(1.6, 2.4), M.glow(lin("#ffe6d8"), 0.12), M4.mul(m, M4.trans(0, 2.0, -depth + 0.05)));
      return { i, x, m, bw, depth, shelves, stacks: [], hov: 0 };
    });
    add(G.disc(2.4, 72), M.rug, M4.chain(TR(0, 0.006, 0.8), M4.rotX(-Math.PI / 2), M4.scale(1.5, 1, 1)));
    /* a velvet bench, a side table and a floor lamp */
    add(G.softBox(1.6, 0.4, 0.55, 0.16, 3), M.velvet, TR(0, 0.38, 1.0));
    [[-0.7, -0.2], [0.7, -0.2], [-0.7, 0.2], [0.7, 0.2]].forEach(([x, z]) => add(G.cyl(0.02, 0.2, 8, true, 0.015), M.gold, TR(x, 0.1, 1.0 + z)));
    add(G.card(2.2, 1.2), M.shadowSoft(0.45), M4.chain(TR(0, 0.004, 1.0), M4.rotX(-Math.PI / 2)));
    add(G.cyl(0.014, 1.55, 10, true), M.gold, TR(-4.9, 0.78, 0.4));
    add(G.cyl(0.16, 0.02, 20, true), M.gold, TR(-4.9, 0.01, 0.4));
    add(G.cyl(0.22, 0.3, 24, false, 0.16), c.MAT({ color: lin("#fbeee6"), rough: 0.7, emis: [0.55, 0.42, 0.34] }), TR(-4.9, 1.65, 0.4));
    add(G.card(1.2, 1.2), M.glow(lin("#ffd6b0"), 0.28), TR(-4.9, 1.65, 0.6));
    const L = [
      { p: at(0, 3.4, 0.6), c: lin("#ffe2cc", 2.3), r: 7.5, prio: 4 },
      { p: at(-4.9, 1.7, 0.5), c: lin("#ffc890", 1.8), r: 4 },
      ...BAYS.map((b) => ({ p: at(b.x, 2.6, WALLZ + 0.9), c: lin("#ffe8d8", 1.5), r: 3.2 })),
      { p: at(0, 2.2, 3.4), c: lin("#ffe3d0", 1.2), r: 6 }
    ];
    const st = { sig: "", focus: -1, hover: -1 };
    function fill(bay, colors) {
      bay.stacks.forEach((it) => c.removeItem(it)); bay.stacks = [];
      const per = 2, cols = colors.length ? colors : ["#f4cdd8"];
      let k = 0;
      bay.shelves.forEach((y, si) => {
        for (let p = 0; p < per; p++) {
          const x = (p - (per - 1) / 2) * 0.62 + (si % 2 ? 0.08 : -0.06), n = 3 + ((si + p) % 2);
          for (let q = 0; q < n; q++) {
            const col = cols[(k++) % cols.length];
            const mat = c.MAT({ color: lin(col.base || col), rough: 0.88, env: 0.06 });
            const h = 0.055, w = 0.44 + ((q * 7) % 3) * 0.01;
            bay.stacks.push(add(G.softBox(w, h, 0.32, 0.03, 2), mat, M4.mul(bay.m, M4.chain(M4.trans(x + ((q * 13) % 5 - 2) * 0.006, y + 0.018 + h / 2 + q * h, -bay.depth / 2), M4.rotY(((q * 5) % 3 - 1) * 0.03)))));
            if (col.accent && q === n - 1) bay.stacks.push(add(G.box(w * 0.98, 0.006, 0.012), c.MAT({ color: lin(col.accent), rough: 0.6 }), M4.mul(bay.m, M4.trans(x, y + 0.018 + h * (q + 1) - 0.004, -bay.depth / 2 + 0.16))));
          }
        }
      });
    }
    function shotOf(name, p) {
      const q = c.st.progress;
      if (name === "bay") { const b = BAYS[(p && p.index) || 0]; return { pos: at(b.x, 1.6, 0.9), tgt: at(b.x, 1.45, WALLZ), fov: 46 }; }
      if (name === "bays") { const x = lerp(-3.3, 3.3, q); return { pos: at(x, 1.6, 1.1), tgt: at(x, 1.45, WALLZ), fov: 48, k: 6.5 }; }
      if (name === "reading") { const s = Math.sin(c.st.t * 0.05) * 0.4; return { pos: at(s, 1.7, 4.0), tgt: at(s * 0.5, 1.55, -2.4), fov: 52 }; }
      return { pos: at(0, 1.75, 4.2), tgt: at(0, 1.55, -2.4), fov: 52 };
    }
    const room = {
      env: () => K.env({ sky: [0.38, 0.31, 0.3], gnd: [0.14, 0.1, 0.1], keyCol: [0.14, 0.12, 0.1], expo: 1.02 }),
      lights: () => L,
      camera(shot, p) { const s = shotOf(shot, p); const r = K.compose(s.pos, s.tgt, s.fov, shot === "reading" || shot === "bays" ? 0 : 1); if (s.k) r.k = s.k; return r; },
      update: () => false,
      pick(r) {
        let best = null;
        BAYS.forEach((b) => { const h = c.hitRect(r, b.m, b.bw / 2, 1.5, 0, 1.5); if (h && (!best || h.t < best.t)) best = { t: h.t, type: "bay", index: b.i }; });
        return best;
      },
      hover(h) { st.hover = h ? h.index : -1; },
      onEnter() { c.st.veilColor = lin("#fbf8ef"); },
      setBays(list) {
        const sig = list.map((b) => b.key).join("|"); if (sig === st.sig) return; st.sig = sig;
        list.forEach((b, i) => { if (BAYS[i]) fill(BAYS[i], b.colors); }); c.wake(1200);
      }
    };
    return room;
  };
})();
