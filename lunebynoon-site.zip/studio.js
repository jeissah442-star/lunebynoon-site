/* LuneByNoon storefront, editorial edition.
   Renders the shop pages over the shared shopping logic in app.js (cart, sizes,
   embroidery, mix and match, bundles, checkout). Real photographs only, rounded
   frames, free native scrolling, and a door that opens into the hallway.
   Loaded before app.js; exposes window.LBNUI. */
(function () {
  "use strict";
  const $ = (s, r) => (r || document).querySelector(s);
  const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));
  const X = () => window.LBN;
  const S = () => X().S;
  const t = (k, v) => X().t(k, v);
  const L = (o) => X().L(o);
  const esc = (s) => X().esc(s);
  const fmt = (n) => X().fmt(n);
  const num = (n) => X().num(n);
  const P = (id) => X().P(id);
  const Bn = (id) => X().B(id);
  const Art = () => X().Art;
  const reduce = () => !!(window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches);

  const U = { shopType: "all", shopSort: "featured", czView: "photo", pdpView: "photo", bound: false };

  /* copy that belongs to this design, in both languages */
  const TX = {
    en: {
      hero_eyebrow: "Personalized pyjamas · Delivered across Egypt",
      shop_now: "Shop the collection", make_yours: "Personalize yours",
      intro_big: "Soft sets for slow mornings and quiet nights, finished with a name in thread.",
      v_comfort_s: "Soft woven cotton, cut to move with you.", v_details_s: "Piping, ric rac trims and your own embroidery.",
      v_timeless_s: "Classic shapes you keep coming back to.", v_women_s: "Designed for every kind of night.",
      sig_eyebrow: "Our signature sets", sig_title: "Made to be lived in", view_all: "View all",
      names_title: "Your name, stitched on the pocket", names_sub: "Choose the name, the thread and the lettering. We embroider it on the chest pocket so the set is only ever yours.",
      names_cta: "Start your embroidery", names_detail: "Script lettering",
      cols_eyebrow: "Collections", cols_title: "Find your kind of comfort",
      mix_cap: "Tops and bottoms sold on their own, so every set can be yours.",
      gifts_eyebrow: "Bundles and gifts", from: "From",
      story_eyebrow: "Our story", read_story: "Read our story",
      journal_eyebrow: "@lunebynoon", follow: "Follow on Instagram",
      door_msg: "Every night begins with a little magic", door_open: "Open the door", door_skip: "Skip",
      all_types: "All", t_sets: "Sets", t_tops: "Tops", t_bottoms: "Bottoms", t_robes: "Robes", t_acc: "Accessories",
      sort_featured: "Featured", sort_low: "Price, low to high", sort_high: "Price, high to low", sort_new: "Newest",
      pieces: "pieces", no_pieces: "Nothing here yet. Try another collection.",
      v_photo: "Photo", v_close: "Close-up", v_stitch: "Stitching",
      emb_preview: "Embroidery preview", emb_on: "Shown on the chest pocket", emb_card: "Shown as a close-up of the stitching for this placement",
      perk1: "Free delivery across Egypt on orders over {p}", perk2: "Pay on delivery, by card or InstaPay", perk3: "Embroidery is added in our workshop before dispatch",
      cz_eyebrow: "The atelier", cz_title: "Customize your pyjamas", cz_sub: "Pick a piece, type a name and see it stitched right away. Every embroidered piece is made to order.",
      cz_piece: "Choose your piece", cz_piece_s: "Sets, tops and robes", cz_colour_size: "Colour and size", cz_name: "Your name or initials", cz_name_s: "Up to 12 letters, English or Arabic",
      cz_inspo: "Try", cz_font: "Lettering", cz_thread: "Thread colour", cz_place: "Placement", cz_icon: "Add a small icon", cz_note: "A note for our workshop",
      cz_review: "Review", cz_chars: "{n}/12", piece_price: "Piece", emb_fee: "Embroidery", total: "Total",
      mx_eyebrow: "Mix and match", mx_your: "Your set",
      b_eyebrow: "Bundles", b_title: "Gifting, made easy", b_sub: "Curated sets for every season, moment or gift. Choose sizes and colours, and add a name to any piece.",
      st_eyebrow: "About us", chapter: "Chapter",
      scroll: "Scroll", season_shop: "Shop the collection",
      mood_original: "Every night", mood_winter: "Cold nights", mood_summer: "Hot nights", mood_bridal: "The big day", mood_postpartum: "New mornings"
    },
    ar: {
      hero_eyebrow: "بيجامات بلمستك · توصيل لكل مصر",
      shop_now: "تسوّقي المجموعة", make_yours: "خصّصي طقمك",
      intro_big: "أطقم ناعمة لصباح هادي وليالي رايقة، ومتطرز عليها اسمك بالخيط.",
      v_comfort_s: "قطن ناعم بيتحرك معاكي.", v_details_s: "بايبنج وشرايط وتطريز باسمك.",
      v_timeless_s: "قصّات كلاسيك بترجعيلها دايمًا.", v_women_s: "معمولة لكل نوع من الليالي.",
      sig_eyebrow: "أطقمنا المميزة", sig_title: "معمولة عشان تتلبس وتتعاش", view_all: "شوفي الكل",
      names_title: "اسمك متطرز على الجيب", names_sub: "اختاري الاسم ولون الخيط وشكل الخط، وإحنا نطرزه على جيب الصدر عشان الطقم يبقى ليكي إنتي بس.",
      names_cta: "ابدئي التطريز", names_detail: "خط سكريبت",
      cols_eyebrow: "المجموعات", cols_title: "لاقي راحتك على طريقتك",
      mix_cap: "التوب والبنطلون بيتباعوا لوحدهم، عشان كل طقم يبقى على ذوقك.",
      gifts_eyebrow: "باقات وهدايا", from: "من",
      story_eyebrow: "حكايتنا", read_story: "اقري حكايتنا",
      journal_eyebrow: "@lunebynoon", follow: "تابعينا على إنستجرام",
      door_msg: "كل ليلة بتبدأ بشوية سحر", door_open: "افتحي الباب", door_skip: "تخطي",
      all_types: "الكل", t_sets: "أطقم", t_tops: "توبات", t_bottoms: "بناطيل", t_robes: "روبات", t_acc: "إكسسوارات",
      sort_featured: "المميز", sort_low: "السعر من الأقل", sort_high: "السعر من الأعلى", sort_new: "الأحدث",
      pieces: "قطعة", no_pieces: "مفيش قطع هنا دلوقتي. جربي مجموعة تانية.",
      v_photo: "الصورة", v_close: "عن قرب", v_stitch: "التطريز",
      emb_preview: "معاينة التطريز", emb_on: "ظاهر على جيب الصدر", emb_card: "ظاهر كصورة قريبة للتطريز في المكان ده",
      perk1: "توصيل مجاني لكل مصر للطلبات فوق {p}", perk2: "ادفعي عند الاستلام أو بالكارت أو إنستاباي", perk3: "التطريز بيتعمل في ورشتنا قبل الشحن",
      cz_eyebrow: "الأتيليه", cz_title: "صمّمي بيجامتك", cz_sub: "اختاري القطعة واكتبي الاسم وشوفيه متطرز على طول. كل قطعة متطرزة بتتعمل مخصوص ليكي.",
      cz_piece: "اختاري القطعة", cz_piece_s: "أطقم وتوبات وروبات", cz_colour_size: "اللون والمقاس", cz_name: "اسمك أو حروفك", cz_name_s: "لحد ١٢ حرف، عربي أو إنجليزي",
      cz_inspo: "جربي", cz_font: "شكل الخط", cz_thread: "لون الخيط", cz_place: "مكان التطريز", cz_icon: "ضيفي أيقونة صغيرة", cz_note: "ملاحظة للورشة",
      cz_review: "المراجعة", cz_chars: "{n}/١٢", piece_price: "القطعة", emb_fee: "التطريز", total: "الإجمالي",
      mx_eyebrow: "نسّقي طقمك", mx_your: "طقمك",
      b_eyebrow: "الباقات", b_title: "الهدايا بقت أسهل", b_sub: "أطقم مختارة لكل موسم ومناسبة وهدية. اختاري المقاسات والألوان، وضيفي اسم على أي قطعة.",
      st_eyebrow: "عنّا", chapter: "الفصل",
      scroll: "انزلي", season_shop: "تسوّقي المجموعة",
      mood_original: "كل ليلة", mood_winter: "ليالي البرد", mood_summer: "ليالي الحر", mood_bridal: "اليوم الكبير", mood_postpartum: "صباحات جديدة"
    }
  };
  const tx = (k, vars) => {
    let s = (TX[S().lang] || TX.en)[k];
    if (s == null) s = TX.en[k] != null ? TX.en[k] : k;
    if (vars) Object.keys(vars).forEach((v) => { s = s.split("{" + v + "}").join(vars[v]); });
    return s;
  };

  const ICO = {
    arrow: '<svg class="arr" viewBox="0 0 16 10" aria-hidden="true"><path d="M0 5h14M10 1l4 4-4 4" stroke="currentColor" stroke-width="1.4" fill="none"/></svg>',
    left: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" aria-hidden="true"><path d="M15 5l-7 7 7 7"/></svg>',
    right: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" aria-hidden="true"><path d="M9 5l7 7-7 7"/></svg>',
    truck: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" aria-hidden="true"><path d="M3 6h11v10H3zM14 9h4l3 3v4h-7"/><circle cx="7" cy="17.5" r="1.6"/><circle cx="17" cy="17.5" r="1.6"/></svg>',
    card: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" aria-hidden="true"><rect x="3" y="6" width="18" height="12" rx="2"/><path d="M3 10h18"/></svg>',
    needle: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" aria-hidden="true"><path d="M19 5L7 17M17.5 3.5l3 3M5 19l-1 1"/><path d="M9 6c-3 1-5 4-4 7s5 3 7 1" stroke-dasharray="2 2"/></svg>'
  };
  const LINE = (d, extra) => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${d}${extra || ""}</svg>`;
  const SICON = {
    moon: LINE('<path d="M15.2 3.6a8.6 8.6 0 1 0 5.6 13.7a6.9 6.9 0 0 1 -5.6 -13.7z"/>'),
    snow: LINE('<path d="M12 2.5v19M3.8 7.2l16.4 9.6M3.8 16.8l16.4-9.6M9.6 4.1L12 6.4l2.4-2.3M9.6 19.9l2.4-2.3 2.4 2.3M4.3 10.4l3.2.8-.9 3.2M19.7 13.6l-3.2-.8.9-3.2M6.6 9.6l-.9 3.2 3.2.8M17.4 14.4l.9-3.2-3.2-.8"/>'),
    sun: LINE('<circle cx="12" cy="12" r="4.2"/><path d="M12 2.5v2.4M12 19.1v2.4M2.5 12h2.4M19.1 12h2.4M5.3 5.3l1.7 1.7M17 17l1.7 1.7M5.3 18.7L7 17M17 7l1.7-1.7"/>'),
    pearl: LINE('<path d="M12 3l1.7 5.6L19.5 10l-5.8 1.6L12 17.5l-1.7-5.9L4.5 10l5.8-1.4z"/><circle cx="18.5" cy="18" r="1.6"/><circle cx="5.5" cy="18.5" r="1"/>'),
    dawn: LINE('<path d="M3 17.5h18M6.5 17.5a5.5 5.5 0 0 1 11 0M12 6.5v2.2M5.6 9.8l1.5 1.5M18.4 9.8l-1.5 1.5M8 20.5h8"/>')
  };
  const SEASON = {
    original: { mood: "moon", pics: ["classic-set", "classic-top", "crescent-set"] },
    winter: { mood: "snow", pics: ["burgundy-winter-set", "checkered-set", "ivory-winter-set"] },
    summer: { mood: "sun", pics: ["summer-short-set", "satin-cami-set", "lounge-shorts"] },
    bridal: { mood: "pearl", pics: ["bride-set", "bridal-robe", "ivory-winter-set"] },
    postpartum: { mood: "dawn", pics: ["mama-set", "mama-robe", "blush-winter-set"] }
  };
  const fx = (mood) => `<span class="s-fx s-fx-${mood}" aria-hidden="true"></span>`;
  const chip = (col) => `<span class="s-season-chip">${SICON[(SEASON[col] || {}).mood || "moon"]}${esc(tx("mood_" + col))}</span>`;
  /* product cut-outs that float around the page */
  const CUT = (name, cls, style, par) => `<span class="s-float ${cls || ""}" ${par != null ? `data-par="${par}"` : ""} style="${style || ""}" aria-hidden="true"><img src="assets/cut/${name}.webp" alt="" loading="lazy" decoding="async"></span>`;
  const NAMES = ["Haya", "Salma", "Sara", "Nour", "Lina", "Malak", "Farida", "Jana", "Mariam", "Yasmin"];
  const NAMES_AR = ["هيا", "سلمى", "سارة", "نور", "لينا", "ملك", "فريدة", "جنى", "مريم", "ياسمين"];
  const LOGO = (alt) => `<img src="assets/logo-burgundy.svg" alt="${alt == null ? "LuneByNoon" : alt}" width="640" height="147" decoding="async">`;
  const img = (src, alt, cls, eager) => `<img src="${esc(src)}" alt="${esc(alt || "")}" ${cls ? `class="${cls}"` : ""} ${eager ? "" : 'loading="lazy"'} decoding="async">`;
  const thumb = (p) => (p && p.image ? p.image.replace(/\.jpg$/, "-thumb.jpg") : "");
  const COLS = ["original", "winter", "summer", "bridal", "postpartum"];
  const COL_PHOTO = { original: "classic-set", winter: "burgundy-winter-set", summer: "summer-short-set", bridal: "bride-set", postpartum: "mama-set" };

  /* where the chest pocket sits on each photograph: x, y, text width (px of 900 x 1204), angle */
  const POINTS = {
    "stripe-top": [512, 343, 54, 0], "winter-top": [571, 345, 54, 1], "blush-winter-set": [548, 438, 58, 0],
    "summer-short-set": [502, 489, 44, 0], "stripe-set": [502, 556, 50, -2], "classic-set": [528, 582, 46, 0],
    "crescent-set": [538, 503, 48, 0], "burgundy-winter-set": [623, 507, 36, 0], "robe-set": [446, 378, 42, 0],
    "crescent-flannel-set": [482, 590, 36, -3], "classic-top": [582, 366, 42, 28]
  };
  const ON_PHOTO = ["pocket", "left"];
  const MODELS = [
    { name: "Haya", ar: "هيا", img: "assets/models/haya.jpg", detail: "assets/models/haya-detail.jpg", pid: "stripe-top", thread: "burgundy" },
    { name: "Salma", ar: "سلمى", img: "assets/models/salma.jpg", detail: "assets/models/salma-detail.jpg", pid: "winter-top", thread: "baby" },
    { name: "Sara", ar: "سارة", img: "assets/models/sara.jpg", detail: "assets/models/sara-detail.jpg", pid: "blush-winter-set", thread: "burgundy" }
  ];

  const route = () => S().route;
  const qty = () => S().cart.reduce((a, l) => a + l.qty, 0);
  const colorOf = (p, k) => X().colorOf(p, k) || p.colors[0];
  const darkHex = (hex) => { const h = String(hex || "").replace("#", ""); if (h.length < 6) return false; const r = parseInt(h.slice(0, 2), 16), g = parseInt(h.slice(2, 4), 16), b = parseInt(h.slice(4, 6), 16); return (r * 299 + g * 587 + b * 114) / 1000 < 110; };
  const typeOf = (p) => (p.type === "set" ? "sets" : p.type === "top" ? "tops" : p.type === "bottom" ? "bottoms" : p.type === "robe" ? "robes" : "acc");

  /* ---------------------------------------------------------------- chrome */
  const NAV = () => [["home", t("nav_home")], ["customize", t("nav_customize")], ["mix", t("nav_mix")], ["shop", t("nav_collections")], ["bundles", t("nav_bundles")], ["story", t("nav_story")]];
  function header() {
    const r = route().name, x = X();
    const on = (k) => (k === "shop" ? r === "shop" || r === "p" : k === "bundles" ? r === "bundles" || r === "b" : r === k);
    const link = ([k, v]) => `<a href="#${k}" class="${on(k) ? "on" : ""}" ${on(k) ? 'aria-current="page"' : ""}>${esc(v)}</a>`;
    const n = qty();
    return `<div class="s-hdr">
      <div class="s-hdr-l"><button class="s-ib s-menu-btn" data-act="menu" aria-label="${esc(t("menu"))}">${x.ICON.menu}</button><nav class="s-nav" aria-label="Main">${NAV().slice(0, 3).map(link).join("")}</nav></div>
      <a class="s-logo" href="#home" aria-label="LuneByNoon">${LOGO("")}</a>
      <div class="s-hdr-r"><nav class="s-nav" aria-label="Main, continued">${NAV().slice(3).map(link).join("")}</nav>
        <button class="s-lang" data-act="lang">${esc(t("otherLang"))}</button>
        <button class="s-ib" data-act="search" aria-label="${esc(t("search"))}">${x.ICON.search}</button>
        <button class="s-ib" data-act="cart" aria-label="${esc(t("bag"))}">${x.ICON.bag}<span class="count" id="count" ${n ? "" : "hidden"}>${num(n)}</span></button>
      </div></div>`;
  }
  function footer() {
    const st = S().settings;
    const ext = (u, label) => `<a href="${esc(u || "#")}" target="_blank" rel="noopener">${esc(label)}</a>`;
    return `<div class="s-ftr">
      <div class="s-ftr-top">
        <div><span class="s-eyebrow" style="color:var(--s-petal)">${esc(t("news_title"))}</span><h3 style="margin-top:.8rem">${esc(t("tagline"))}</h3><p>${esc(t("news_sub"))}</p></div>
        <form class="newsform" id="newsform" novalidate><label class="sr" for="newsEmail">${esc(t("news_ph"))}</label>
          <input type="email" id="newsEmail" placeholder="${esc(t("news_ph"))}" autocomplete="email"><button class="s-btn light" type="submit">${esc(t("news_btn"))}</button>
          <p class="note" id="newsMsg" aria-live="polite"></p></form>
      </div>
      <div class="s-ftr-cols">
        <div class="s-ftr-brand"><img src="assets/logo-cream.svg" alt="LuneByNoon" width="640" height="147"><p>${esc(t("est"))}</p></div>
        <div><h4>${esc(t("f_shop"))}</h4>${NAV().slice(1).map(([k, v]) => `<a href="#${k}">${esc(v)}</a>`).join("")}</div>
        <div><h4>${esc(t("f_support"))}</h4>${["shipping", "returns", "custom", "payment", "size", "care", "faq", "contact"].map((k) => `<a href="#help-${k}">${esc(t("h_" + k))}</a>`).join("")}<a href="#creators">${esc(t("h_creators"))}</a></div>
        <div><h4>${esc(t("f_follow"))}</h4>${ext(st.instagram, "Instagram")}${ext(st.tiktok, "TikTok")}${ext(st.pinterest, "Pinterest")}${S().canEdit ? `<a href="#admin">${esc(t("admin"))}</a>` : ""}</div>
      </div>
      <div class="s-ftr-base"><span>© 2026 LuneByNoon. ${esc(t("rights"))}</span><span><a href="#help-terms">${esc(t("h_terms"))}</a> · <button data-act="lang">${esc(t("otherLang"))}</button></span></div>
    </div>`;
  }

  /* ---------------------------------------------------------------- shared pieces */
  function card(p, opts) {
    opts = opts || {};
    const tags = [];
    if (p.inStock === false) tags.push(`<span class="s-tag out">${esc(t("sold_out"))}</span>`);
    else if (p.isNew) tags.push(`<span class="s-tag">${esc(t("badge_new"))}</span>`);
    else if (X().canEmb(p) && opts.custom !== false) tags.push(`<span class="s-tag">${esc(t("badge_custom"))}</span>`);
    return `<a class="s-card" ${opts.pop != null ? `data-pop style="--d:${Math.min(opts.pop, 6) * 80}ms"` : ""} href="#p-${esc(p.id)}">
      <div class="s-frame">${p.image ? img(p.image, L(p.name)) : ""}<span class="s-card-tags">${tags.join("")}</span></div>
      <div class="s-card-meta"><h3>${esc(L(p.name))}</h3><span class="p">${fmt(p.price)}</span></div>
      ${opts.sub !== false ? `<div class="s-card-sub">${esc(p.colors.map((c) => L(c.name)).join(" · "))}</div>` : ""}
    </a>`;
  }
  function rail(id, items) {
    return `<div class="s-rail-wrap"><div class="s-rail" id="${id}" tabindex="0">${items.join("")}</div></div>`;
  }
  const railCtl = (id) => `<div class="s-rail-ctl"><button type="button" data-srail="${id}" data-d="-1" aria-label="${esc(t("prev_design"))}">${ICO.left}</button><button type="button" data-srail="${id}" data-d="1" aria-label="${esc(t("next_design"))}">${ICO.right}</button></div>`;

  function monoHTML(p, c, colKey) {
    const pt = POINTS[p.id];
    if (!pt || !c || !c.text || !ON_PHOTO.includes(c.placement)) return "";
    const A = Art();
    const color = (A.THREADS || {})[c.thread] || "#6e2135";
    return `<span class="s-mono" data-w="${(pt[2] / 9).toFixed(2)}" style="left:${(pt[0] / 9).toFixed(2)}%;top:${(pt[1] / 12.04).toFixed(2)}%;--ang:${pt[3]}deg;color:${color};font-family:${(A.FONTS || {})[c.font] || ""}">${esc(c.text)}${c.icon ? A.icon(c.icon, 14, color) : ""}</span>`;
    void colKey;
  }
  function swatchHTML(p, colKey, c, cap) {
    const A = Art(), col = colorOf(p, colKey) || {}, base = col.base || "#f6d6df";
    const color = (A.THREADS || {})[c.thread] || "#6e2135";
    const text = c.text || (S().lang === "ar" ? "هيا" : "Haya");
    return `<div class="s-swatch ${darkHex(base) ? "dark" : ""}" style="background-color:${esc(base)}"><span class="seam"></span>
      <span class="txt" style="color:${color};font-family:${(A.FONTS || {})[c.font] || ""}">${esc(text)}${c.icon ? A.icon(c.icon, 20, color) : ""}</span>
      ${cap ? `<span class="cap">${esc(cap)}</span>` : ""}</div>`;
  }
  function zoomVars(p) {
    const pt = POINTS[p.id];
    return pt ? `--zx:${(pt[0] / 9).toFixed(1)}%;--zy:${(pt[1] / 12.04).toFixed(1)}%` : "";
  }

  /* embroidery controls, same data-act and data-in keys as app.js */
  function embControls(scope, c, pls, idp) {
    const x = X(), A = Art();
    const sample = c.text || (S().lang === "ar" ? "هيا" : "Haya");
    return `<div class="s-emb">
      <div class="s-field"><label for="${idp}Text">${esc(tx("cz_name"))}<span>${esc(tx("cz_name_s"))}</span></label>
        <input class="s-input" type="text" id="${idp}Text" maxlength="12" value="${esc(c.text)}" placeholder="${esc(t("c_text_ph"))}" data-in="embtext" data-scope="${scope}" autocomplete="off"></div>
      <div class="s-field"><span class="lbl">${esc(tx("cz_font"))}<span>${esc(t("font_" + c.font))}</span></span>
        <div class="s-fonts">${x.FONT_KEYS.map((k) => `<button type="button" class="${c.font === k ? "on" : ""}" data-act="emb" data-scope="${scope}" data-k="font" data-v="${k}" aria-pressed="${c.font === k}"><b style="font-family:${A.FONTS[k]}" data-sample>${esc(sample)}</b><span>${esc(t("font_" + k))}</span></button>`).join("")}</div></div>
      <div class="s-field"><span class="lbl">${esc(tx("cz_thread"))}<span>${esc(t("th_" + c.thread))}</span></span>
        <div class="s-threads">${x.THREAD_KEYS.map((k) => `<button type="button" class="${c.thread === k ? "on" : ""}" data-act="emb" data-scope="${scope}" data-k="thread" data-v="${k}" aria-pressed="${c.thread === k}"><i style="background-color:${A.THREADS[k]}"></i>${esc(t("th_" + k))}</button>`).join("")}</div></div>
      ${pls.length > 1 ? `<div class="s-field"><span class="lbl">${esc(tx("cz_place"))}<span>${esc(t("pl_" + c.placement))}</span></span>
        <div class="s-chips">${pls.map((k) => `<button type="button" class="s-chip ${c.placement === k ? "on" : ""}" data-act="emb" data-scope="${scope}" data-k="placement" data-v="${k}" aria-pressed="${c.placement === k}">${esc(t("pl_" + k))}</button>`).join("")}</div></div>` : ""}
      <div class="s-field"><span class="lbl">${esc(tx("cz_icon"))}<span>${esc(t("optional"))}</span></span>
        <div class="s-chips">${x.ICON_KEYS.map((k) => `<button type="button" class="s-chip ${(c.icon || "") === k ? "on" : ""}" data-act="emb" data-scope="${scope}" data-k="icon" data-v="${k}" aria-pressed="${(c.icon || "") === k}">${k ? A.icon(k, 16, "#6e2135") : ""}${esc(t("icon_" + (k || "none")))}</button>`).join("")}</div></div>
      <div class="s-field"><label for="${idp}Note">${esc(tx("cz_note"))}<span>${esc(t("optional"))}</span></label>
        <textarea class="s-input" id="${idp}Note" rows="2" maxlength="200" placeholder="${esc(t("c_note_ph"))}" data-in="embnote" data-scope="${scope}">${esc(c.note || "")}</textarea></div>
    </div>`;
  }
  const colorBtns = (p, cur, act, extra) => `<div class="s-colors">${p.colors.map((c) => `<button class="s-color ${c.key === cur ? "on" : ""}" data-act="${act}" data-v="${esc(c.key)}" ${extra || ""} aria-label="${esc(L(c.name))}" aria-pressed="${c.key === cur}" style="background:linear-gradient(135deg, ${esc(c.base)} 55%, ${esc(c.accent || c.base)} 55%)"></button>`).join("")}</div>`;
  const sizeBtns = (p, cur, act, extra) => `<div class="s-sizes">${p.sizes.map((z) => `<button class="s-size ${cur === z ? "on" : ""}" data-act="${act}" data-v="${esc(z)}" ${extra || ""} aria-pressed="${cur === z}" ${(p.soldOutSizes || []).includes(z) ? "disabled" : ""}>${esc(z)}</button>`).join("")}</div>`;

  /* ---------------------------------------------------------------- views */
  function view(r) {
    switch (r.name) {
      case "home": return vHome();
      case "shop": return vShop(r.arg);
      case "p": return vProduct(r.arg);
      case "customize": return vCustomize();
      case "mix": return vMix();
      case "bundles": return vBundles();
      case "b": return vBundle(r.arg);
      case "story": return vStory();
      default: return null;
    }
  }

  function featured() {
    const all = S().products.filter((p) => p.inStock !== false);
    const f = all.filter((p) => p.featured);
    const sets = all.filter((p) => p.type === "set");
    return (f.length >= 6 ? f : f.concat(sets.filter((p) => !f.includes(p)))).slice(0, 10);
  }
  function vHome() {
    X().setMeta("", t("custom_sub"));
    const st = S().settings;
    const sets = featured();
    const cols = COLS.map((c) => [c, P(COL_PHOTO[c])]).filter(([, p]) => p);
    const tops = S().products.filter((p) => p.type === "top").slice(0, 3), bots = S().products.filter((p) => p.type === "bottom").slice(0, 2);
    const posters = [1, 2, 3, 4, 5, 6].map((n) => `assets/posters/poster-${n}.jpg`);
    const bundles = S().bundles.slice(0, 4);
    const vals = [["v_comfort", "v_comfort_s"], ["v_details", "v_details_s"], ["v_timeless", "v_timeless_s"], ["v_women", "v_women_s"]];
    return `
    <section class="s-hx" id="sHx" aria-label="LuneByNoon">
      <div class="s-hx-pin">
        <div class="s-hx-bg" aria-hidden="true"></div>
        <div class="s-hx-frame"><img src="assets/brand-story-wide.jpg" alt="${esc(t("tagline"))}" fetchpriority="high" decoding="async">
          <div class="s-hx-copy"><p>${esc(L(st.heroSub) || "")}</p><div class="s-hero-ctas"><a class="s-btn light" href="#shop">${esc(tx("shop_now"))} ${ICO.arrow}</a><a class="s-btn line-light" href="#customize">${esc(tx("make_yours"))}</a></div></div></div>
        <span class="s-hx-hint">${esc(tx("scroll"))}<i></i></span>
      </div>
    </section>

    <div class="s-mq" aria-hidden="true">
      <div class="s-mq-row" data-mq="l">${[0, 1, 2].map(() => NAMES.map((n) => `<b>${esc(n)}</b>${SICON.moon}`).join("")).join("")}</div>
      <div class="s-mq-row ar" data-mq="r">${[0, 1, 2].map(() => NAMES_AR.map((n) => `<b>${esc(n)}</b>${SICON.moon}`).join("")).join("")}</div>
    </div>

    <section class="s-sec s-rel"><div class="s-wrap s-intro">
      <div class="s-intro-l"><span class="s-eyebrow" data-rv>${esc(t("tagline"))}</span>
        <div class="s-fabric-showcase"><div class="fabric-shot">${img("assets/products/classic-set.jpg", "Classic cotton set", "", true)}</div><div class="fabric-shot">${img("assets/products/satin-cami-set.jpg", "Satin cami set", "", true)}</div></div></div>
      <div><p class="big" data-rv>${esc(tx("intro_big"))}</p>
        <div class="s-values">${vals.map(([a, b], i) => `<div data-rv style="--d:${i * 90}ms"><b>${esc(t(a))}</b>${esc(tx(b))}</div>`).join("")}</div></div>
    </div></section>

    <section class="s-sec tight" style="padding-top:0">
      <div class="s-wrap s-head"><div data-rv><span class="s-eyebrow">${esc(tx("sig_eyebrow"))}</span><h2 class="s-h2">${esc(tx("sig_title"))}</h2></div>
        <div style="display:flex;gap:1.2rem;align-items:center">${railCtl("railSig")}<a class="s-link" href="#shop">${esc(tx("view_all"))} ${ICO.arrow}</a></div></div>
      <div class="s-rail-full">${rail("railSig", sets.map((p, i) => card(p, { pop: i })))}</div>
    </section>

    <section class="s-sec pink"><div class="s-wrap">
      <div class="s-names-copy"><div style="display:grid;gap:.9rem;max-width:640px" data-rv><span class="s-eyebrow">${esc(t("truly_eyebrow"))}</span><h2 class="s-h2">${esc(tx("names_title"))}</h2><p class="s-lede">${esc(tx("names_sub"))}</p></div>
        <a class="s-btn" href="#customize">${esc(tx("names_cta"))} ${ICO.arrow}</a></div>
      <div class="s-names">${MODELS.map((m, i) => { const p = P(m.pid); return `<a class="s-name" data-pop style="--d:${i * 140}ms" href="#customize" data-sname="${esc(m.name)}" data-sthread="${m.thread}" data-spid="${esc(m.pid)}">
        <div style="position:relative"><div class="s-frame" data-grow>${img(m.img, m.name + " · " + (p ? L(p.name) : ""))}</div><span class="detail" data-par="${i % 2 ? -0.18 : 0.18}">${img(m.detail, "")}</span></div>
        <div class="who"><b>${esc(m.name)}</b><span>${p ? esc(L(p.name)) : ""} · ${esc(t("th_" + m.thread))}</span></div></a>`; }).join("")}</div>
    </div></section>

    <section class="s-sec"><div class="s-wrap">
      <div class="s-head"><div data-rv><span class="s-eyebrow">${esc(tx("cols_eyebrow"))}</span><h2 class="s-h2">${esc(tx("cols_title"))}</h2><img class="s-ricrac" src="assets/cut/ricrac.webp" alt="" aria-hidden="true"></div><a class="s-link" href="#shop">${esc(tx("view_all"))} ${ICO.arrow}</a></div>
      <div class="s-cols">${cols.map(([c, p], i) => `<a class="s-col s-mood-${SEASON[c].mood}" data-pop style="--d:${i * 90}ms" href="#shop-${c}"><div class="s-frame">${img(p.image, t("col_" + c))}${fx(SEASON[c].mood)}${chip(c)}</div>
        <div class="lbl"><div><h3>${esc(t("col_" + c))}</h3><span>${esc(t("cold_" + c))}</span></div><span class="go">${ICO.arrow}</span></div></a>`).join("")}</div>
    </div></section>

    <section class="s-sec pink"><div class="s-wrap s-split">
      <div class="s-stack"><div class="s-frame wide" data-grow>${img("assets/rooms/dressing.jpg", "")}</div>${tops[0] ? `<div class="s-frame inset" data-par="-0.22">${img(tops[0].image, L(tops[0].name))}</div>` : ""}</div>
      <div class="copy" data-rv><span class="s-eyebrow">${esc(t("mix_eyebrow"))}</span><h2 class="s-h2">${esc(t("mix_title"))}</h2><p class="s-lede">${esc(t("mix_sub"))}</p>
        <div class="s-pieces">${tops.concat(bots).map((p) => `<a href="#p-${esc(p.id)}"><span class="s-frame">${img(thumb(p), L(p.name))}</span>${esc(L(p.name))}</a>`).join("")}</div>
        <p class="s-note">${esc(tx("mix_cap"))}</p>
        <a class="s-btn" href="#mix">${esc(t("mix_cta"))} ${ICO.arrow}</a></div>
    </div></section>

    <section class="s-sec"><div class="s-wrap">
      <div class="s-split rev"><div class="s-stack"><div class="s-frame wide" data-grow>${img("assets/rooms/gifts.jpg", "")}</div></div>
        <div class="copy" data-rv><span class="s-eyebrow">${esc(tx("gifts_eyebrow"))}</span><h2 class="s-h2">${esc(t("bundles_title"))}</h2><p class="s-lede">${esc(t("bundles_sub"))}</p><a class="s-btn" href="#bundles">${esc(t("bundles_cta"))} ${ICO.arrow}</a></div></div>
      ${bundles.length ? `<div class="s-bundle-row">${bundles.map((b, i) => bundleCard(b, i)).join("")}</div>` : ""}
    </div></section>

    <section class="s-sec pink"><div class="s-wrap s-split">
      <div class="s-stack"><div class="s-frame tall" data-grow>${img("assets/brand-story.jpg", "")}</div></div>
      <div class="copy" data-rv><span class="s-eyebrow">${esc(tx("story_eyebrow"))}</span><h2 class="s-h2">${esc(t("story_title"))}</h2><p class="s-lede">${esc(t("story_sub"))}</p><a class="s-btn ghost" href="#story">${esc(tx("read_story"))} ${ICO.arrow}</a></div>
    </div></section>

    <section class="s-sec"><div class="s-wrap">
      <div class="s-head"><div data-rv><span class="s-eyebrow">${esc(tx("journal_eyebrow"))}</span><h2 class="s-h2">${esc(t("community_title"))}</h2><p class="s-lede">${esc(t("community_sub"))}</p></div>
        <a class="s-link" href="${esc(st.instagram || "#")}" target="_blank" rel="noopener">${esc(tx("follow"))} ${ICO.arrow}</a></div>
      <div class="s-journal">${posters.map((src, i) => `<div class="s-frame" data-par="${[0.12, -0.16, 0.22, -0.1, 0.18, -0.2][i]}">${img(src, "")}</div>`).join("")}</div>
    </div></section>`;
  }
  function bundleCard(b, i) {
    const ps = b.items.map(P).filter((p) => p && p.image);
    const pics = ps.slice(0, 3);
    return `<a class="s-bcard" ${i != null ? `data-pop style="--d:${i * 110}ms"` : ""} href="#b-${esc(b.id)}"><div class="s-frame ${pics.length < 2 ? "one" : pics.length === 2 ? "two" : ""}">${pics.map((p) => img(p.image, "")).join("")}</div>
      <h3>${esc(L(b.name))}</h3><div class="pr"><b>${fmt(b.price)}</b>${X().bWorth(b) > b.price ? `<s>${fmt(X().bWorth(b))}</s>` : ""}</div></a>`;
  }

  /* shop */
  function shopList(col) {
    const s = S().shop, q = String(s.q || "").trim().toLowerCase();
    let list = S().products.slice();
    if (col && col !== "all" && COLS.includes(col)) list = list.filter((p) => (p.collections || []).includes(col));
    if (U.shopType !== "all") list = list.filter((p) => typeOf(p) === U.shopType);
    if (q) list = list.filter((p) => (L(p.name) + " " + p.name.en + " " + (p.name.ar || "") + " " + (p.collections || []).join(" ")).toLowerCase().includes(q));
    if (U.shopSort === "low") list.sort((a, b) => a.price - b.price);
    else if (U.shopSort === "high") list.sort((a, b) => b.price - a.price);
    else if (U.shopSort === "new") list.sort((a, b) => (b.isNew ? 1 : 0) - (a.isNew ? 1 : 0));
    else list.sort((a, b) => (b.featured ? 1 : 0) - (a.featured ? 1 : 0));
    list.sort((a, b) => (a.inStock === false ? 1 : 0) - (b.inStock === false ? 1 : 0));
    return list;
  }
  function vShop(arg) {
    const col = COLS.includes(arg) ? arg : "all";
    X().setMeta(col === "all" ? t("nav_collections") : t("col_" + col), col === "all" ? "" : t("cold_" + col));
    const list = shopList(col);
    const types = [["all", "all_types"], ["sets", "t_sets"], ["tops", "t_tops"], ["bottoms", "t_bottoms"], ["robes", "t_robes"], ["acc", "t_acc"]];
    const q = S().shop.q;
    return `<div class="s-wrap s-page">
      <div class="s-crumbs"><a href="#home">${esc(t("nav_home"))}</a><span>/</span><span>${esc(t("nav_collections"))}</span></div>
      ${col === "all" ? `<div class="s-pagehead s-rel"><span class="s-eyebrow">${esc(tx("cols_eyebrow"))}</span><h1 class="s-h1" style="font-size:clamp(2.2rem,4.4vw,3.8rem)">${esc(t("col_all"))}</h1>
        <p class="s-lede">${esc(t("cold_all"))}</p></div>` : seasonBanner(col)}
      <nav class="s-tabs" aria-label="${esc(tx("cols_eyebrow"))}"><a href="#shop" class="${col === "all" ? "on" : ""}">${esc(t("col_all"))}</a>${COLS.map((c) => `<a href="#shop-${c}" class="${col === c ? "on" : ""}">${esc(t("col_" + c))}</a>`).join("")}</nav>
      <div class="s-toolbar">
        <div class="s-tabs">${types.map(([k, l]) => `<button type="button" data-stype="${k}" class="${U.shopType === k ? "on" : ""}">${esc(tx(l))}</button>`).join("")}</div>
        <div style="display:flex;gap:1rem;align-items:center"><span class="s-note">${num(list.length)} ${esc(tx("pieces"))}</span>
          <select data-ssort aria-label="sort">${[["featured", "sort_featured"], ["low", "sort_low"], ["high", "sort_high"], ["new", "sort_new"]].map(([k, l]) => `<option value="${k}" ${U.shopSort === k ? "selected" : ""}>${esc(tx(l))}</option>`).join("")}</select></div>
      </div>
      ${q ? `<p class="s-note" style="margin-bottom:1rem">“${esc(q)}” <button class="s-chip" data-act="fq" style="margin-inline-start:.5rem">✕</button></p>` : ""}
      ${list.length ? `<div class="s-grid" id="grid">${list.map((p, i) => card(p, { pop: i % 4 })).join("")}</div>` : `<div class="s-empty"><p>${esc(tx("no_pieces"))}</p><a class="s-btn ghost" href="#shop">${esc(t("col_all"))}</a></div>`}
    </div><div style="height:clamp(64px,8vw,120px)"></div>`;
  }

  function seasonBanner(col) {
    const se = SEASON[col], pics = se.pics.map(P).filter((p) => p && p.image);
    return `<section class="s-cbanner s-mood-${se.mood}">${fx(se.mood)}
      <div class="copy">${chip(col)}<h1 class="s-h1">${esc(t("col_" + col))}</h1><p class="s-h3">${esc(t("colh_" + col))}</p><p class="s-lede">${esc(t("cold_" + col))}</p></div>
      <div class="pics">${pics.map((p, i) => `<a class="s-frame f${i}" href="#p-${esc(p.id)}" data-par="${[0.1, -0.16, 0.22][i]}">${img(p.image, L(p.name), "", i === 0)}</a>`).join("")}</div>
    </section>`;
  }

  /* product */
  function vProduct(id) {
    const x = X(), p = P(id);
    if (!p) return `<div class="s-wrap s-page"><div class="s-empty"><p>${esc(t("no_results"))}</p><a class="s-btn" href="#shop">${esc(t("back_shop"))}</a></div></div>`;
    if (S().pdp.id !== id) x.resetPdp(id);
    const s = S().pdp, col = colorOf(p, s.color);
    x.setMeta(L(p.name), L(p.desc)); x.productLd(p);
    if (S()._viewed !== id) { S()._viewed = id; x.track("view_item", { item_id: id, value: p.price, currency: "EGP" }); }
    const emb = x.canEmb(p), pls = Art().placementsFor(p);
    const c = s.c, custom = c.on && c.text ? c : null;
    const sample = custom || { text: S().lang === "ar" ? "هيا" : "Haya", font: c.font, thread: c.thread, placement: pls[0], icon: "" };
    const canPhoto = !!POINTS[p.id];
    let v = U.pdpView; if (v === "close" && !canPhoto) v = "photo"; if (v === "stitch" && !emb) v = "photo";
    const showC = custom || (v !== "photo" ? sample : null);
    const unit = p.price + (custom ? x.fee() : 0);
    const related = S().products.filter((q) => q.id !== p.id && (q.collections || []).some((cc) => (p.collections || []).includes(cc))).slice(0, 8);
    const col0 = (p.collections || [])[0];
    const main = v === "stitch"
      ? `<div style="position:absolute;inset:0;display:grid;place-items:center;background:var(--s-pink)"><div style="width:72%">${swatchHTML(p, s.color, sample, t("pl_" + sample.placement))}</div></div>`
      : `<div class="layer" style="${zoomVars(p)}">${img(p.image, L(p.name), "", true)}${monoHTML(p, showC)}</div>`;
    return `<div class="s-wrap s-page">
      <div class="s-crumbs"><a href="#home">${esc(t("nav_home"))}</a><span>/</span><a href="#shop">${esc(t("nav_collections"))}</a>${col0 ? `<span>/</span><a href="#shop-${col0}">${esc(t("col_" + col0))}</a>` : ""}<span>/</span><span>${esc(L(p.name))}</span></div>
      <div class="s-pdp">
        <div class="s-gal">
          <div class="thumbs">
            <button class="${v === "photo" ? "on" : ""}" data-spview="photo" aria-label="${esc(tx("v_photo"))}">${img(thumb(p), "")}</button>
            ${canPhoto && emb ? `<button class="${v === "close" ? "on" : ""}" data-spview="close" aria-label="${esc(tx("v_close"))}" style="${zoomVars(p)}"><span style="display:block;width:100%;height:100%;overflow:hidden"><img src="${esc(thumb(p))}" alt="" style="transform:scale(2.4);transform-origin:var(--zx) var(--zy)"></span></button>` : ""}
            ${emb ? `<button class="${v === "stitch" ? "on" : ""}" data-spview="stitch" aria-label="${esc(tx("v_stitch"))}"><span class="sw-thumb" style="width:100%;height:100%;background:${esc(col.base)}">Aa</span></button>` : ""}
          </div>
          <div class="s-frame main s-photo ${v === "close" ? "close" : ""}" id="sPdpMain" style="${zoomVars(p)}">${main}</div>
        </div>
        <div class="s-buy">
          <div style="display:grid;gap:.8rem"><span class="s-eyebrow">${esc(col0 ? t("col_" + col0) : "LuneByNoon")}</span><h1>${esc(L(p.name))}</h1>
            <div class="price" id="sPdpPrice">${fmt(unit)}${p.compareAt ? `<s>${fmt(p.compareAt)}</s>` : ""}</div>
            <p class="s-lede">${esc(L(p.desc))}</p></div>
          <div class="s-opt"><div class="s-opt-h"><span>${esc(t("colour"))}</span><span>${esc(col ? L(col.name) : "")}</span></div>${colorBtns(p, s.color, "pcolor")}</div>
          <div class="s-opt"><div class="s-opt-h"><span>${esc(t("size"))}</span><a href="#help-size">${esc(t("size_guide"))}</a></div>${sizeBtns(p, s.size, "psize")}</div>
          ${emb ? `<div class="s-perso"><button data-act="ptoggle" aria-expanded="${c.on}"><span style="display:grid;gap:.15rem"><b>${esc(t("personalize"))}</b><span>${esc(t("personalize_fee", { p: fmt(x.fee()) }))}</span></span><span style="font-size:1.4rem;line-height:1">${c.on ? "–" : "+"}</span></button>
            ${c.on ? `<div class="in">${embControls("pdp", c, pls, "pdp")}<p class="s-note" id="sPdpEmbNote">${esc(ON_PHOTO.includes(c.placement) && canPhoto ? tx("emb_on") : tx("emb_card"))}</p><p class="s-note">${esc(t("c_note"))}</p></div>` : ""}</div>` : ""}
          ${s.err ? `<p class="s-err" role="alert">${esc(s.err)}</p>` : ""}
          <div class="s-buyrow"><div class="s-qty"><button data-act="pqty" data-d="-1" aria-label="-">−</button><span>${num(s.qty)}</span><button data-act="pqty" data-d="1" aria-label="+">+</button></div>
            <button class="s-btn addcart" data-act="padd" ${p.inStock === false ? "disabled" : ""}>${esc(p.inStock === false ? t("sold_out") : t("add_bag"))}</button></div>
          <div class="s-perks"><div>${ICO.truck}<span>${esc(tx("perk1", { p: fmt(S().settings.freeDeliveryOver || 3500) }))}</span></div><div>${ICO.card}<span>${esc(tx("perk2"))}</span></div>${emb ? `<div>${ICO.needle}<span>${esc(tx("perk3"))}</span></div>` : ""}</div>
          <div class="s-acc">
            <details open><summary>${esc(t("details"))}</summary><div class="body"><p>${esc(L(p.desc))}</p></div></details>
            <details><summary>${esc(t("fabric_care"))}</summary><div class="body"><p>${esc(L(p.fabric))}</p><a class="s-link" href="#help-care">${esc(t("h_care"))}</a></div></details>
            <details><summary>${esc(t("size_guide"))}</summary><div class="body"><p>${esc(x.SIZES.fit[S().lang])}</p><a class="s-link" href="#help-size">${esc(t("h_size"))}</a></div></details>
            <details><summary>${esc(t("delivery"))}</summary><div class="body"><p>${esc(t("delivery_line"))}</p><a class="s-link" href="#help-shipping">${esc(t("h_shipping"))}</a></div></details>
          </div>
        </div>
      </div></div>
      ${related.length ? `<section class="s-sec tight"><div class="s-wrap s-head"><div><h2 class="s-h2">${esc(t("you_may"))}</h2></div>${railCtl("railRel")}</div><div class="s-rail-full">${rail("railRel", related.map((q) => card(q)))}</div></section>` : `<div style="height:80px"></div>`}`;
  }

  /* customize */
  function vCustomize() {
    const x = X(), z = S().cz;
    x.setMeta(t("c_title"), t("c_sub"));
    const pieces = S().products.filter((p) => x.canEmb(p) && p.inStock !== false && p.type !== "bottom" && p.image)
      .sort((a, b) => (POINTS[b.id] ? 1 : 0) - (POINTS[a.id] ? 1 : 0));
    if (!z.pid || !pieces.find((p) => p.id === z.pid)) z.pid = (pieces.find((p) => p.id === "stripe-top") || pieces[0] || {}).id;
    const p = P(z.pid);
    if (!p) return `<div class="s-wrap s-page"><div class="s-empty">${esc(t("no_results"))}</div></div>`;
    if (!z.color || !p.colors.find((c) => c.key === z.color)) z.color = p.colors[0].key;
    const pls = Art().placementsFor(p);
    if (!U.czInit) { U.czInit = true; if (pls.includes("pocket") && !z.text) z.placement = "pocket"; }
    if (!pls.includes(z.placement)) z.placement = pls.includes("pocket") ? "pocket" : pls[0];
    if (z.size && !p.sizes.includes(z.size)) z.size = "";
    if (p.sizes.length === 1) z.size = p.sizes[0];
    const canPhoto = !!POINTS[p.id] && ON_PHOTO.includes(z.placement);
    let v = U.czView; if (v === "close" && !canPhoto) v = "photo";
    const c = { text: z.text || (S().lang === "ar" ? "هيا" : "Haya"), font: z.font, thread: z.thread, placement: z.placement, icon: z.icon };
    const col = colorOf(p, z.color);
    const step = (n, title, sub, body) => `<section class="s-step"><header><span class="n">${num(n)}</span><h2>${esc(title)}</h2>${sub ? `<p>${esc(sub)}</p>` : ""}</header>${body}</section>`;
    return `<div class="s-wrap s-page"><div class="s-cz">
      <div class="s-cz-stage">
        <div class="s-frame main s-photo ${v === "close" ? "close" : ""}" id="sCzMain" style="${zoomVars(p)}">
          <div class="layer" style="${zoomVars(p)}">${img(p.image, L(p.name), "", true)}${monoHTML(p, c)}</div>
          <div class="s-cz-inset" id="sCzSwatch">${swatchHTML(p, z.color, c, t("pl_" + z.placement))}</div>
          ${POINTS[p.id] ? `<div class="s-cz-views" role="group"><button type="button" class="${v === "photo" ? "on" : ""}" data-czview="photo">${esc(tx("v_photo"))}</button><button type="button" class="${v === "close" ? "on" : ""}" data-czview="close" ${canPhoto ? "" : "disabled"}>${esc(tx("v_close"))}</button></div>` : ""}
        </div>
        <div class="s-cz-cap"><b>${esc(tx("emb_preview"))}</b><span id="sCzLine">${esc(c.text)} · ${esc(t("font_" + z.font))} · ${esc(t("th_" + z.thread))} · ${esc(t("pl_" + z.placement))}</span><span class="s-note">${esc(canPhoto ? tx("emb_on") : tx("emb_card"))}</span></div>
      </div>
      <div>
        <div class="s-cz-head"><span class="s-eyebrow">${esc(tx("cz_eyebrow"))}</span><h1 class="s-h2">${esc(tx("cz_title"))}</h1><p class="s-lede">${esc(tx("cz_sub"))}</p></div>
        <div class="s-steps">
          ${step(1, tx("cz_piece"), tx("cz_piece_s"), `<div class="s-pieces-pick">${pieces.map((q) => `<button class="${q.id === p.id ? "on" : ""}" data-act="czp" data-v="${esc(q.id)}" aria-pressed="${q.id === p.id}"><span class="s-frame">${img(thumb(q), "")}</span>${esc(L(q.name))}</button>`).join("")}</div>`)}
          ${step(2, tx("cz_colour_size"), "", `<div class="s-opt"><div class="s-opt-h"><span>${esc(t("colour"))}</span><span>${esc(L(col.name))}</span></div>${colorBtns(p, z.color, "czc")}</div>
            <div class="s-opt"><div class="s-opt-h"><span>${esc(t("size"))}</span><a href="#help-size">${esc(t("size_guide"))}</a></div>${sizeBtns(p, z.size, "czs")}</div>`)}
          ${step(3, tx("cz_name"), tx("cz_name_s"), `<input class="s-input" type="text" id="czText" maxlength="12" value="${esc(z.text)}" placeholder="${esc(t("c_text_ph"))}" data-in="embtext" data-scope="cz" autocomplete="off" style="font-size:1.25rem">
            <div class="s-inspo"><span>${esc(tx("cz_inspo"))}</span>${MODELS.map((m) => `<button type="button" data-czname="${esc(S().lang === "ar" ? m.ar : m.name)}">${esc(S().lang === "ar" ? m.ar : m.name)}</button>`).join("")}</div>`)}
          ${step(4, tx("cz_font"), t("font_" + z.font), `<div class="s-fonts">${x.FONT_KEYS.map((k) => `<button type="button" class="${z.font === k ? "on" : ""}" data-act="emb" data-scope="cz" data-k="font" data-v="${k}" aria-pressed="${z.font === k}"><b style="font-family:${Art().FONTS[k]}" data-sample>${esc(c.text)}</b><span>${esc(t("font_" + k))}</span></button>`).join("")}</div>`)}
          ${step(5, tx("cz_thread"), t("th_" + z.thread), `<div class="s-threads">${x.THREAD_KEYS.map((k) => `<button type="button" class="${z.thread === k ? "on" : ""}" data-act="emb" data-scope="cz" data-k="thread" data-v="${k}" aria-pressed="${z.thread === k}"><i style="background-color:${Art().THREADS[k]}"></i>${esc(t("th_" + k))}</button>`).join("")}</div>`)}
          ${step(6, tx("cz_place"), t("pl_" + z.placement), `<div class="s-chips">${pls.map((k) => `<button type="button" class="s-chip ${z.placement === k ? "on" : ""}" data-act="emb" data-scope="cz" data-k="placement" data-v="${k}" aria-pressed="${z.placement === k}">${esc(t("pl_" + k))}</button>`).join("")}</div>
            <div class="s-field"><span class="lbl">${esc(tx("cz_icon"))}<span>${esc(t("optional"))}</span></span><div class="s-chips">${x.ICON_KEYS.map((k) => `<button type="button" class="s-chip ${(z.icon || "") === k ? "on" : ""}" data-act="emb" data-scope="cz" data-k="icon" data-v="${k}" aria-pressed="${(z.icon || "") === k}">${k ? Art().icon(k, 16, "#6e2135") : ""}${esc(t("icon_" + (k || "none")))}</button>`).join("")}</div></div>
            <div class="s-field"><label for="czNote">${esc(tx("cz_note"))}<span>${esc(t("optional"))}</span></label><textarea class="s-input" id="czNote" rows="2" maxlength="200" placeholder="${esc(t("c_note_ph"))}" data-in="embnote" data-scope="cz">${esc(z.note)}</textarea></div>`)}
          ${step(7, tx("cz_review"), "", `<div class="s-sum" style="margin-top:0">
            <div class="ln"><span>${esc(tx("piece_price"))}: ${esc(L(p.name))} · ${esc(L(col.name))}${z.size ? " · " + esc(z.size) : ""}</span><span>${fmt(p.price)}</span></div>
            <div class="ln"><span>${esc(tx("emb_fee"))}${z.text ? `: “${esc(z.text)}” · ${esc(t("pl_" + z.placement))}` : ""}</span><span>${fmt(x.fee())}</span></div>
            <div class="ln tot"><span>${esc(tx("total"))}</span><span>${fmt(p.price + x.fee())}</span></div>
            ${z.err ? `<p class="s-err" role="alert">${esc(z.err)}</p>` : ""}
            <p class="s-note">${esc(t("c_note"))}</p>
            <button class="s-btn block addcart" data-act="czadd">${esc(t("c_cta"))} ${ICO.arrow}</button></div>`)}
        </div>
      </div></div></div><div style="height:clamp(64px,8vw,120px)"></div>`;
  }

  /* mix and match */
  function vMix() {
    const x = X(), m = S().mix;
    x.setMeta(t("m_title"), t("m_sub"));
    const tops = S().products.filter((p) => p.type === "top" && p.inStock !== false);
    const bottoms = S().products.filter((p) => p.type === "bottom" && p.inStock !== false);
    const extras = S().products.filter((p) => (p.type === "robe" || p.type === "accessory") && p.inStock !== false && !(p.collections || []).includes("bridal") && !(p.collections || []).includes("postpartum"));
    const top = P(m.top), bot = P(m.bottom), q = x.mixQuote();
    const pick = (p, which) => {
      const sel = which === "top" ? m.top : m.bottom, colKey = which === "top" ? m.topColor : m.bottomColor, sizeVal = which === "top" ? m.topSize : m.bottomSize;
      const on = sel === p.id;
      return `<div class="s-pickcard ${on ? "on" : ""}"><button data-act="mxpick" data-w="${which}" data-v="${esc(p.id)}" aria-pressed="${on}" aria-label="${esc(L(p.name))}"><span class="s-frame" style="display:block">${img(p.image, "")}${on ? `<span class="on-badge">✓</span>` : ""}</span></button>
        <h4>${esc(L(p.name))}</h4><span class="pr">${fmt(p.price)}</span>
        ${colorBtns(p, on ? colKey : "", "mxcol", `data-w="${which}" data-p="${esc(p.id)}"`)}
        ${on ? `<select data-in="mxsize" data-w="${which}" aria-label="${esc(t("size"))}"><option value="">${esc(t("size"))}</option>${p.sizes.map((s) => `<option ${sizeVal === s ? "selected" : ""}>${esc(s)}</option>`).join("")}</select>` : ""}</div>`;
    };
    const head = (n, k) => `<div class="s-step" style="border:0;padding:0"><header><span class="n">${num(n)}</span><h2>${esc(t("m_s" + k))}</h2><p>${esc(t("m_s" + k + "s"))}</p></header></div>`;
    const embBlock = (scope, piece, st, label, colKey) => !piece || !x.canEmb(piece) ? "" : `<div style="display:grid;gap:.9rem"><label class="s-emb-toggle"><input type="checkbox" data-in="mxon" data-scope="${scope}" ${st.on ? "checked" : ""}> ${esc(label)} <span class="s-note">${esc(t("personalize_fee", { p: fmt(x.fee()) }))}</span></label>
      ${st.on ? `<div class="s-emb-box"><div class="row"><div>${swatchHTML(piece, colKey, st, t("pl_" + st.placement))}</div>${embControls(scope, st, Art().placementsFor(piece), scope)}</div></div>` : ""}</div>`;
    const lines = [];
    if (top) lines.push([t("m_top"), top, m.topColor, m.topSize, top.price + (m.cTop.on && m.cTop.text ? x.fee() : 0), m.cTop.on && m.cTop.text ? m.cTop : null]);
    if (bot) lines.push([t("m_bottom"), bot, m.bottomColor, m.bottomSize, bot.price + (m.cBot.on && m.cBot.text ? x.fee() : 0), m.cBot.on && m.cBot.text ? m.cBot : null]);
    Object.keys(m.addons).forEach((id) => { const p = P(id); if (p) lines.push([t("m_addon"), p, m.addons[id].color, m.addons[id].size, p.price, null]); });
    return `<div class="s-wrap s-page">
      <div class="s-split" style="margin-bottom:clamp(40px,6vw,80px)"><div class="s-stack"><div class="s-frame wide">${img("assets/rooms/dressing.jpg", "", "", true)}</div>${P("classic-top") ? `<div class="s-frame inset">${img(P("classic-top").image, "")}</div>` : ""}</div>
        <div class="copy"><span class="s-eyebrow">${esc(tx("mx_eyebrow"))}</span><h1 class="s-h2">${esc(t("m_title"))}</h1><p class="s-lede">${esc(t("m_sub"))}</p><p class="s-note">${esc(t("m_save_note", { pct: num(S().settings.setDiscountPct || 0) }))}</p></div></div>
      <div class="s-mx">
        <div>
          <section class="s-mx-step" id="mxs1">${head(1, 1)}<div class="s-mx-pick">${tops.map((p) => pick(p, "top")).join("")}</div></section>
          <section class="s-mx-step" id="mxs2">${head(2, 2)}<div class="s-mx-pick">${bottoms.map((p) => pick(p, "bottom")).join("")}</div></section>
          <section class="s-mx-step" id="mxs3">${head(3, 3)}<div class="s-addons">${extras.map((p) => { const a = m.addons[p.id]; return `<div class="s-addon ${a ? "on" : ""}"><span class="s-frame">${img(thumb(p), "")}</span><div><b>${esc(L(p.name))}</b><small>${fmt(p.price)}</small>
            ${a && p.sizes.length > 1 ? `<select data-in="mxasize" data-p="${esc(p.id)}" aria-label="${esc(t("size"))}">${p.sizes.map((s) => `<option ${a.size === s ? "selected" : ""}>${esc(s)}</option>`).join("")}</select>` : ""}</div>
            <button data-act="mxadd" data-p="${esc(p.id)}" aria-pressed="${!!a}" aria-label="${esc(L(p.name))}">${a ? "✓" : "+"}</button></div>`; }).join("")}</div></section>
          <section class="s-mx-step" id="mxs4">${head(4, 4)}${!top && !bot ? `<p class="s-note">${esc(t("m_need"))}</p>` : ""}
            ${embBlock("mixtop", top, m.cTop, t("m_on_top") + (top ? ": " + L(top.name) : ""), m.topColor)}
            ${embBlock("mixbot", bot, m.cBot, t("personalize") + (bot ? ": " + L(bot.name) : ""), m.bottomColor)}</section>
        </div>
        <aside class="s-yours" aria-label="${esc(tx("mx_your"))}"><h3 class="s-h3">${esc(tx("mx_your"))}</h3>
          ${lines.length ? lines.map(([label, p, ck, size, price, c]) => `<div class="ln"><span class="s-frame">${img(thumb(p), "")}</span><span><b style="font-weight:600">${esc(label)}</b> · ${esc(L(p.name))}<small>${esc(L(colorOf(p, ck).name))} · ${esc(t("size"))}: ${esc(size || "–")}${c ? ` · “${esc(c.text)}”` : ""}</small></span><span>${fmt(price)}</span></div>`).join("") : `<p class="s-note">${esc(t("m_need"))}</p>`}
          ${q.discount ? `<div class="s-sum" style="margin:0;padding:.9rem 1rem"><div class="ln"><span>${esc(t("m_save"))}</span><span style="color:var(--s-wine)">−${fmt(q.discount)}</span></div></div>` : ""}
          <div class="s-sum" style="margin:0;padding:.9rem 1rem"><div class="ln tot" style="border:0;padding:0"><span>${esc(tx("total"))}</span><span>${fmt(q.total)}</span></div></div>
          ${m.err ? `<p class="s-err" role="alert">${esc(m.err)}</p>` : ""}
          <button class="s-btn block addcart" data-act="mxbag">${esc(t("m_add"))} ${ICO.arrow}</button></aside>
      </div></div><div style="height:clamp(64px,8vw,120px)"></div>`;
  }

  /* bundles */
  function bundleVis(b) {
    const ps = b.items.map(P).filter((p) => p && p.image).slice(0, 3);
    return `<div class="vis ${ps.length < 2 ? "one" : ps.length === 2 ? "two" : ""}">${ps.map((p) => img(p.image, "")).join("")}</div>`;
  }
  function vBundles() {
    const x = X();
    x.setMeta(t("b_eyebrow"), t("b_sub"));
    return `<div class="s-wrap s-page">
      <div class="s-banner"><img src="assets/rooms/gifts.jpg" alt=""><div class="in"><span class="s-eyebrow">${esc(tx("b_eyebrow"))}</span><h1 class="s-h1" style="font-size:clamp(2.2rem,4.6vw,4rem)">${esc(tx("b_title"))}</h1><p>${esc(tx("b_sub"))}</p></div></div>
      <div class="s-bundles">${S().bundles.map((b) => {
        const worth = x.bWorth(b), out = x.bundleSoldOut(b);
        return `<article class="s-bundle">${bundleVis(b)}<div class="pad"><h3>${esc(L(b.name))}</h3><p class="s-note">${esc(L(b.desc))}</p>
          <div class="pr"><b>${fmt(b.price)}</b>${worth > b.price ? `<s>${fmt(worth)}</s><span class="s-save">${esc(t("b_save", { p: fmt(worth - b.price) }))}</span>` : ""}</div>
          <details><summary>${esc(t("b_includes"))} · ${esc(t("b_choose_h"))}</summary>${x.bDefs(b)}</details>
          <a class="s-btn" href="#b-${esc(b.id)}" style="justify-self:start" ${out ? 'aria-disabled="true"' : ""}>${esc(out ? t("sold_out") : t("b_choose"))} ${ICO.arrow}</a></div></article>`;
      }).join("")}</div></div><div style="height:clamp(64px,8vw,120px)"></div>`;
  }
  function vBundle(id) {
    const x = X(), b = Bn(id);
    if (!b) return vBundles();
    x.setMeta(L(b.name), L(b.desc));
    const sel = x.bState(b), worth = x.bWorth(b), out = x.bundleSoldOut(b);
    const fees = sel.filter((s) => x.validText(s.text)).length * x.fee();
    return `<div class="s-wrap s-page">
      <div class="s-crumbs"><a href="#home">${esc(t("nav_home"))}</a><span>/</span><a href="#bundles">${esc(t("nav_bundles"))}</a><span>/</span><span>${esc(L(b.name))}</span></div>
      <div class="s-pagehead"><span class="s-eyebrow">${esc(tx("b_eyebrow"))}</span><h1 class="s-h1" style="font-size:clamp(2.2rem,4.4vw,3.6rem)">${esc(L(b.name))}</h1><p class="s-lede">${esc(L(b.desc))}</p>
        <div style="display:flex;gap:.8rem;align-items:baseline;flex-wrap:wrap"><b style="font-size:1.3rem">${fmt(b.price)}</b>${worth > b.price ? `<s class="s-note">${fmt(worth)}</s><span class="s-save">${esc(t("b_save", { p: fmt(worth - b.price) }))}</span>` : ""}</div></div>
      <div class="s-bdetail"><div>
        ${sel.map((s, i) => {
          const p = P(s.pid); if (!p) return "";
          const pls = Art().placementsFor(p);
          const sb = (k, opts, label) => `<label>${esc(label)}<select data-in="bopt" data-k="${k}" data-b="${esc(b.id)}" data-i="${i}">${opts.map(([v, l]) => `<option value="${v}" ${s[k] === v ? "selected" : ""}>${esc(l)}</option>`).join("")}</select></label>`;
          return `<div class="s-bpiece"><div class="s-frame s-photo">${img(p.image, L(p.name))}${monoHTML(p, x.validText(s.text) ? s : null)}</div><div class="opts">
            <h3 class="s-h3">${esc(t("b_each", { n: num(i + 1) }))}: ${esc(L(p.name))}</h3>
            <div class="s-opt"><div class="s-opt-h"><span>${esc(t("colour"))}</span><span>${esc(L(colorOf(p, s.color).name))}</span></div>${colorBtns(p, s.color, "bcol", `data-b="${esc(b.id)}" data-i="${i}"`)}</div>
            <div class="s-opt"><div class="s-opt-h"><span>${esc(t("size"))}</span><a href="#help-size">${esc(t("size_guide"))}</a></div>${sizeBtns(p, s.size, "bsize", `data-b="${esc(b.id)}" data-i="${i}"`)}</div>
            ${x.canEmb(p) ? `<details ${s.text ? "open" : ""}><summary>${esc(t("personalize"))} <span class="s-note">${esc(t("personalize_fee", { p: fmt(x.fee()) }))}</span></summary>
              <div class="row3" style="margin-top:.8rem">
                <label>${esc(tx("cz_name"))}<input type="text" maxlength="12" value="${esc(s.text)}" placeholder="${esc(t("c_text_ph"))}" data-in="btext" data-b="${esc(b.id)}" data-i="${i}"></label>
                ${sb("font", x.FONT_KEYS.map((k) => [k, t("font_" + k)]), tx("cz_font"))}
                ${sb("thread", x.THREAD_KEYS.map((k) => [k, t("th_" + k)]), tx("cz_thread"))}
                ${sb("placement", pls.map((k) => [k, t("pl_" + k)]), tx("cz_place"))}
                ${sb("icon", x.ICON_KEYS.map((k) => [k, t("icon_" + (k || "none"))]), t("icon"))}
                <label>${esc(tx("cz_note"))}<input type="text" maxlength="200" value="${esc(s.note)}" data-in="bnote" data-b="${esc(b.id)}" data-i="${i}"></label>
              </div></details>` : ""}
          </div></div>`;
        }).join("")}</div>
        <aside class="s-bsum"><div class="ln"><span>${esc(L(b.name))}</span><span>${fmt(b.price)}</span></div>${fees ? `<div class="ln"><span>${esc(tx("emb_fee"))}</span><span>${fmt(fees)}</span></div>` : ""}<div class="ln tot"><span>${esc(tx("total"))}</span><span>${fmt(b.price + fees)}</span></div>
          ${S().bErr ? `<p class="s-err" role="alert">${esc(S().bErr)}</p>` : ""}<button class="s-btn block addcart" data-act="badd" data-b="${esc(b.id)}" ${out ? "disabled" : ""}>${esc(out ? t("sold_out") : t("b_add"))} ${ICO.arrow}</button>
          ${x.bDefs(b)}</aside>
      </div></div><div style="height:clamp(64px,8vw,120px)"></div>`;
  }

  /* story */
  function vStory() {
    X().setMeta(t("st_title"), t("st_open"));
    const st = S().settings;
    const pics = ["assets/brand-bedroom.jpg", "assets/posters/poster-2.jpg", "assets/brand-crescents.jpg", "assets/posters/poster-3.jpg", "assets/posters/poster-5.jpg", "assets/posters/poster-6.jpg"];
    return `<div class="s-wrap s-page">
      <div class="s-story-hero"><img src="assets/brand-story-wide.jpg" alt=""><div class="in"><span class="s-eyebrow" style="color:var(--s-petal)">${esc(t("st_eyebrow"))}</span><h1 class="s-h1">${esc(t("st_title"))}</h1><p>${esc(t("st_open"))}</p></div></div>
      <section class="s-sec"><div class="s-chapters">${[1, 2, 3, 4, 5, 6].map((n, i) => `<div class="s-chapter"><div class="s-frame">${img(pics[i], "")}</div>
        <div class="copy"><span class="num">${esc(tx("chapter"))} ${num(n)}</span><h2 class="s-h2">${esc(t("st_h" + n))}</h2><p class="s-lede">${esc(t("st_p" + n))}</p>
          ${n === 4 ? `<div class="s-palette">${["#fad6e1", "#f6e7f1", "#fbf8ef", "#6e2135", "#4f2b1f"].map((c) => `<i style="background:${c}"></i>`).join("")}</div>` : ""}
          ${n === 5 ? `<div class="s-chips">${COLS.map((c) => `<a class="s-chip" href="#shop-${c}" style="text-decoration:none">${esc(t("col_" + c))}</a>`).join("")}</div>` : ""}
          ${n === 6 ? `<div class="s-chips"><a class="s-chip" style="text-decoration:none" href="${esc(st.instagram || "#")}" target="_blank" rel="noopener">Instagram</a><a class="s-chip" style="text-decoration:none" href="${esc(st.tiktok || "#")}" target="_blank" rel="noopener">TikTok</a><a class="s-chip" style="text-decoration:none" href="${esc(st.pinterest || "#")}" target="_blank" rel="noopener">Pinterest</a></div>` : ""}
        </div></div>`).join("")}</div></section>
      <section class="s-sec pink" style="border-radius:var(--r-xl);margin-bottom:clamp(48px,6vw,96px)"><div class="s-quote">${LOGO("LuneByNoon")}<p>${esc(t("tagline"))}</p><a class="s-btn" href="#shop">${esc(tx("shop_now"))} ${ICO.arrow}</a></div></section>
    </div>`;
  }

  /* ---------------------------------------------------------------- live updates */
  function fitMonos(root) {
    $$(".s-mono", root || document).forEach((m) => {
      const host = m.closest(".s-photo"); if (!host) return;
      const W = host.clientWidth; if (!W) return;
      const target = (parseFloat(m.dataset.w) || 5) / 100 * W;
      m.style.fontSize = "100px";
      const w = m.scrollWidth || 1;
      let fs = 100 * target / w;
      fs = Math.min(fs, target * 0.62);
      m.style.fontSize = fs.toFixed(2) + "px";
    });
  }
  function onCz() {
    if (route().name !== "customize") return;
    const z = S().cz, p = P(z.pid); if (!p) return;
    const text = z.text || (S().lang === "ar" ? "هيا" : "Haya");
    const c = { text, font: z.font, thread: z.thread, placement: z.placement, icon: z.icon };
    const layer = $("#sCzMain .layer");
    if (layer) { const old = layer.querySelector(".s-mono"); if (old) old.remove(); layer.insertAdjacentHTML("beforeend", monoHTML(p, c)); fitMonos(layer.parentNode); }
    const sw = $("#sCzSwatch"); if (sw) sw.innerHTML = swatchHTML(p, z.color, c, t("pl_" + z.placement));
    const ln = $("#sCzLine"); if (ln) ln.textContent = `${text} · ${t("font_" + z.font)} · ${t("th_" + z.thread)} · ${t("pl_" + z.placement)}`;
    $$("[data-sample]").forEach((b) => { b.textContent = text; });
  }
  function onEmb(scope) {
    if (scope !== "pdp" || route().name !== "p") return;
    const p = P(route().arg), s = S().pdp; if (!p) return;
    const pr = $("#sPdpPrice"); if (pr) pr.innerHTML = fmt(p.price + (s.c.text ? X().fee() : 0)) + (p.compareAt ? `<s>${fmt(p.compareAt)}</s>` : "");
    const layer = $("#sPdpMain .layer");
    if (layer) { const old = layer.querySelector(".s-mono"); if (old) old.remove(); const sample = s.c.text ? s.c : null; layer.insertAdjacentHTML("beforeend", monoHTML(p, sample)); fitMonos(layer.parentNode); }
    $$("[data-sample]").forEach((b) => { b.textContent = s.c.text || (S().lang === "ar" ? "هيا" : "Haya"); });
    const sw = $("#sPdpMain .s-swatch .txt"); if (sw && s.c.text) sw.firstChild.textContent = s.c.text;
  }

  /* ---------------------------------------------------------------- the door */
  function doorSeen() { try { return !!sessionStorage.getItem("lbn_intro"); } catch (e) { return true; } }
  function markSeen() { try { sessionStorage.setItem("lbn_intro", "1"); } catch (e) {} }
  function showDoor() {
    if ($("#door") || doorSeen() || route().name !== "home") return;
    const el = document.createElement("div");
    el.id = "door"; el.className = "s-door"; el.setAttribute("role", "dialog"); el.setAttribute("aria-modal", "true"); el.setAttribute("aria-label", "LuneByNoon");
    el.innerHTML = `<div class="s-door-view"><div class="s-stage" id="doorStage">
        <img class="room" src="assets/rooms/door.jpg" alt="" fetchpriority="high">
        <div class="s-opening"><img src="assets/brand-story-wide.jpg" alt=""></div>
        <div class="s-leaves"><div class="s-leaf l"><img src="assets/rooms/door.jpg" alt=""><span class="crest"></span></div><div class="s-leaf r"><img src="assets/rooms/door.jpg" alt=""><span class="crest"></span></div></div>
        <button class="s-door-hit" type="button" aria-label="${esc(tx("door_open"))}"></button>
      </div></div>
      <button class="s-door-skip" type="button">${esc(tx("door_skip"))}</button>
      <div class="s-door-ui"><p>${esc(tx("door_msg"))}</p><button class="s-btn light" type="button" id="doorOpen">${esc(tx("door_open"))}</button></div>`;
    document.body.appendChild(el);
    document.body.classList.add("s-lock");
    const open = () => {
      if (el.classList.contains("open")) return;
      markSeen(); el.classList.add("open");
      try { if (X().playDoor) X().playDoor(); } catch (e) {}
      if (reduce()) { finish(); return; }
      const stage = $("#doorStage"), r = stage.getBoundingClientRect();
      const ow = r.width * .37625, oh = r.height * .85111;
      const s = Math.max(innerWidth / ow, innerHeight / oh) * 1.08;
      setTimeout(() => { stage.classList.add("push"); stage.style.transform = `translate(-50%, -50%) scale(${s.toFixed(3)})`; }, 1050);
      setTimeout(() => el.classList.add("fade"), 2150);
      setTimeout(finish, 3150);
    };
    const finish = () => { markSeen(); el.remove(); document.body.classList.remove("s-lock"); const m = $("#main"); if (m) m.focus({ preventScroll: true }); };
    el.querySelector("#doorOpen").addEventListener("click", open);
    el.querySelector(".s-door-hit").addEventListener("click", open);
    el.querySelector(".s-door-skip").addEventListener("click", finish);
    el.addEventListener("keydown", (e) => { if (e.key === "Escape") finish(); });
    setTimeout(() => { const b = el.querySelector("#doorOpen"); if (b) b.focus({ preventScroll: true }); }, 50);
  }

  /* ---------------------------------------------------------------- scroll motion
     Native, free scrolling. Nothing is held or snapped: the page only reads the
     scroll position and moves things in response (grow, drift, drop, pull up). */
  const MO = { raf: 0, par: [], grow: [], mq: [], hx: null, io: null };
  const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
  function motionScan() {
    const still = reduce();
    document.documentElement.classList.toggle("s-still", still);
    if (!MO.io && "IntersectionObserver" in window) {
      MO.io = new IntersectionObserver((es) => es.forEach((e) => { if (e.isIntersecting) { e.target.classList.add("in"); MO.io.unobserve(e.target); } }), { rootMargin: "0px 0px -6% 0px", threshold: 0.08 });
    }
    $$("[data-rv]:not(.in), [data-pop]:not(.in)").forEach((el) => { if (still || !MO.io) el.classList.add("in"); else MO.io.observe(el); });
    MO.par = still ? [] : $$("[data-par]");
    MO.grow = still ? [] : $$("[data-grow]");
    MO.mq = $$("[data-mq]");
    MO.hx = $("#sHx");
    if (MO.hx) { const h = $(".hdr"); MO.hx.style.setProperty("--hdr", (h ? h.offsetHeight : 72) + "px"); }
    tick();
  }
  const RAF = window.requestAnimationFrame ? window.requestAnimationFrame.bind(window) : (f) => setTimeout(f, 16);
  const CAF = window.cancelAnimationFrame ? window.cancelAnimationFrame.bind(window) : clearTimeout;
  function tick() { if (!MO.raf) MO.raf = RAF(frame); }
  function frame() {
    MO.raf = 0;
    const vh = innerHeight, y = scrollY;
    if (MO.hx && document.body.contains(MO.hx)) {
      const r = MO.hx.getBoundingClientRect(), pin = MO.hx.firstElementChild ? MO.hx.firstElementChild.offsetHeight : vh;
      const p = reduce() ? 1 : clamp(-r.top / Math.max(1, r.height - pin), 0, 1);
      MO.hx.style.setProperty("--p", p.toFixed(4));
    }
    for (const el of MO.par) {
      const r = el.getBoundingClientRect(); if (r.bottom < -300 || r.top > vh + 300) continue;
      const c = (r.top + r.height / 2 - vh / 2) / vh;
      el.style.setProperty("--py", (c * parseFloat(el.dataset.par) * -160).toFixed(1) + "px");
    }
    for (const el of MO.grow) {
      const r = el.getBoundingClientRect(); if (r.bottom < -100 || r.top > vh + 100) continue;
      el.style.setProperty("--g", clamp((vh - r.top) / (vh * 0.85), 0, 1).toFixed(3));
    }
    for (const el of MO.mq) {
      const w = el.scrollWidth / 3 || 1, dir = el.dataset.mq === "r" ? 1 : -1;
      el.style.setProperty("--mx", (dir * ((y * 0.35) % w) - (dir > 0 ? w : 0)).toFixed(1) + "px");
    }
    const rail = $("#sSide");
    if (rail) { const max = document.documentElement.scrollHeight - vh; rail.style.setProperty("--sp", max > 0 ? clamp(y / max, 0, 1).toFixed(4) : 0); }
  }
  function sideRail() {
    if ($("#sSide")) return;
    const a = document.createElement("aside");
    a.id = "sSide"; a.className = "s-side"; a.setAttribute("aria-hidden", "true");
    a.innerHTML = `<a href="#home" tabindex="-1" class="logo-v"><img src="assets/logo-burgundy.svg" alt="" width="640" height="147"></a><span class="bar"><i></i></span><span class="mn">${SICON.moon}</span>`;
    document.body.appendChild(a);
    document.body.classList.add("s-has-side");
  }

  /* ---------------------------------------------------------------- lifecycle */
  function before() {}
  function after(r) {
    bindOnce();
    sideRail();
    fitMonos();
    motionScan();
    if (r.name === "home") showDoor();
  }
  function bindOnce() {
    if (U.bound) return; U.bound = true;
    document.addEventListener("click", (e) => {
      const rb = e.target.closest("[data-srail]");
      if (rb) { const el = document.getElementById(rb.dataset.srail); if (el) { const card = el.firstElementChild; const step = card ? card.getBoundingClientRect().width + 24 : 300; const dir = document.documentElement.dir === "rtl" ? -1 : 1; el.scrollBy({ left: Number(rb.dataset.d) * step * 2 * dir, behavior: reduce() ? "auto" : "smooth" }); } return; }
      const ty = e.target.closest("[data-stype]");
      if (ty) { U.shopType = ty.dataset.stype; X().renderMain(true); return; }
      const pv = e.target.closest("[data-spview]");
      if (pv) { U.pdpView = pv.dataset.spview; X().renderMain(true); return; }
      const cv = e.target.closest("[data-czview]");
      if (cv) { U.czView = cv.dataset.czview; X().renderMain(true); return; }
      const nm = e.target.closest("[data-czname]");
      if (nm) { S().cz.text = nm.dataset.czname; S().cz.err = ""; X().renderMain(true); return; }
      const pt = e.target.closest('[data-act="ptoggle"]');
      if (pt && !S().pdp.c.on && POINTS[S().pdp.id]) U.pdpView = "close";
      const sn = e.target.closest("[data-sname]");
      if (sn) { const z = S().cz; z.text = sn.dataset.sname; z.thread = sn.dataset.sthread || z.thread; z.font = "script"; z.placement = "pocket"; z.pid = sn.dataset.spid; z.color = null; U.czView = "close"; }
    });
    document.addEventListener("change", (e) => {
      if (e.target && e.target.matches && e.target.matches("[data-ssort]")) { U.shopSort = e.target.value; X().renderMain(true); }
    });
    let rt = 0;
    window.addEventListener("resize", () => { CAF(rt); rt = RAF(() => { fitMonos(); motionScan(); }); });
    window.addEventListener("scroll", tick, { passive: true });
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(() => fitMonos());
    window.addEventListener("hashchange", () => { U.pdpView = "photo"; });
  }

  window.LBNUI = { header, footer, view, before, after, onCz, onEmb, onTry: () => {}, fitMonos };
})();
